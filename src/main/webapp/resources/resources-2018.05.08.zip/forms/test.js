define([ "dfe-core", 
        'dfe-field-helper',
        "components/component", 
        "components/labeled-component", 
        "components/editbox", 
        "components/container", 
        "components/table",
        "components/button",
        "components/checkbox" ], function(core, fields, Component, Labeled, Editbox, Container, Table, Button, Checkbox) {
    return class TestForm extends core.DfeForm {
        static fields() {
            return (
                Container.field("field-0", { get: $$ => $$('policy.cmau') }, [
                    Table.field("field-1", { get: $$ => $$('.location') }, [
                        Container.field("field-2", { get: $$ => $$('.showStuff') == 'Y' ? [] : [$$] }, [
                            Editbox.field("field-3", {
                                atr: () => fields.simple('.address1', { vstrategy: 'always' })
                            })
                        ]),
                        Checkbox.field("field-4", { get: $$ => $$('.showStuff'), set: ($$, value) => $$.set('.showStuff', value) })
                    ]),
                    Button.field("field-5", { get: () => 'Add', set: $$ => $$.append('.location', {address1: 'New one'}) })
                ])
            )
            /*return Table.field("field-1", { get: $$ => $$('policy') }, [
                Labeled.field("field-2", { atr: () => ({label: 'Some label'}) }, [
                    Editbox.field("field-3", {
                        get: $$ => $$('policy.effective'),
                        set: ($$, value) => $$.set('policy.effective', value),
                        atr: () => ({
                            formatting: 'MM/DD/YYYY',
                            transform: '67890134',
                            vstrategy: 'always'
                        }),
                        val: $$ => $$('policy.effective').match(/\d{8}/) || $$.error('Some error'), 
                        pos: [{ style: 'display: inline-block' }]
                    })
                ]),
                Labeled.field("field-4", { atr: () => ({label: 'Some label'}) }, [
                    Editbox.field("field-5", {
                        get: $$ => $$('policy.effective'),
                        set: ($$, value) => $$.set('policy.effective', value),
                        atr: () => ({
                            formatting: 'MM/DD/YYYY',
                            transform: '67890134',
                            vstrategy: 'always'
                        }),
                        val: $$ => $$('policy.effective').match(/\d{8}/) || $$.error('Some error'), 
                        pos: [{ style: 'display: inline-block' }]
                    })
                ])
            ]);*/
            /*return Editbox.field("field-2", {
                    get: $$ => $$('policy.effective'),
                    set: ($$, value) => $$.set('policy.effective', value),
                    atr: () => ({
                        formatting: 'MM/DD/YYYY',
                        transform: '67890134'
                    })
                });*/
            /*return Labeled.field("field-1", { atr: () => ({label: 'Some label'}) }, [
                Editbox.field("field-2", {
                    get: $$ => $$('policy.effective'),
                    set: ($$, value) => $$.set('policy.effective', value),
                    atr: () => ({
                        formatting: 'MM/DD/YYYY',
                        transform: '67890134'
                    })
                })
            ])*/
        }
    }
});