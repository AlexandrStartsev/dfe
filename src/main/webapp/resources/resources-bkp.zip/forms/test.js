defineForm([ "require", "dfe-common", "components/editbox" ], function(require, cmn, __c_editbox) {
    return new class {
        constructor() {
            this.dfe = __c_editbox("field-2", {
                get: $$ => $$('control.overrideeffectivelimit'),
                set: ($$, value) => $$.set('control.overrideeffectivelimit', value)
            });
        }
        onstart($$) {
           // $$.defaultSubset('policy.producer');
        //    $$.defaultValue('policy.effective', cmn.yyyymmdd(cmn.today()));
          //  $$.defaultValue('policy.common.StateofDomicile', 'KS');
            //$$.defaultValue('control.overrideeffectivelimit', 'N');
        }
        setup() {}
    }();
});