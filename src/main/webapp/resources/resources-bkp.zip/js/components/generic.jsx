

/*(function (){
    var sss = new Set();
    
	function _test(a, b) { if(a == 0) return b == 0; if(typeof a != 'object') return a == b; for(var i in a) if(a[i] != b[i]) return false; return true; }
	function _extend() { for(var i = arguments.length-1, to = arguments[i], from; from = arguments[--i];) for (var key in from) to[key] = from[key]; return to; }
    function defer(p, c, d, e, a, t) { return c._deferred = p ? 0 : function(p) {c.component.render(p, c, d, e, a, t)} }  
    function _base() { return function (n, f, c) { return _extend({name:n,children:c||[],component:arguments.callee},f) } }
	define('components/component', ['ui/utils'], function(uiUtils) {
	    return _extend({
	        cname: 'component',
	        isContainer: false,
            slots: 1,
            mapAttributes: function(attrs, map, override) {
                var ret = {}; for(var i in attrs) ret[ map.get(i) || i ] = override && typeof override[i] != 'undefined' ? override[i] : attrs[i]; return ret;
            },
	        toAttribute: (function(c){ var r = new Set(); c.forEach(function(a) {r.add(a)}); return r})([
	                                                                'name', 'id', 'disabled', 'hidden', 'readonly', 'maxlength', 'placeholder', 'spellcheck', 
	                                                                'class', 'style', 'type']),
	        setAttributesUI: function(ui, errs, attrs) { 
	            for(var i in attrs) {
                    this.toAttribute.has(i) && uiUtils.setAttribute(ui, i, attrs[i]);
	            }
	        },
	        setAttributes: function(control, errs, attrs) { 
	            this.setAttributesUI(control.ui, errs, attrs);
	        },
	        setParentNode: function(control, nodes) {
	            if(control._allParentNodes = nodes)
                    control._deferred ? ( control.ui && this.attachUI(control, nodes), control.notifications == 0 && control._deferred(nodes)) : this.attachUI(control, nodes)
                else
	            	this.detachUI(control);
	        },
            attachUI: function (control, nodes) {
                control.ui && control.ui.parentNode != nodes[0] && nodes[0].appendChild(control.ui); 
	            control.errorUi && nodes[0].appendChild(control.errorUi);
            },
            detachUI: function (control) {
                uiUtils.removeNode(control.ui);
	        	uiUtils.removeNode(control.errorUi);
            },
	        emptyUI: function (control) {
                this.detachUI(control);
	        	delete control.ui;
                delete control.errorUi;
	        },
	        purge: function (control) { 
	            this.emptyUI(control); 
	        },
	        doValidation: function(control, events, attrs) { 
	            attrs || (attrs = {});
	            var vs = (attrs.vstrategy||'').split(' ');
	            if( vs.indexOf('none') != -1 ) return false;
	            if( ( vs.indexOf('disabled') == -1 && attrs.disabled) || attrs.hidden ) return false;
	            if( vs.indexOf('always') != -1 ) return true;
	            if( ( vs.indexOf('notified') != -1 || vs.indexOf('followup') != -1 && control.stickyError )
	                       && (control.error || events.length > 1 || events.length && events[0].action != 'init') ) return true;
	            return control.error || events.filter(function(e) { return 'validate' == e.action }) != 0; 
	        },
	        appendError: function(control, ui, errs, attrs) { 
	        	uiUtils.removeNode(control.errorUi);
                if( errs ) {
                    control.errorUi = document.createElement('label'); 
                    uiUtils.setAttribute(control.errorUi, 'class', attrs.eclass || 'dfe-error');
                    uiUtils.setAttribute(control.errorUi, 'style', attrs.estyle); // || 'color: #DB1260; font-weight: bold; display: block;'
                    control.errorUi.innerHTML = errs;
                    return ui && ui.appendChild(control.errorUi);
                }
                delete control.errorUi;
	        },
	        store: function(control, value, method) { control.model.runtime.store(control, value, method) },
	        _render: function(control, model_proxy, errs, attrs, events) { this.render(control._allParentNodes, control, model_proxy, errs, attrs, events) },
	        render: function(nodes, control, model_proxy, errs, attrs, events) {},
	        layout: 'none',
	        runtime: function(control) { return control.runtime || (control.runtime={}) },
	        setEvents: function(ui, control, data, errs, attrs) {
	            for(var n in attrs.events) 
	                (function(a, e) { 
	                    if(typeof e == 'function') {
	                        var nm = a, t = ui, id, i=a.indexOf('$'); 
	                        uiUtils.addEventListener(t, nm, function(event) { 
	                        	return e.call(control.model.runtime.form, event, control) 
	                        }, false);
	                    }
	                })(n, attrs.events[n]);
	        },
            base: _base
	    }, _base())
	})
    
	define('components/editbox', ['components/component', 'ui/utils', 'components/date-picker-polyfill'], function(Component, uiUtils) {
	    var Patterning = function(v, p) { while(p && v != 0 && !(v.match(p) && v.match(p)[0] == v) ) v = v.substr(0, v.length-1); return v; }
	    var Formatting = function(value, format) { // aka XXX-XXX-XXXX or MM/DD/YYYY
	        if(format && typeof value !== 'undefined') {
	            var ret = '', i, j, vn, vl, fn, fl;
	            value = (Array.isArray(value) ? value[0] : value).toString().replace(/\W/g, '');
	            for (i = 0, j = 0; i < format.length && j < value.length; i++) {
	                vn = !(vl = value.charAt(j).match(/[A-Z]/i)) && !isNaN(parseInt(value.charAt(j)));
	                fn = !(fl = format.charAt(i) == '_') && 'XdDmMyY9'.indexOf(format.charAt(i)) >= 0;
	                if (fl && !vl || fn && !vn) break ;
	                ret += fl && vl || fn && vn ? value.charAt(j++) : format.charAt(i);
	            }
	            value = ret;
	        }
	        return value||'';
	    }
	    return _extend({
	        cname: 'editbox',
	        render: function (nodes, control, data, errs, attrs, events) {
                if(!defer(nodes, control, data, errs, attrs, events)) {
                    if(attrs.transform) {
                        control.transform = [];
                        attrs.transform.split('').forEach(function(s) { control.transform.push(s.charCodeAt(0)-(s.charCodeAt(0) > 57 ? 55 : 48)) });
                    }
                    control.pattern = attrs.pattern;
                    control.formatting = attrs.formatting;
                    if(!control.ui) {
                        nodes[0].appendChild(control.ui = document.createElement('input'))._dfe_ = control;
                        control.ca = 0;
                        uiUtils.addEventListener(control.ui, 'keydown', function(e) {
                            var s = control.ui.selectionStart, v = control.ui.value, m; 
                            if((e.key == 'Backspace' || e.key == 'Delete' || e.key == 'Del') && control.formatting && v.length != control.ui.selectionEnd) {
                                e.preventDefault();
                                s && (control.ui.selectionEnd = --control.ui.selectionStart);  
                            } 
                            if(!e.key || e.key.length > 1 || e.ctrlKey) return ;
                            if(control.formatting) {
                                control.ca++;
                                if(e.key == control.formatting[s]) { control.ui.selectionStart++; e.preventDefault(); return ; }
                                while(control.formatting[s] && '_XdDmMyY9'.indexOf(control.formatting[s])==-1) s++;
                                var ol = v.length, nl = Formatting(v.substr(0, s) + e.key + v.substr(s + 1), control.formatting).length;
                                if(s < ol && nl >= ol || s >= ol && nl > ol ) {
                                    control.ui.value = control.ui.value.substr(0, s) + control.ui.value.substr(s + 1); 
                                    control.ui.selectionEnd = s; 
                                } else {
                                    e.preventDefault();
                                    return ;
                                }
                            }
                            if(control.pattern) {
                                m = (v = control.ui.value.substr(0, s) + e.key + control.ui.value.substr(control.ui.selectionEnd)).match(control.pattern);
                                (!m || m[0] != v) && (control.ca--, e.preventDefault());
                            }
                        }, false);
                        var store = function() { 
                            var f = control.formatting, p = control.pattern, data = Patterning(Formatting(control.ui.value, f), p); 
                            if(control.transform) { 
                                var t = []; for(var i=0;i<control.transform.length; i++)
                                    data.length > control.transform[i] && (t[i] = data.charAt(control.transform[i]));
                                for(var i=0;i<t.length; i++) 
                                    t[i] = t[i]||' ';
                                data = t.join('');
                            }
                            delete control.inputLock;
                            control.notifications.push({ action : 'self' }); 
                            control.component.store(control, data); 
                        }
                        uiUtils.addEventListener(control.ui, 'keydown', function() { control.inputLock = true; })
                        uiUtils.addEventListener(control.ui, attrs.trigger||'keyup', store);
                        attrs.trigger == 'change' || uiUtils.addEventListener(control.ui, 'change', store);
                        this.setEvents(control.ui, control, data, errs, attrs);
                    }
                    Array.isArray(data) && (data=data[0]), data || (data=''), data = data.toString();
                    if(control.transform) { 
                        var t = []; for(var i=0;i<data.length; i++) 
                            control.transform.length > i && (t[control.transform[i]] = data.charAt(i));
                        data = t.join('');
                    }
                    data = Patterning(Formatting(data, control.formatting), control.pattern);
                    if(data != control.ui.value && !control.inputLock) {
                        var v = control.ui.value, ss = control.ui.selectionStart;
                        control.ui.value = data;
                        if(control.formatting && ss >= control.ca && ss <= v.length && v != control.ui.value) {
                           var over = control.formatting.substr(ss-control.ca, control.ca).replace(/[_XdDmMyY9]/g,'').length;
                           if(control.ui.ownerDocument.activeElement == control.ui)
                               control.ui.selectionEnd = control.ui.selectionStart = ss + over; 
                        }
                        control.ca = 0;
                    }
                    this.setAttributes(control, errs, attrs);
                    this.appendError(control, nodes[0], errs, attrs);
                }
	        },
	        setAttributes: function(control, errs, attrs) {
	        	control.ui.disabled = attrs.disabled; 
	            attrs.placeholder = attrs.disabled ? '' : control.formatting || attrs.placeholder;
	            Component.setAttributes.call(this, control, errs, attrs);
	        },
	        appendError: function(control, ui, errs, attrs) {
	            if(attrs.eclass) 
	            	uiUtils.setAttribute(control.ui, 'class', (attrs['class']||'') + (errs ? (attrs['class'] ? ' ' : '') + attrs.eclass : ''));
	            else 
	                Component.appendError.call(this, control, ui, errs, attrs);
	        }
	    }, Component, _base())
	})

    define('components/pass-through', ['components/component', 'ui/utils'], function(Component, uiUtils) {
        return _extend({
	        cname: 'pass-through',
            isContainer: true,
            slots: 0,
            // TODO: ...
            attachUI: function (control, nodes) {
                var i = 0;
            	nodes && control.fixedChildren.forEach(function(c) {
                    c.component.setParentNode(c, nodes.slice(i, i += c.component.slots))
                })
            },
            detachUI: function (control) {
                control.fixedChildren.forEach(function(c) { 
                    c.component.detachUI(c)
                })
            },            
	        render: function (nodes, control, data, errs, attrs, events) {
	        	this.attachUI(control, nodes);
	        }
	    }, Component, function() { throw 'Not to be used directly' });
    })  
})()
*/