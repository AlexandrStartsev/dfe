typeof Date === 'undefined' && (Date = {});

Date.prototype.yyyymmdd = function() {
  var mm = this.getMonth() + 1, dd = this.getDate();
  return [this.getFullYear(),(mm>9 ? '' : '0') + mm,(dd>9 ? '' : '0') + dd].join('');
}
Date.ARFtoDate = function(ad) { 
    Array.isArray(ad) && (ad=ad[0]);
    var dt = new Date(ad.substr(0, 4),ad.substr(4, 2)-1,ad.substr(6, 2)); 
    return (dt == 'Invalid&nbsp;Date' || dt.yyyymmdd() != ad) ? 'Invalid&nbsp;Date' : dt;
}
Date.today = function(days) { return new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() + (days || 0)); }

var arfDatePattern = '^(18|19|20)((\d\d(((0[1-9]|1[012])(0[1-9]|1[0-9]|2[0-8]))|((0[13578]|1[02])(29|30|31))|((0[4,6,9]|11)(29|30))))|(([02468][048]|[13579][26])0229))$';
var statesPattern = 'AK|AL|AR|AZ|CA|CO|CT|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NC|ND|NE|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY';
var statesPatternType = (ss = new Set(), statesPattern.split('|').forEach(function(s) {ss.add(s.charAt(0))}), Array.from(ss).join('|') + '|' + statesPattern);

//#################################################################################################################
function required($$, name, pattern, message) {
    var val = $$.get(name);
    Array.isArray(val) && (val = val[0]);
    if( typeof val === 'undefined' || val.toString().replace(/ /g, '') === '' ) $$.error(message || 'Required');
    else if( pattern === 'date' && Date.ARFtoDate(val.toString()) == 'Invalid&nbsp;Date' || pattern && pattern !== 'date' && ! val.match(pattern) ) 
            $$.error(message || 'Invalid&nbsp;format');
         else return true ;
}
//#################################################################################################################

typeof ajaxCache !== 'undefined' || (ajaxCache = new Map());
// 'https://cors-anywhere.herokuapp.com/'; headers : {'X-Requested-With': 'Accept'}
//, headers: {'Content-Type': 'application/x-www-form-urlencoded'} <- auto added
//, headers: {'X-Requested-With': 'Accept'} 
// url, param, name, element, method, headers, mapper, errorcallback, default
function ajaxFeed($$, o) {
   //function extend(v1, v2) {r={};for(v in v1)r[v]=v1[v];for(v in v2)r[v]=v2[v]; return r}
   //o = extend({element : 'result', method: 'GET', headers: {}, mapper : function(i) {return i}}, o);
   o = _extend(o, {element : 'result', method: 'GET', headers: {}, mapper : function(i) {return i}});
   var r = { value : ( o.name ? o.param[o.name] : o.param), url: o.url, status: 'loading', items : []}, cached, has = false, e;
   test = o.name ? function(i) { return i[o.name]==o.param[o.name]; } : function(i) { for(v in o.param) if(i[v]!=o.param[v]) return; return true; }
   var success = function(data, status) {
	  typeof data == 'string' && (data=JSON.parse(data));
      ajaxCache.set(o.url, data);
      d = data && (o.element && data[o.element] || data);
      o['default'] && (d = [o['default']].concat(d));
      (r.status = status) == 'success' && Array.isArray(d) && d.forEach( function(i) { r.items.push(i=o.mapper(i)); r.found||test(i)&&(r.found=(o.name ? i[o.name] : i)) });
      if(!r.found) {
          e = (o.errorcallback ? o.errorcallback(status, r, o.param) : (r.items.length > 0 ? 'Please&nbsp;make&nbsp;selection' : 'Not&nbsp;found')); 
          if($$.control.doVal && e && !o.noerror) { $$.control.data = r; $$.error(e) } else { $$.result(r) }
      } else { 
          delete $$.control.error;
          $$.result(r); 
      }
   };
   if( (cached = ajaxCache.get(o.url)) != undefined) success(cached, 'success');
   else  
       $.ajax({ url: o.url, dataType: 'json', type: o.method, success: success, 
            headers : _extend(o.headers, {'Content-Type': 'application/x-www-form-urlencoded'}),
            error: function (status, error) {
                r.status = status;
                e = (o.errorcallback ? o.errorcallback(status, error, o.param) : JSON.stringify(error)); 
                if($$.control.doVal && e && !o.noerror) { $$.control.data = r; $$.error(e) } else { /*$$.control.error = e;*/ $$.result(r) }
            }
        });
   if(r.status == 'loading') return r; // to prevent re-rendering after synchronous $.ajax call
}
//###########################################################################################################
function ajaxPost(data, url, accept, error) {
    $.ajax({ url: url, type: 'POST', dataType: 'json', contentType:"application/json; charset=utf-8", data: JSON.stringify(data),
        success: function(d, s) { typeof accept == 'function' && accept(d, s); },
        error: function(d, s, e) { typeof error == 'function' ? error(d, s, e) : console.log(e); }
    });
}
//#################################################################################################################

function jsonToJs(obj, formName) {
    var cc = [], fields = [], setup, pos, needsReturn = function(code) {
        try{
            return fbody = require('esprima').parse(code).body, fbody.length == 1 && ( fbody[0].type == 'ExpressionStatement' ||
                    fbody[0].type == 'BlockStatement' && fbody[0].body.filter(function(b) { b.type != 'LabeledStatement'}).length === 0);
        } catch(e) { return true; }
    }
    obj.dfe.forEach(function(r) {
        var c = r.type, field = '{name:"' + r.name + '",component:argument[' + (cc.indexOf(c) >= 0? cc.indexOf(c) : (cc.push(c), cc.length - 1)) + '],';
        typeof r.parent     == 'string' && ( field += 'parent:"' + r.parent + '",' );
        typeof r['class']   == 'string' && ( field += '"class": "' + r['class'] + '",' );
        typeof r._get       == 'string' && ( field += 'get:function($$){' + (needsReturn(r._get) ? 'return ' : '') + r._get + '},' ); 
        typeof r._set       == 'string' && ( field += 'set:function($$,value){' + r._set + '},' ); 
        typeof r.validation == 'string' && ( field += 'val:function($$){' + (needsReturn(r.validation) ? 'return ' : '') + r.validation + '},' );
        typeof r.attributes == 'string' && ( field += 'atr:function($$){' + (needsReturn(r.attributes) ? 'return ' : '') + r.attributes + '},' );
        ['tpos', 'dpos'].forEach(function(p){
            if(r[p]) {
                pos = '';
                for(v in r[p]) 
                    pos += String.format('{0}:"{1}",', v, r[p][v])
                pos && ( field = field + p + ':{' + pos + '},' );
            }
        })
        field = (field + '}').replace(/\,\}/g,'}');
        fields.push(field);
    })
    setup = obj.setup != 0 ? ',setup: function(){' + obj.setup + '}' : '';
    return 'define("' + formName + '",["' + cc.map(function(c) { return 'components/' + c}).join('","') + '"], function(){return {dfe:[' + fields.join(',') + ']' + setup + '}})';
}
