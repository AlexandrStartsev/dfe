/* 
 * @param {String} path 
 * @returns {String|Array|JsonProxy}
 */
$$ = function (path) {
    return 'abc';
}
for(i in JsonProxy.prototype)
    $$[i] = JsonProxy.prototype[i];
$$.control = { notifications: [] };
$$.form = new DfeForm();
$$.form.setup();

$$.runtime = new DfeRuntime();

/* Feeds render function of a respective component;
 * @param value to be passed to render function
 */
$$.result = function (value) {};
$$.error = function (errorText) {};
$$.events = [{action: "a"}];

get($$),
set($$, value),
validate($$),
attr($$)


