var _isIE7 = (navigator.appVersion.indexOf("MSIE 7.") != -1);

function _setAttribute(node, name, value) { 
    if(value && value != 0) { _isIE7 ? $(node).attr(name, value) : node.setAttribute(name, value); return true; } else node.removeAttribute(name); 
}

function _addEventListener(node, eventname, handler, capture) {
	typeof node.addEventListener === 'function' ? node.addEventListener(eventname, handler, capture) : $(node).on(eventname, handler);
}

function _removeEventListener(node, eventname, handler, capture) {
	typeof node.removeEventListener === 'function' ? node.removeEventListener(eventname, handler, capture) : $(node).off(eventname, handler);
}

function getQuoteFormName(arf) { return arf.policy[0].formname; }

function dfe_navigate(form, action, arf) {
    form.policy_formname.value = getQuoteFormName(arf);
    if(action == 'next') { 
     	form.action.value = 'next_experimental';
        ajaxPost(arf, '/DfeServlet.srv?a=model', function(r){
            runtime.notifyControls(runtime.findControls(r.data.map(function(v) {return v.field})), 'validate');
            if(r.result) {
		        form.submit();
            } else {
            	document.getElementById('button_next').disabled = false;
                console.log(r);
                echo && alert( "Detected " + r.data.length + " error(s), F12 to see console" ); 
            }
        }, function() { document.getElementById('button_next').disabled = false; });
    }
}

// support for nav tab
var DFE = DFE || {};
DFE.nav = function () {
    var postForm = function (form, formName) {
            form.action.value = 'load';
            form.policy_formname.value = formName;
            form.submit();
        },
        backNav = function (form, formName) {
            form.action.value = 'back';
            form.policy_formname.value = formName;
            form.submit();
        },
        reloadQuote = function (form, formName) {
            form.action.value = 'reload';
            form.policy_formname.value = formName;
            form.submit();
        },
        submitForm = function (form) {
        	arf() ? dfe_navigate(form, 'next', arf()) : document.getElementById('button_next').disabled = false; 
        };
    
    return {
        postForm:      postForm,
        backNav:       backNav,
        reloadQuote:   reloadQuote,
        submitForm:    submitForm
    };
} ();

// ############ polyfill for Array.*, Map and Set
Array.isArray || (Array.isArray = function(o) { return o instanceof Array })
Array.prototype.forEach || (Array.prototype.forEach = function(f, a) { for(var i = 0; i < this.length; i++) f.call(a, this[i], i, this) })
Array.prototype.indexOf || (Array.prototype.indexOf = function(e) { var i=this.length-1; for(;i>=0 && this[i] != e;i--); return i; })
Array.prototype.filter || (Array.prototype.filter = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) f.call(a, this[i], i, this) && r.push(this[i]); return r } )
Array.prototype.map || (Array.prototype.map = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) r.push(f.call(a, this[i], i, this)); return r } )
Array.from || (Array.from = function(s) { 
    var r = [], o;
    Symbol && Symbol.iterator && (typeof s[Symbol.iterator] === 'function') && (s=s[Symbol.iterator]());
    if(typeof s.next === 'function') 
        while(!(o=s.next()).done) 
            r.push(o.value); 
    else 
        s.forEach(function(e) { r.push(e); } ); 
    return r; 
})

var Symbol = Symbol || {}
Symbol.iterator || (Symbol.iterator='Symbol(Symbol.iterator)')

var Map = Map || (
Map = function(i) { this.size = 0; i && Array.from(i).forEach(function(a) { a=Array.from(a); this.set(a[0], a[1]) }, this) },
Map.prototype.clear = function() { delete this.head; this.size = 0; },
Map.prototype[Symbol.iterator] = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: [this.pos.key, this.pos.value], done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Map.prototype.keys = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.key, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Map.prototype.values = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.value, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},        
Map.prototype.entries = Map.prototype[Symbol.iterator],
Map.prototype.set = function(k,v) {
    if(!this.head) {
        this.head = {key: k, value: v};
        this.size++;
    } else {
        if(this.head.key == k) {
            this.head.value = v;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k; h=h.next) ;
            if(!h.next) {
                h.next = {key: k};
                this.size++;
            }
            h.next.value = v;
        }
    }
    return this; 
},
Map.prototype['delete'] = function(k) {
    if(this.head) {
        if(this.head.key == k) {
            this.head = this.head.next;
            this.size--;
            return true;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k ; h=h.next);
            if(h.next) {
                h.next = h.next.next;
                this.size --;
                return true;
            }
        }
    }
    return false;
},
Map.prototype.get = function(k) {
    var h = this.head;
    for(; h; h=h.next) 
        if(h && h.key == k) return h.value;
},
Map.prototype.has = function(k) { return typeof this.get(k) !== 'undefined'; },
Map.prototype.forEach = function(f, a) {
    var h = this.head;
    for(; h; h=h.next) 
        f.call(a, h.value, h.key, this);
},
Map.prototype.keys = function() { var ret = []; for(var h = this.head; h; h=h.next)  ret.push(h.key);  return ret;},
Map.prototype.values = function() { var ret = []; for(var h = this.head; h; h=h.next)  ret.push(h.value);  return ret;},
Map)

var Set = Set || (Set = function(i) { this.size = 0; i && Array.from(i).forEach(function(v) { this.add(v) }, this) },
Set.prototype[Symbol.iterator] = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.key, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Set.prototype.keys = Set.prototype[Symbol.iterator],
Set.prototype.entries = Set.prototype[Symbol.iterator],
Set.prototype.add = function(k) {
    if(!this.head) {
        this.head = {key: k};
        this.size++;
    } else {
        if(this.head.key != k) {
            var h = this.head;
            for(; h.next && h.next.key != k; h=h.next) ;
            if(!h.next) {
                h.next = {key: k};
                this.size++;
            }
        }
    }
    return this; 
},
Set.prototype.clear = function() { delete this.head; this.size = 0; },
Set.prototype['delete'] = function(k) {
    if(this.head) {
        if(this.head.key == k) {
            this.head = this.head.next;
            this.size--;
            return true;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k ; h=h.next);
            if(h.next) {
                h.next = h.next.next;
                this.size --;
                return true;
            }
        }
    }
    return false;
},
Set.prototype.forEach = function (f, a) {
    for(var h = this.head; h; h=h.next) 
        f.call(a, h.key, this);
},
Set.prototype.has = function(k) { 
    for(var h = this.head; h; h=h.next) 
        if(h && h.key == k) return true;
    return false;
},
Set)

//###### JSON polyfill
window.JSON || (window.JSON = {
    parse: function(sJSON) { return eval('(' + sJSON + ')'); },
    stringify: (function () {
      var toString = Object.prototype.toString;
      var hasOwnProperty = Object.prototype.hasOwnProperty;
      var isArray = Array.isArray || function (a) { return toString.call(a) === '[object Array]'; };
      var escMap = {'"': '\\"', '\\': '\\\\', '\b': '\\b', '\f': '\\f', '\n': '\\n', '\r': '\\r', '\t': '\\t'};
      var escFunc = function (m) { return escMap[m] || '\\u' + (m.charCodeAt(0) + 0x10000).toString(16).substr(1); };
      var escRE = /[\\"\u0000-\u001F\u2028\u2029]/g;
      return function stringify(value) {
        if (value == null) {
          return 'null';
        } else if (typeof value === 'number') {
          return isFinite(value) ? value.toString() : 'null';
        } else if (typeof value === 'boolean') {
          return value.toString();
        } else if (typeof value === 'object') {
          if (typeof value.toJSON === 'function') {
            return stringify(value.toJSON());
          } else if (isArray(value)) {
            var res = '[';
            for (var i = 0; i < value.length; i++)
              res += (i ? ', ' : '') + stringify(value[i]);
            return res + ']';
          } else if (toString.call(value) === '[object Object]') {
            var tmp = [];
            for (var k in value) {
              // in case "hasOwnProperty" has been shadowed
              if (hasOwnProperty.call(value, k))
                tmp.push(stringify(k) + ': ' + stringify(value[k]));
            }
            return '{' + tmp.join(', ') + '}';
          }
        }
        return '"' + value.toString().replace(escRE, escFunc) + '"';
      };
    })()
  });

/*
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" type="text/css" rel="stylesheet">
css:
.server-error-dlg {
    z-index: 1001;
}

.server-error-dlg:focus-within{
    z-index: 1002;
}

.server-error-dlg > div.ui-dialog-content {
    white-space: pre-wrap;
    color: red;
    font-size: 13px;
}

.server-error-dlg span.ui-dialog-title {
    color: black;
}

*/

function displayServerError(text) {
    require(['jquery-ui'], function() {
        console.error(text),
        $('<div>').text(text).dialog({ 
            classes: {'ui-dialog': 'server-error-dlg'}, 
            title: 'Server error', 
            width: 700, 
            height: 400, 
            close: function() { 
                $(this).dialog('destroy') 
            } 
        }).focus()
    });
}