function getContainerLayout(proxy) {
    var par = proxy.get('.parent_px')
    return par!=0 && par.withListener(proxy.listener).get('.component').layout;
}

function DfeEditor(dfe_proxy, components, listener) {
    DfeForm.call(this, dfe_proxy, components, listener);
}

DfeEditor.prototype = new DfeForm();
DfeEditor.prototype.constructor = DfeEditor;

DfeEditor.prototype.changeParent = function(proxy, newparentname) {
    if(proxy) {
        proxy.set('dfe.parent');
        this.fixParent(proxy);
        proxy.set('dfe.parent', newparentname);
        this.fixParent(proxy);
    }
}

DfeEditor.prototype['delete'] = function(proxy) {
    if(proxy) {
        proxy.set('dfe.parent');
        this.fixParent(proxy);
        proxy.detach();
    }
}

DfeEditor.prototype.changeTPos = function(proxy, w, h, n, s) {
    if(proxy) {
        var tpos = _extend(proxy.get('.tpos'), {});
        w != undefined && (tpos.w = w), h != undefined && (tpos.h = h), n != undefined && (tpos.n = n), s != undefined && (tpos.s = s);
        proxy.set('.tpos', tpos);
    }
}

DfeEditor.prototype.changeName = function(proxy, value) {
    var oldName = proxy.get('.name');
    if( value != '' && ! proxy.get('dfe').some(function(px) { return px.get('.name') == value; }) ) {
        proxy.set('.name', value);
        proxy.get('.children').forEach(function(cr) { cr.get('dfe.children.proxy').withListener(cr.listener).set('.parent', value) });
        var parent = proxy.get('.parent_px')
        if(parent !=0) {
            parent.withListener(proxy.listener).get('.children').forEach(function (cf){
                if(cf.get('dfe.children.name') == oldName) 
                    cf.set('dfe.children.name', value);
            });
        }
    } else {
        proxy.set('dfe.name', value);
        proxy.set('dfe.name', oldName);
    }
}

DfeEditor.prototype.changeType = function(proxy, value) {
    proxy.set('.type', value);
    proxy.set('.component', proxy.get('.form').components.get(value));
    proxy.get('.children').forEach(function(cr) { 
        this.changeParent(cr.get('.proxy').withListener(cr.listener), proxy.get('.name')); 
    }, this);
}

DfeEditor.prototype.removeField = function(proxy) {
    this.changeParent(proxy, undefined);
    proxy.detach();
}

DfeEditor.prototype.forPrinting = function(dfe_proxy) {
    var ret = {dfe : [], setup : dfe_proxy.get('setup')};
    dfe_proxy.get('dfe').forEach(function(px) {
        var my = {}
        for(i in px.data) {
            if(i != 'children' && i != 'parent_px' && i != 'component' && i != 'form' && i != 'set' && i != 'get' && i != 'atr' && i != 'val')
                my[i] = px.data[i];
        }
        ret.dfe.push(my);
    });
    return ret;
}

DfeEditor.prototype.getChildrenRecursively = function (parent, subChildren) {
    var ret = [];
    parent.get('.children').forEach(function(o) {
        ret.push(o = o.get('.proxy').withListener(o.listener));
        if(subChildren == 'Y') ret = ret.concat(this.getChildrenRecursively(o, subChildren));
    }, this);
    return ret;
}

DfeEditor.prototype.getFieldList = function (proxy, childrenOf, hierarchyOf, subChildren) {
    var arr = proxy.get('dfe'); // todo: if px.get('.name') == childrenOf / == hierarchyOf not found (name changed)
    if( childrenOf != 0 && childrenOf != 'All' ) {
        var parent = arr.filter(function(px) { return px.get('.name') == childrenOf } )[0];
        return [parent].concat(this.getChildrenRecursively(parent, subChildren));
    }
    if( hierarchyOf != 0 && hierarchyOf != 'All' ) {
        var ret = [], l = proxy.listener;
        for(var px = arr.filter(function(px) { return px.get('.name') == hierarchyOf } )[0]; px != 0; px = px.get('.parent_px'))
            ret.unshift(px);
        return ret;
    }
    return arr;
}

DfeEditor.prototype.pushCSStoPage = function(css_text, id) {
    var doc = (window.opener == null ? document : window.opener.document), ui;
    if( (ui = doc.getElementById(id)) == undefined ) {
        doc.getElementsByTagName('head')[0].innerHTML += '<style id="' + id + '" type="text/css"></style>';
        ui = doc.getElementById(id);
    }
    ui.innerHTML = css_text;
}

DfeEditor.prototype.moveField = function(proxy, newpos) {
    var idx = proxy.index();
    if(idx != newpos && idx != 0) {
        var data = proxy.get('..').data, pC = proxy.get('.parent_px').get('.children.name');
        if(newpos<1) newpos = 1;
        if(newpos>= data.dfe.length) newpos = data.dfe.length - 1;
        data.dfe.splice(newpos, 0, data.dfe.splice(idx,  1)[0]);
        proxy.listener.notify(data, 'dfe');
        proxy.get('..dfe').forEach(function(px){ (pC.indexOf(px.get('.name')) != -1) && this.fixParent(px); }, this); 
    }
}

DfeEditor.prototype.validateTarget = function($$) {
    var tr = $$.runtime.target_runtime;
    var arf = tr.model_proxy.data;
    var dfe = this.forPrinting($$.runtime.model_proxy);
    var r = JSON.parse(DfeValidator.validateStringify(JSON.stringify(arf), JSON.stringify(dfe)));
    alert( r.result ? "Validated" : "Invalid: " + r.data.length + " error(s)"); 
    tr.notifyControls(tr.findControls(r.data.map(function(v) {return v.field})), 'validate');
}

DfeEditor.prototype.storeInSession = function($$) {
    var form = $$.runtime.target_runtime.form.formName;
    var dfe = this.forPrinting($$.runtime.model_proxy);
    ajaxPost(dfe, '/DfeServlet.srv?a=dfe&p=' + form, function(d, s){ alert(s) }, function(d, s) { alert(s) });
}

DfeEditor.prototype.restartTarget = function ($$) {
    var rt = $$.runtime.target_runtime, s = rt.form.dfe_proxy.data.setup;
    if(s) 
        try { 
            s && Function(s).call(rt.form) ;
        } catch (e) { console.error(e) }
    rt.restart();
}

DfeEditor.prototype.setTargetDfe = function($$, dfe) {
    var tr = $$.runtime.target_runtime;
    var dfe_proxy = new JsonProxy(dfe, [], [], $$.listener);
    var form = new tr.form.constructor(dfe_proxy, Array.from(tr.form.components.values()), $$.listener);
    form.formName = tr.form.formName;
    tr.setDfeForm(form);
    $$.runtime.setModel(form.getDfeArf());
}

DfeEditor.prototype.generateName = function(proxy) {
    var ns = new Set(proxy.get('dfe.name')), i;
    for(i = ns.size; ns.has('field-'+i); i++ ) {}
    return 'field-'+i;
} 

DfeEditor.prototype.highlightField = function(e, control) { 
    var rt = (control.model.runtime && control.model.runtime.target_runtime);
    if(!rt) return ;
    var cc, doc = rt.rootControl.ui.ownerDocument, clazz = '__marker__', ui, r, sp, hl = 'background: peru;'
                , body = doc.getElementsByTagName('body')[0]
                , mrk = doc.getElementsByClassName(clazz);
    for(var i = mrk.length; i>0; i--, mrk[i].parentElement.removeChild(mrk[i]));
    
    var dom = document.elementFromPoint(e.clientX, e.clientY), c, proxy;
    while(dom && !dom._dfe_) dom = dom.parentNode;
    if( dom && (c = dom._dfe_) && (proxy = c.model).get('.name') != 0 ) {
        if( e.type == 'mouseover' ) {
            do {
                if(rt.findControls(proxy.get('.name')).filter( function(c) { 
                    if( (ui = c.ui && c.ui.nodeName ? c.ui : c.mUI[0]).nodeName && (r = ui.getBoundingClientRect()) &&(r.x || r.width) ) {
                        body.appendChild(sp = doc.createElement('span'));
                        sp.setAttribute('style', 'position: absolute; z-index: 3000; opacity: 0.5; border-radius: 5px; ' + hl);
                        sp.setAttribute('class', '__marker__');
                        sp.style.top = (r.top - 3 + (doc.defaultView.scrollY||doc.defaultView.window.pageYOffset)) + 'px';
                        sp.style.left = (r.left - 4 + (doc.defaultView.scrollX||doc.defaultView.window.pageXOffset)) + 'px';
                        sp.style.width = (r.width + 10) + 'px'; 
                        sp.style.height = (r.height + 6) + 'px';
                        return true;
                    }
                }).length > 0 ) break; 
                hl = 'border: dashed; border-color: red;', proxy = proxy.get('.parent_px').withListener(proxy.listener);
            } while(proxy);
        }
    }
}

//require.config({ paths: { "ace": 'ace' } });
// little how-to: https://ace.c9.io/#nav=howto&api=virtual_renderer
// https://github.com/ajaxorg/ace
// https://github.com/ajaxorg/ace/wiki/Syntax-validation
//_addEventListener(window, 'load', function() {
require(['ace/ace'], function(ace) {
	window.aceEditor = ace.edit(document.createElement('div'));
	aceEditor.container.style.width = aceEditor.container.style.height = '100%';
	aceEditor.setTheme('ace/theme/eclipse');  //dawn, eclipse, iplastic, kuroir, textmate
	aceEditor.setShowPrintMargin(false);
	aceEditor.$blockScrolling = Infinity;
	aceEditor.commands.on('exec', function(e) {
	   e.command.name == 'Esc' && aceEditor.completer.popup && aceEditor.completer.popup.isOpen && e.stopPropagation();
	});
	//rt.session.setUseSoftTabs(true);
	// intellisense: https://stackoverflow.com/questions/26239090/javascript-intellisense-in-ace-editor
	ace.config.loadModule('ace/ext/tern', function () {
	            /* taken from http://sevin7676.github.io/Ace.Tern/demo.html#html */
	            /* http://ternjs.net/doc/manual.html#option_defs */
	            /* http://ternjs.net/doc/manual.html#plugins */    
	    aceEditor.setOptions({
	        enableTern: {
	            defs: ['browser', 'ecma5', 'jquery'], 
	            plugins: { 
	                doc_comment: { fullDocs: true } 
	            }, 
	           // useWorker: false, 
	            startedCb: function () {
                    $('script').each(function(){ 
                        if(this.src.match(/dfe-editor.js$/)) {
                            var url = this.src, src = ['ui-utils', 'dfe-core', 'extras', 'hints']; // $('script').each( ... )
                            $.when.apply($, src.map(function(s) { return $.get(url.replace(/dfe-editor/, s), 0, 0, 'text')})).done(function() {
                                for(i = 0; i < arguments.length; i++)
                                    aceEditor.ternServer.addDoc(src[i], arguments[i][0]);
                            });
                        }
                    })
	            },
	        },
	        enableSnippets: true,
	        enableBasicAutocompletion: true,
	    });
	});
});

//#######################  popup editor to edit code #############################
function formatCode(control, text, func) {
    if(text == 0 ) return '';
    return func && typeof func.name == 'string' ? (
            typeof func.of == 'string' ? func.of + '.prototype.' + func.name + ' = function() {\n\t' + text + '\n}' :
               'function ' + func.name + '(' + (func.args ? func.args.join(',') : '') + ') {\n\t' +
                (func.cmnt ? '/* ' + func.cmnt + ' */\n\t' : '') + ( func.ret && needsReturn(text) ? 'return ' : '') + text + '\n}') : text;
}

function tryExtractCode(control, text, func) {
    try {
        if(func) {
            var esprima = require('esprima'); 
            var b = esprima.parse(text).body, p, n;
            if( b.length != 1 || func.of && b[0].expression.left.type != 'MemberExpression' ||
            		!(func.of ? b[0].expression.right : b[0]).type.match(/Function.*ion/) ) throw 'illegal structure';
            for(p = text.indexOf('(')+1, n = 1; n; p++)
                n += (text.charAt(p) == '(' ? 1 : text.charAt(p) == ')' ? -1 : 0);
            text = text.substr(text.indexOf('{', p) + 1).replace(/^[\n\t ]*(\/\*[^]*\*\/)?[\n\t ]*/g, '').replace(/[\n\t ]*}[\n\t ]*$/g,'');
            func.ret && needsReturn(text.replace(/^return[\n\t ]+/, '')) && (text = text.replace(/^return[\n\t ]+/, ''));
        }
        control.notifications.push({ action : 'self' }); 
        control.store(control.model.runtime, text);
    } catch(e) { console.error(e), control.error || control.model.error('compilation error') }
}

function CEditCode() {this.name = 'editbox-code'; }
CEditCode.prototype = new CEditPopup();
CEditCode.prototype.constructor = CEditCode;
['func', 'lang', 'fontSize'].forEach(function(a) { CEditCode.prototype.skipattrs.add(a) });

CEditCode.prototype.updatePopupContent = function(control, data, attrs) {
    var rt = this.runtime(control);
    !(rt.ta && rt.ta.contains(control.ui.ownerDocument.activeElement)) && rt.session && rt.session.setValue(formatCode(control, data, attrs.ta.func));
}

CEditCode.prototype.getPopupUi = function(rtd, control) {
    var attrs = control.model.attrs, rt = this.runtime(control);
    if(!rt.session) { 
        rt.session = ace.createEditSession(formatCode(control, control.data, attrs.ta.func), 'ace/mode/' + (attrs.ta.lang||'javascript'));
        rt.session.on('change', function(e) { new Error().stack.indexOf('setValue') == -1 && tryExtractCode(control, rt.session.getValue(), attrs.ta.func) });
    }
    aceEditor.setSession(rt.session);
    return aceEditor.container;
}

CEditCode.prototype.onResize = function(control) { aceEditor.resize() }
CEditCode.prototype.getPopupActiveElement = function(control) { return aceEditor.renderer.textarea }
CEditCode.prototype.onClosePopup = function(control) {}
CEditCode.prototype.purge = function (runtime, control) { rt = this.runtime(control), rt.session && rt.session.destroy(); this.emptyUI(runtime, control); }
CEditCode.prototype.setPopupAttributes = function(rtd, control, attrs, errs) {
    CEditPopup.prototype.setPopupAttributes.call(this, rtd, control, attrs, errs);
    this.runtime(control).ta && (this.getPopupUi(rtd, control).style.fontSize = attrs.fontSize||'14px', aceEditor.resize());
}

typeof dfeComponents !== 'undefined' && dfeComponents.push(new CEditCode());
