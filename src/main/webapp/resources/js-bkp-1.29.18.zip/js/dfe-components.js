//#############################################################################

var _isIE7 = (navigator.appVersion.indexOf("MSIE 7.") != -1);

function _setAttribute(node, name, value) { 
    if(value && value != 0) { _isIE7 ? $(node).attr(name, value) : node.setAttribute(name, value); return true; } else node.removeAttribute(name); 
}

function _addEventListener(node, eventname, handler, capture) {
	typeof node.addEventListener === 'function' ? node.addEventListener(eventname, handler, capture) : $(node).on(eventname, handler);
}

function _removeEventListener(node, eventname, handler, capture) {
	typeof node.removeEventListener === 'function' ? node.removeEventListener(eventname, handler, capture) : $(node).off(eventname, handler);
}

function Component() { this.name = 'component'; }

Component.prototype.__inc_id = 1;
Component.prototype.getNextId = function() { return 'i' + (Component.prototype.__inc_id++); }
Component.prototype.isContainer = function () { return false; }
Component.prototype.skipattrs = new Set();
Component.prototype.toAttribute = new Set();

[   'tagname', 'hmodel', 'options', 'trigger', 'orientation', 'vstrategy', 'formatting',
    'default', 'display', 'focusnew', 'data', 'info', 'depend', 'errorwatch', 'events', 'ta', 
    'filter', 'order', 'offsetLeft', 'offsetTop', 'rowclass', 'rowstyle', 'colclass', 'colstyle',
    'rowclass$header', 'rowclass$footer', 'rowstyle$header', 'rowstyle$footer', 'haclass', 'nodollar',
    'skip', 'pattern', 'transform', 'hfield', 'tagname', 'eclass'
].forEach(function(a) { Component.prototype.skipattrs.add(a) }); 

['name', 'id', 'disabled', 'hidden', 'readonly', 'maxlength', 'placeholder', 'spellcheck', 'class', 'style'
].forEach(function(a) { Component.prototype.toAttribute.add(a) }); 

Component.prototype.setAttributesUI = function(rtd, ui, data, errs, attrs, events) { 
    for(var i in attrs) {
        if(! this.skipattrs.has(i)) {
            if( this.toAttribute.has(i) ) 
                _setAttribute(ui, i, attrs[i]);
            else
                if(i.indexOf('$')==-1) ui[i] = attrs[i]; 
        }
    }
}

Component.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) { 
    this.setAttributesUI(rtd, control.ui, data, errs, attrs, events);
}

Component.prototype.checkAttributes = function(control, newArrts, oldAttrs) { return true; }

Component.prototype.setParentNode = function(control, pnode) {
    if(pnode) {
        control.ui && pnode.appendChild(control.ui); 
        (control.mUI||[]).forEach(function(ui) {pnode.appendChild(ui)});
    } else 
        if(control.parentNode) {
            control.ui && control.parentNode.removeChild(control.ui); 
            (control.mUI||[]).forEach(function(ui) {control.parentNode.removeChild(ui)});
        }
    control.parentNode = pnode;
}

Component.prototype.emptyUI = function (runtime, control) {
    if(control.parentNode) {
        control.ui && control.parentNode.removeChild(control.ui); 
        (control.mUI||[]).forEach(function(ui) {control.parentNode.removeChild(ui)});
    }
    control.ui = 0, control.mUI = [];
}

Component.prototype.purge = function (runtime, control) { this.emptyUI(runtime, control); }

/* none - no validation. $$.error = ... is ignored on both client and server side. may be useful with ajaxFeed datasource
   default/clean - validate if previously errored or when 'validate' notification received
   followup - acts as 'clean' until first error (control.stickyError is undefined), then as 'notified' 
   notified - validate if previously errored or when notified (non-empty event queue)
   always - validate on every rendering cycle (including very first one, after creation)
   extras:
    - if 'disabled' word is added, control will validate as above even when attribute 'disabled' is set 
    //- if 'post' word is added, control will be notified with 'validate' event when any  additionally after 
 */
Component.prototype.doValidation = function(rtd, control, events, attrs) { 
    attrs || (attrs = {});
    var vs = (attrs.vstrategy||'').split(' ');
    if( vs.indexOf('none') != -1 ) return false;
    if( ( vs.indexOf('disabled') == -1 && attrs.disabled) || attrs.hidden ) return false;
    if( vs.indexOf('always') != -1 ) return true;
    if( ( vs.indexOf('notified') != -1 || vs.indexOf('followup') != -1 && control.stickyError )
               && (control.error || events.length > 1 || events.length && events[0].action != 'init') ) return true;
    //if(attrs.errorwatch && control.stickyError && events.filter(e => ['errorwatch'].indexOf(e.action)!=-1) != 0 ) return true;
    return control.error || events.filter(function(e) { return 'validate' == e.action }) != 0; 
}

Component.prototype.appendError = function(control, ui, errs, attrs, keepmUI) { 
    if(ui) {
        while( control.mUI && control.mUI.length > (keepmUI||0) ) ui.removeChild(control.mUI.pop());
        if( errs ) {
            var e = document.createElement('label'); 
            e.setAttribute('class', attrs.eclass || 'dfe-error');
            e.setAttribute('style', attrs.estyle); // || 'color: #DB1260; font-weight: bold; display: block;'
            e.innerHTML = errs;
            ui.appendChild(e);
            (ui == control.parentNode) && (control.mUI||(control.mUI = [])).push(e);
        }
    }
}
Component.prototype.store = function(runtime, value) { runtime.store(this, value); }
Component.prototype.render = function(runtime, control, model_proxy, errs, attrs, events) { control.ui = 1; }
Component.prototype.layout = 'none';
Component.prototype.runtime = function(control) { return control.runtime || (control.runtime={}) }
Component.prototype.setEvents = function(rtd, ui, control, data, errs, attrs, events) {
    for(n in attrs.events) 
        (function(a, e) { 
            if(typeof e == 'function') {
                var nm = a, t = ui, id, i=a.indexOf('$'); 
                if(i != -1 && !isNaN(id=+a.substr(i+1)) && (id==0||control.mUI[id])) { t = id==0?control.ui:mUI[id-1]; nm=a.substr(0,i)}
                _addEventListener(t, nm, function(event) { return e(event, control) }, false);
            }
        })(n, attrs.events[n]);
} 
//#############################################################################
function CEditbox() {this.name = 'editbox'; }
CEditbox.prototype = new Component();
CEditbox.prototype.constructor = CEditbox;
CEditbox.patterning = function(v, p) { while(p && v != 0 && !(v.match(p) && v.match(p)[0] == v) ) v = v.substr(0, v.length-1); return v; }
CEditbox.formatting = function(value, format) { // aka XXX-XXX-XXXX or MM/DD/YYYY
    if(format && typeof value !== 'undefined') {
	    var ret = '', i, j, vn, vl, fn, fl;
        value = (Array.isArray(value) ? value[0] : value).toString().replace(/\W/g, '');
        for (i = 0, j = 0; i < format.length && j < value.length; i++) {
            vn = !(vl = value.charAt(j).match(/[A-Z]/i)) && !isNaN(parseInt(value.charAt(j)));
            fn = !(fl = format.charAt(i) == '_') && 'XdDmMyY9'.indexOf(format.charAt(i)) >= 0;
            if (fl && !vl || fn && !vn) break ;
            ret += fl && vl || fn && vn ? value.charAt(j++) : format.charAt(i);
        }
	    value = ret;
    }
    return value||'';
}

CEditbox.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(attrs.transform) {
        control.transform = [];
        attrs.transform.split('').forEach(function(s) { control.transform.push(s.charCodeAt(0)-(s.charCodeAt(0) > 57 ? 55 : 48)) });
    }
    control.pattern = attrs.pattern;
    control.formatting = attrs.formatting;
    if(!control.ui) {
        control.ui = document.createElement('input');
        control.parentNode && control.parentNode.appendChild(control.ui);
        control.ca = 0;
        _addEventListener(control.ui, 'keydown', function(e) {
        	var s = control.ui.selectionStart, v = control.ui.value, m; 
        	if((e.key == 'Backspace' || e.key == 'Delete' || e.key == 'Del') && control.formatting && v.length != control.ui.selectionEnd) {
                e.preventDefault();
                s && (control.ui.selectionEnd = --control.ui.selectionStart);  
            } 
            if(!e.key || e.key.length > 1 || e.ctrlKey) return ;
            if(control.formatting) {
                control.ca++;
                if(e.key == control.formatting[s]) { control.ui.selectionStart++; e.preventDefault(); return ; }
                while(control.formatting[s] && '_XdDmMyY9'.indexOf(control.formatting[s])==-1) s++;
                var ol = v.length, nl = CEditbox.formatting(v.substr(0, s) + e.key + v.substr(s + 1), control.formatting).length;
                if(s < ol && nl >= ol || s >= ol && nl > ol ) {
                    control.ui.value = control.ui.value.substr(0, s) + control.ui.value.substr(s + 1); 
                    control.ui.selectionEnd = s; 
                } else {
                    e.preventDefault();
                    return ;
                }
            }
            if(control.pattern) {
            	m = (v = control.ui.value.substr(0, s) + e.key + control.ui.value.substr(control.ui.selectionEnd)).match(control.pattern);
            	(!m || m[0] != v) && (control.ca--, e.preventDefault());
            }
        }, false);
        var store = function() { 
            var f = control.formatting, p = control.pattern, data = CEditbox.patterning(CEditbox.formatting(control.ui.value, f), p); 
            if(control.transform) { 
                var t = []; for(var i=0;i<control.transform.length; i++)
                    data.length > control.transform[i] && (t[i] = data.charAt(control.transform[i]));
                for(var i=0;i<t.length; i++) 
                    t[i] = t[i]||' ';
                data = t.join('');
            }
            control.notifications.push({ action : 'self' }); 
            control.store(rtd, data); 
        }
        _addEventListener(control.ui, attrs.trigger||'keyup', store, false);
        _addEventListener(control.ui, 'change', store, false);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    Array.isArray(data) && (data=data[0]), data || (data=''), data = data.toString();
    if(control.transform) { 
        var t = []; for(var i=0;i<data.length; i++) 
            control.transform.length > i && (t[control.transform[i]] = data.charAt(i));
        data = t.join('');
    }
    data = CEditbox.patterning(CEditbox.formatting(data, control.formatting), control.pattern);
    if(data != control.ui.value) {
        var v = control.ui.value, ss = control.ui.selectionStart;
        control.ui.value = data;
        if(control.formatting && ss >= control.ca && ss <= v.length && v != control.ui.value) {
           var over = control.formatting.substr(ss-control.ca, control.ca).replace(/[_XdDmMyY9]/g,'').length;
           control.ui.selectionEnd = control.ui.selectionStart = ss + over; 
        }
        control.ca = 0;
    }
    
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}

CEditbox.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) { 
    attrs.placeholder = attrs.disabled ? '' : control.formatting || attrs.placeholder;
    Component.prototype.setAttributes.call(this, rtd, control, data, errs, attrs, events);
}

CEditbox.prototype.appendError = function(control, ui, errs, attrs) {
    if(attrs.eclass) 
        _setAttribute(control.ui, 'class', (attrs['class']||'') + (errs ? ' ' + attrs.eclass : ''));
    else 
        Component.prototype.appendError.call(this, control, ui, errs, attrs);
}
//#############################################################################
function CEditboxD() {this.name = 'editbox-$'; }
CEditboxD.prototype = new CEditbox();
CEditboxD.prototype.constructor = CEditboxD;
CEditboxD.formatting = function(v, n, l) {
	do {
		v = (n?'':'$') + v.replace(/[^\d]/g,'').replace(/(\d)(?=(\d{3})+$)/g, '$1,');
	} while(l && v.length > l && (v=v.substr(0, v.length-1)));
	return v;
}  
	
CEditboxD.prototype.render = function (rtd, control, data, errs, attrs, events) {
    control.maxlength = attrs.formatting && attrs.formatting.length;
    control.nodollar = attrs.formatting && attrs.formatting.charAt(0) != '$';
    if(!control.ui) {
        control.ui = document.createElement('input');
        control.parentNode && control.parentNode.appendChild(control.ui);
        _addEventListener(control.ui, 'keydown', function(e) {
            var ml = control.maxlength < CEditboxD.formatting(control.ui.value + '1', control.nodollar, 99).length;
	        if(e.key == ',' && control.ui.value.charAt(control.ui.selectionStart) == ',') control.ui.selectionStart++;
	        !e.ctrlKey && e.key && e.key.length == 1 && control.ui.selectionStart == control.ui.selectionEnd && (e.key < '0' || e.key > '9' || ml) && e.preventDefault();
        }, false);
        var store = function() { 
            var v = CEditboxD.formatting(control.ui.value, control.nodollar, control.maxlength);
            control.notifications.push({ action : 'self' }); control.store(rtd, v.replace(/[^\d]/g,'')); 
        }
        _addEventListener(control.ui, attrs.trigger||'keyup', store, false);
        _addEventListener(control.ui, 'change', store, false);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    Array.isArray(data) && (data=data[0]);
    if(typeof data == 'string' || typeof data == 'number') {
        var ss = control.ui.selectionStart, ov = control.ui.value, nv = CEditboxD.formatting(data, control.nodollar, control.maxlength), o = 0;
        if(ov != nv) {
        	control.ui.value = nv;
        	if(control.ui == document.activeElement) {
        		for(i=0;i<ss;i++) (nv.charAt(i) == ',' || nv.charAt(i) == '$') && o++, (ov.charAt(i) == ',' || ov.charAt(i) == '$') && o--;
            	control.ui.selectionStart = control.ui.selectionEnd = ss + o - (ov.charAt(ss) == ',' && nv.charAt(ss + o - 1) == ',' ? 1 : 0);
        	}
        }
    } else control.ui.value = '';
    
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}
//#############################################################################
function CDropdown (){ this.name = 'dropdown'; }
CDropdown.prototype = new Component();
CDropdown.prototype.constructor = CDropdown;

    // we assume {data.items} = [{value, description}] to be array of items and {data.value} to be one of those (or be something third if not selected)
CDropdown.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('select');
        control.parentNode && control.parentNode.appendChild(control.ui);
        _addEventListener(control.ui, 'change', function(e){
            control.store(rtd, control.ui.options[control.ui.selectedIndex].value);
        }, true);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    //while (control.ui.firstChild) control.ui.removeChild(control.ui.firstChild);
    var s = 0, i = 0, opt, d = [];
    attrs['default'] && (!Array.isArray(attrs['default']) || (attrs['default']={value: attrs['default'], description: 'Please select...'})) && d.push(attrs['default']);
    data && Array.isArray(data.items) && (d = d.concat(data.items));
    //var html = [];
    var currentNode = control.ui.firstChild;
    d.forEach(function(v) {
        currentNode || control.ui.appendChild(currentNode = document.createElement('option'));
        if(typeof v == 'string' || typeof v == 'number') {
            currentNode.text = currentNode.value = v;
            if(data.value == v) s = i;
        } else {
            currentNode.value = v.value;
            currentNode.text = (v.description || v.value);
            if(data.value == v.value) s = i;
        }
        i++; currentNode = currentNode.nextSibling;
    });
    for(; currentNode; currentNode = currentNode.nextSibling) control.ui.removeChild(currentNode);
    control.ui.selectedIndex = s; 
    //var so = control.ui.options[control.ui.selectedIndex]; attrs.default || so && control.store(rtd, so.value);
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}
//#############################################################################
function CButton(){ this.name = 'button'; }
CButton.prototype = new Component();
CButton.prototype.constructor = CButton;
            
CButton.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('input');
        control.ui.setAttribute('type', 'button');
        _addEventListener(control.ui, 'click', function(e){control.store(rtd, control.ui.value);}, true);
        control.parentNode && control.parentNode.appendChild(control.ui);
    }
    control.ui.value = data;
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}

CButton.prototype.appendError = function(control, parentNode, errs, attrs) {
	attrs.estyle ? _setAttribute(control.ui, 'style', (attrs.style||'') + ';' + (errs && attrs.estyle || '')) : Component.prototype.appendError.call(this, control, parentNode, errs, attrs);
}
//#############################################################################
function CContainer() { this.name = 'container'; }
CContainer.prototype = new Component();
CContainer.prototype.constructor = CContainer;
CContainer.prototype.layout = 'tpos';
CContainer.prototype.isContainer = function () { return true; }
CContainer.prototype.runtime = function(control) {
    return control.runtime || (control.runtime = { fieldData: [], allocs : new Map() }); 
}

CContainer.prototype.emptyUI = function(rtd, control) {
    Component.prototype.emptyUI.call(this, rtd, control);
    var rt = this.runtime(control);
    rt.allocs = new Map();
    delete rt.headAlloc;
    delete rt.footAlloc;
}

CContainer.prototype.buildFieldData = function(control, previousData, attrs) {
    var l = control.field.listener, ret = [], d, pd, tpos, i=0, cls, nm; 
    previousData = previousData||[];
    ret.match = true, ret.attrs = attrs;
    (l.get(control.field.data, 'children')||[]).forEach(function(cf) {
        cf=cf.proxy, tpos = l.get(cf.data, 'tpos') || {}, cls=l.get(cf.data, 'class');
    	if(attrs.skip && attrs.skip.indexOf(l.get(cf.data, 'name')) != -1) return ;
        tpos = {w: tpos.w > 1 && tpos.w, h: tpos.h > 1 && tpos.h, n: tpos.n=='Y', s: tpos.s }
        ret.push(d = { field: cf, clazz: (typeof cls == 'string' ? cls : ''), pos: tpos });
        pd = previousData[i++]||false;
        ret.match = ret.match && pd && d.clazz == pd.clazz && d.field.data == pd.field.data && tpos.s == pd.pos.s && tpos.w == pd.pos.w && tpos.h == pd.pos.h && tpos.n == pd.pos.n;
    });
    ret.match = ret.match && ret.length == previousData.length; // && this.checkAttributes(control, attrs, previousData.attrs);
    return ret;
}

CContainer.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
    var ret = { nodes: [], rows: [] }, td, tr, ib = nextAllocs && nextAllocs.rows[0];
    fieldData.forEach(function(fd) {
        if(fd.pos.n || !tr) {
            ui.insertBefore(tr = document.createElement('tr'), ib||null);
            ret.rows.push(tr);
        }
        ret.nodes.push(td = document.createElement(fd.clazz == '' ? 'td' : 'th'));
        td.setAttribute('valign', fd.clazz == '' ? 'top' : 'middle');
        tr.appendChild(td);
        fd.pos.w && td.setAttribute('colSpan', fd.pos.w);
        fd.pos.h && td.setAttribute('rowSpan', fd.pos.h);
        fd.pos.s && td.setAttribute(fd.pos.s.charAt(0) == '-' ? 'class' : 'style', fd.pos.s);
    }); 
    return ret;
}

CContainer.prototype.positionChildren = function(rtd, control, allocs, fieldData, rowData) {
    var children = rowData ? control.children.get(rowData) : control.fixedChildren, rt = this.runtime(control), i = 0;
    fieldData.forEach(function(fd) {
        var cc = children.get(fd.field.data);
        cc.component.setParentNode(cc, allocs.nodes[i++]);
    });
}

CContainer.prototype.render = function(rtd, control, data, errs, attrs, events) {
    if( ! (this.runtime(control).fieldData = this.buildFieldData(control, this.runtime(control).fieldData, attrs)).match ) {
        this.emptyUI(rtd, control);
    }
    if(!control.ui) {
        this.renderFx(rtd, control, data, errs, attrs, events);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    this.processRows(rtd, control, attrs, data || [], events);
    this.setAttributes(rtd, control, data, errs, attrs, events);
}

CContainer.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) {
    Component.prototype.setAttributes.call(this, rtd, control, data, errs, attrs, events);
    var rt = this.runtime(control), ha = rt.headAlloc, fa = rt.footAlloc, body = rt.allocs;
    ha && ha.rows.forEach(function(r) { _setAttribute(r, 'class', attrs['rowclass$header']); _setAttribute(r, 'style', attrs['rowstyle$header']); });
    fa && fa.rows.forEach(function(r) { _setAttribute(r, 'class', attrs['rowclass$footer']); _setAttribute(r, 'style', attrs['rowstyle$footer']); });
    body && body.forEach(function (aa) { aa.rows.forEach(function(r) { _setAttribute(r, 'class', attrs.rowclass); _setAttribute(r, 'style', attrs.rowstyle); })});
}

CContainer.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
    control.ui = document.createElement('table');
    _isIE7 && control.ui.appendChild(control.ui_tbody = document.createElement('tbody'));
    control.parentNode && control.parentNode.appendChild(control.ui);
    var rt = this.runtime(control), elem;
    var hf = rt.fieldData.filter(function(fd) { return fd.clazz!='' && fd.clazz!='footer' });
    var ff = rt.fieldData.filter(function(fd) { return fd.clazz=='footer' });
    if(hf.length > 0) {
        control.ui.appendChild(elem = document.createElement('thead'));
        this.positionChildren(rtd, control, this.headAlloc = this.allocateNodes(control, elem, attrs, hf), hf);
    }
    if(ff.length > 0) {
        control.ui.appendChild(elem = document.createElement('tfoot'));
        this.positionChildren(rtd, control, this.footAlloc = this.allocateNodes(control, elem, attrs, ff), ff);
    }
}

CContainer.prototype.processRows = function(rtd, control, attrs, newRows, events) {
    var rt = this.runtime(control), newAllocs = new Map(), oldAllocs = rt.allocs, or = [], fieldData = rt.fieldData.filter(function(fd) {return fd.clazz=='';});
    oldAllocs.forEach(function(v,k){or.push(k)});
    var nr = this.orderFilter(rtd, control, attrs, newRows, events);
    for(var i = 0, j = 0; i < nr.length || j < or.length; ) {
        if(i == nr.length) {
            this.removeDataRow(rtd, control, oldAllocs, or[j++], newAllocs);
            continue ;
        }
        if(j == or.length) {
            this.insertRowBefore(rtd, control, attrs, nr[i++], newAllocs, fieldData, rt.footAlloc);
            continue ;
        }
        if(nr[i] != or[j]) { 
            var nn= nr[i+1], on = or[j+1];
            if(nn && nn == or[j])  
                this.insertRowBefore(rtd, control, attrs, nr[i++], newAllocs, fieldData, oldAllocs.get(or[j]));
            else 
                if( on == nr[i] )
                    this.removeDataRow(rtd, control, oldAllocs, or[j++], newAllocs);
                else 
                    this.replaceRow(rtd, control, nr[i++], newAllocs, fieldData, oldAllocs, or[j++]);
        } else { newAllocs.set(nr[i++], oldAllocs.get(or[j++])); }
    }
    rt.allocs = newAllocs;
}

CContainer.prototype.orderFilter = function(rtd, control, attrs, newRows, events) {
    if(typeof attrs.filter == 'function') {
        newRows = newRows.filter(attrs.filter);
    }
    if(Array.isArray(attrs.filter)) { 
        var s = new Set(); 
        attrs.filter.forEach(function(r) { s.add(r.data) });
        newRows = newRows.filter(function(px) {return s.has(px.data)});
    }
    return (typeof attrs.order == 'function' ? newRows.sort(attrs.order) : newRows).map(function(r) { return r.data; });
}

CContainer.prototype.insertRowBefore = function(rtd, control, attrs, nd, newAllocs, fieldData, oldAlloc) {
    var nal = this.allocateNodes(control, control.ui_tbody||control.ui, attrs, fieldData, oldAlloc);
    newAllocs.set(nd, nal);
    this.positionChildren(rtd, control, nal, fieldData, nd);
}

CContainer.prototype.removeDataRow = function(rtd, control, oldAllocs, od, newAllocs) {
    !newAllocs.get(od) && (prevChildren = control.children.get(od)) && prevChildren.forEach(function(c) {c.component.setParentNode(c)});
    oldAllocs.get(od).rows.forEach(function(r) { (control.ui_tbody||control.ui).removeChild(r) } );
}

CContainer.prototype.replaceRow = function(rtd, control, nd, newAllocs, fieldData, oldAllocs, od) {
    var oldAlloc = oldAllocs.get(od), pc = control.children.get(od), c;
    newAllocs.set(nd, oldAlloc);
    pc && !newAllocs.get(od) && fieldData.forEach(function(f) { var c = pc.get(f.field.data); c.component.setParentNode(c) }); //pc.forEach(function(c) {c.component.setParentNode(c)});
    this.positionChildren(rtd, control, oldAlloc, fieldData, nd);
}
//####################################################################################
function CDiv() {this.name = 'div'; }
CDiv.prototype = new CContainer();
CDiv.prototype.constructor = CDiv;
CDiv.prototype.layout = 'dpos';
CDiv.prototype.buildFieldData = function(control, previousData, attrs) {
    var l = control.field.listener, ret = [], pd, dp, dpos, i=0, cls, nm; 
    ret.match = true, ret.attrs = attrs;
    previousData = previousData||[];
    (l.get(control.field.data, 'children')||[]).forEach(function(cf) {
        cf=cf.proxy, dp = l.get(cf.data, 'dpos') || {}, cls = l.get(cf.data, 'class'), nm = l.get(cf.data, 'name'), dpos = {};
        if( attrs.skip && attrs.skip.indexOf(nm) != -1 ) return ;
        if( dp.colclass && dp.colclass != 0 ) dpos.colclass = dp.colclass;
        if( dp.colstyle && dp.colstyle != 0 ) dpos.colstyle = dp.colstyle;
        var d = { field: cf, clazz: (typeof cls == 'string' ? cls : ''), pos: dpos };
        if( nm == attrs.hfield ) {
            pd = previousData.headField;
            ret.headField = d;
        } else {
            pd = previousData[i++]||false;
            ret.push(d);
        }
        ret.match = ret.match && pd && d.clazz == pd.clazz && d.field.data == pd.field.data && dpos.colclass == pd.pos.colclass && dpos.colstyle == pd.pos.colstyle;
    });
    ret.match = ret.match && ret.length == previousData.length; // && this.checkAttributes(control, attrs, previousData.attrs);
    return ret;
}

CDiv.prototype.setAttributes = Component.prototype.setAttributes;

CDiv.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
    var ret = { nodes: [], rows: [] }, div, ib = nextAllocs && nextAllocs.rows[0];
    fieldData.forEach(function(fd) {
        ui.insertBefore(div = document.createElement('div'), ib||null);
        ret.rows.push(div);
        ret.nodes.push(div)
        fd.pos.colclass && div.setAttribute('class', fd.pos.colclass);
        fd.pos.colstyle && div.setAttribute('style', fd.pos.colstyle);
    }); 
    return ret;
}

CDiv.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
    control.ui = document.createElement('div');
    control.parentNode && control.parentNode.appendChild(control.ui);
    var rt = this.runtime(control), hf = rt.fieldData.filter(function(fd) { return fd.clazz!='' });
    hf.length > 0 && this.positionChildren(rtd, control, rt.headAlloc = this.allocateNodes(control, control.ui, attrs, hf), hf);
}
//####################################################################################
function CDivR() {this.name = 'div-r'; }
CDivR.prototype = new CDiv();
CDivR.prototype.setAttributes = CContainer.prototype.setAttributes;
CDivR.prototype.constructor = CDivR;
CDivR.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
    var ret = { nodes: [], rows: [] }, rdiv, div, ib = nextAllocs && nextAllocs.rows[0];
    ui.insertBefore(rdiv = document.createElement('div'), ib||null);
    ret.rows.push(rdiv);
    fieldData.forEach(function(fd) {
        rdiv.appendChild(div = document.createElement('div'));
        _setAttribute(div, 'class', fd.pos.colclass);
        _setAttribute(div, 'style', fd.pos.colstyle);
        ret.nodes.push(div);
    }); 
    return ret;
}
//#############################################################################
// show: 'always', 'hover', 'click'; 
// haclass = ...  
// 
// expand: 'left up'
function CMenu(){ this.name = 'menu'; }
CMenu.prototype = new CDivR();
CMenu.prototype.constructor = CMenu;
            
CMenu.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
    CDivR.prototype.renderFx.call(this, rtd, control, data, errs, attrs, events);
    var div = document.createElement('div'), headField = this.runtime(control).fieldData.headField, cc; //.field.data....| pos.colclass | ...
    if(headField && (cc = control.fixedChildren.get(headField.data))) {
        cc.container.setParentNode(cc, control.ui.appendChild(div));
        _setAttribute(div, 'class', headField.pos.colclass);
        _setAttribute(div, 'style', headField.pos.colstyle);
    }
}
//####################################################################################
function CTab() { this.name = 'tab-s'; }
CTab.prototype = new CDivR();
CTab.prototype.constructor = CTab;

CTab.prototype.render = function(rtd, control, data, errs, attrs, events) {
    CDivR.prototype.render.call(this, rtd, control, data, errs, attrs, events);
    var headAlloc = this.runtime(control).headAlloc.rows[0], rt = this.runtime(control), headField = rt.fieldData.headField;
    while(headAlloc.lastChild) headAlloc.removeChild(headAlloc.lastChild);
    if(headField) {
        control.children.forEach(function(fl, modelData){ 
            var c = fl.get(headField.field.data), div, span, pos = headField.pos;
            c.component.setParentNode(c, headAlloc.appendChild(div = document.createElement('div')));
            _setAttribute(div, 'class', (pos && pos.colclass||'') + (modelData == rt.activeTab && attrs.haclass ? ' ' + attrs.haclass : ''));
            _setAttribute(div, 'style', pos && pos.colstyle);
            _addEventListener(div, 'click', function(e) {
                if(modelData != rt.activeTab) { rt.activeTab = modelData; control.notifications.push({ action : 'self' }); }
            }, false);
        });
    }
}

CTab.prototype.orderFilter = function(rtd, control, attrs, newRows, events) {
    var l = control.model.listener, rt = this.runtime(control), nrS = new Set(), has, at = rt.activeTrack; rt.activeTrack = [];
    attrs.focusnew && events.forEach(function(e) { rt.activeTab = e.action == 'a' ? e.d1 : rt.activeTab });
    newRows.forEach(function(r) { nrS.add(r.data); has |= r.data == rt.activeTab });
    for(var i = 0; at && i < at.length; i++) nrS.has(at[i]) && rt.activeTrack.push(at[i]);
    has ? rt.activeTrack.push(rt.activeTab) : rt.activeTab = rt.activeTrack[rt.activeTrack.length - 1] || newRows.length && newRows[0].data;
    //newRows.filter(function(r) { return r.data == rt.activeTab}).length || (rt.activeTab = newRows.length ? newRows[0].data : 0);
    return rt.activeTab ? [rt.activeTab]:[];
}

CTab.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
    control.ui = document.createElement('div');
    control.parentNode && control.parentNode.appendChild(control.ui);
    this.runtime(control).headAlloc = { rows: [control.ui.appendChild(document.createElement('div'))] };
}

CTab.activeModel = function(control) {
    var ac = control.children.get(control.component.runtime(control).activeTab);
    ac = (ac && ac.values().next().value);
    return ac.model;
}
//####################################################################################
function CDivC() {this.name = 'div-c'; }
CDivC.prototype = new CDiv();
CDivC.prototype.constructor = CDivC;
CDivC.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
    var ret = { nodes: [], rows: [] };
    for(var columns = this.runtime(control).columns, i = 0; i < fieldData.length; i++) {
        var fd = fieldData[i], div = document.createElement('div');
        columns[i].insertBefore(div, nextAllocs && nextAllocs.nodes[i]||null);
        ret.rows.push(div);
        ret.nodes.push(div);
        fd.pos.colclass && div.setAttribute('class', fd.pos.colclass);
        fd.pos.colstyle && div.setAttribute('style', fd.pos.colstyle);
    } 
    return ret;
}

CDivC.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
    control.ui = document.createElement('div');
    control.parentNode && control.parentNode.appendChild(control.ui);
    var rt = this.runtime(control), fd = rt.fieldData, hf = fd.filter(function(fd) { return fd.clazz!='' }), elem;
    rt.columns = [];
    for(i = 0; i < Math.max(hf.length, fd.length - hf.length); i++) {
        rt.columns.push(elem = document.createElement('div')); control.ui.appendChild(elem);
    }
    hf.length > 0 && this.positionChildren(rtd, control, rt.headAlloc = this.allocateNodes(control, control.ui, attrs, hf), hf);
}

CDivC.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) {
    CDiv.prototype.setAttributes.call(this, rtd, control, data, errs, attrs, events);
    var rt = this.runtime(control);
    for(i = 0; i < rt.columns.length; i++) {
        _setAttribute(rt.columns[i], 'class', attrs['rowclass$'+i]||attrs['rowclass$header']);
        _setAttribute(rt.columns[i], 'style', attrs['rowstyle$'+i]||attrs['rowstyle$header']);
    }
}

CDivC.prototype.removeDataRow = function(rtd, control, oldAllocs, od, newAllocs) {
    var oldAlloc = oldAllocs.get(od), prevChildren = control.children.get(od);
    prevChildren && !newAllocs.get(od) && prevChildren.forEach(function(c) {c.component.setParentNode(c)});
    for(var columns = this.runtime(control).columns, i=0; i < oldAlloc.rows.length; i++)
        columns[i].removeChild(oldAlloc.rows[i]);
}
//####################################################################################
function CCheckbox() {this.name = 'checkbox'; }
CCheckbox.prototype = new Component();
CCheckbox.prototype.constructor = CCheckbox;
CCheckbox.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('input'); 
        control.mUI = [document.createElement('label')];
        control.ui.setAttribute('type', 'checkbox');
        if(control.parentNode) {
            control.parentNode.appendChild(control.ui);
            control.parentNode.appendChild(control.mUI[0]);
        }
        _addEventListener(control.ui, 'change', function(e){ control.store(rtd, control.ui.checked ? 'Y' : 'N')}, true);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    if(Array.isArray(data)) data = data[0];
    data || (data='N');
    control.ui.checked =  typeof data == 'object' ? (data.checked != 0 && 'Yy'.indexOf(data.checked) != -1) : ('Yy'.indexOf(data) != -1);
    control.mUI[0].innerText = data.text||'';
    
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs, 1);
}

//####################################################################################
// same structure as for dropdown, except we don't select first element if its value not equal to data.value
function CRadiolist(){ this.name = 'radiolist'; }
CRadiolist.prototype = new Component();
CRadiolist.prototype.constructor = CRadiolist;

CRadiolist.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('div');
        control.parentNode && control.parentNode.appendChild(control.ui);
        _addEventListener(control.ui, 'change', function(e){
            var selected = [], cc = control.ui.children;
            for(var i = cc.length - 1; i >= 0; i--)
                if(cc[i].checked) { selected = cc[i].value; break ; }
            control.store(rtd, selected);
        }, true);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    var orientation = attrs.orientation;
    if( orientation != 'horizontal') orientation = 'vertical';
    if(Array.isArray(data)) data = data[0];
    control.radioname || (control.radioname = this.getNextId());
    data || (data = control.data||{});
    typeof data == 'string' && (data = {value: data});
    if(!data.items) data.items =  [{value :'Y', description : 'Yes'}, {value :'N', description : 'No'}];
    var innerHTML = '', r;
    if(data.items) {
        //var id = this.getNextId()/*, reset = true*/;
        data.items.forEach( function(it) {
            r = document.createElement('input'); 
            r.setAttribute('type', 'radio'); 
            r.setAttribute('name', control.radioname); 
            r.setAttribute('value', it.value); 
            if(it.value == data.value) { /*reset = false;*/ r.setAttribute('checked', 'checked'); } 
            innerHTML += _isIE7 ? r.outerHTML.replace(' ', ' name="' + control.radioname + '" ') : r.outerHTML;
            r = document.createElement('label'); 
            r.innerHTML = (it.description == null ? it.value : it.description); 
            innerHTML += (r.outerHTML + (orientation == 'vertical' ? '</br>' : ''));
        });
        //if(data.items.length > 0 && reset) control.store(rtd, []);
    }
    control.ui.innerHTML = innerHTML;
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.ui, errs, attrs);
}
//####################################################################################   
function CLabel() {this.name = 'label'; }
CLabel.prototype = new Component();
CLabel.prototype.constructor = CLabel;

CLabel.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('label');
        control.parentNode && control.parentNode.appendChild(control.ui);
        _addEventListener(control.ui, 'click', function(e){control.store(rtd, 'clicked')});
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    control.ui.innerHTML = data;
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}
//####################################################################################
function CHtml() {this.name = 'html'; }
CHtml.prototype = new Component();
CHtml.prototype.constructor = CHtml;

CHtml.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('div');
        control.parentNode && control.parentNode.appendChild(control.ui);
    }
    control.ui.innerHTML = data;
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.ui, errs, attrs);
    this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
}
//####################################################################################

function CTextarea() {this.name = 'textarea'; }
CTextarea.prototype = new CEditbox();
CTextarea.prototype.constructor = CTextarea;

CTextarea.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('textarea');
        control.parentNode && control.parentNode.appendChild(control.ui);
        _addEventListener(control.ui, attrs.trigger||'keyup', function(e){ control.store(rtd, control.ui.value)});
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    control.ui.value == data || (control.ui.value = data);
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
}
//####################################################################################
function CEditPopup() {this.name = 'editbox-P'; }
CEditPopup.prototype = new CEditbox();
CEditPopup.prototype.constructor = CEditPopup;

CEditPopup.prototype.render = function (rtd, control, data, errs, attrs, events) {
    var rt = this.runtime(control), self = this;
    if(!control.ui) {
        control.ui = document.createElement('input');
        control.parentNode && control.parentNode.appendChild(control.ui);
    	_addEventListener(control.ui, 'focus', function(e) { self.showPopup(rtd, control) });
        _addEventListener(control.ui, 'click', function(e) { self.showPopup(rtd, control) });
        _addEventListener(control.ui, attrs.trigger || 'keyup', function(e) { control.currentValue === control.ui.value || control.store(rtd, control.ui.value) });
        _addEventListener(control.ui, 'keydown', function(e) { 
            (e.key == 'Esc' || e.key == 'Escape') && rt.ta && control.closePopup();
            e.key == 'Enter' && (e.preventDefault(), self.showPopup(rtd, control), self.getPopupActiveElement(control).focus());
            e.key == 'Tab' && rt.ta && (self.getPopupActiveElement(control).focus(), e.preventDefault());
        });
    }
    control.ui.value === data || (control.ui.value = data);
    control.currentValue = control.ui.value;
    this.setAttributes(rtd, control, data, errs, attrs, events);
    this.appendError(control, control.parentNode, errs, attrs);
    this.setPopupAttributes(rtd, control, attrs.ta||{}, errs);
    this.updatePopupContent(control, data, attrs);
}

CEditPopup.prototype.updatePopupContent = function(control, data, attrs) {
    var rt = this.runtime(control);
    rt.ta && rt.popup && !rt.ta.contains(control.ui.ownerDocument.activeElement) && (rt.popup.value == data || (rt.popup.value = data, rt.popup.selectionStart = rt.popup.selectionEnd = 0, rt.popup.scrollTop = 0));
}

CEditPopup.prototype.getPopupUi = function(rtd, control) {
    var attrs = control.model.attrs, rt = this.runtime(control), p = rt.popup;
    if(!rt.popup) { 
        rt.popup = p = control.ui.ownerDocument.createElement('textarea');
        _setAttribute(p, 'class', 'edit-popup-textarea');
        _addEventListener(p, attrs.trigger || 'keyup', function(){ 
            control.store(rtd, control.ui.value = p.value);
            control.currentValue = p.value;
        });
        _addEventListener(p, 'keydown', function(e) { 
            (e.key == 'Esc' || e.key == 'Escape') && (control.ui.focus(), control.closePopup()) 
            e.key == 'Tab' && (control.ui.focus(), e.preventDefault()); // ??
        });
    }
    return p;
}

CEditPopup.prototype.onResize = function(control) { }
CEditPopup.prototype.getPopupActiveElement = function(control) { 
    return this.runtime(control).popup 
}
CEditPopup.prototype.onClosePopup = function(control) {}
CEditPopup.prototype.purge = function (runtime, control) { control.closePopup && rt.ta && control.closePopup(); this.emptyUI(runtime, control); }

CEditPopup.prototype.showPopup = function(rtd, control) {
    var rt = this.runtime(control), scrollFollow, escUnf, doc = control.ui.ownerDocument, self = this;
    if(control.ui && !rt.ta) {
        this.createPopup(rtd, control);
        this.updatePopupContent(control, control.data, control.model.attrs);
        (scrollFollow = function() {
            var r = control.ui.getBoundingClientRect(), op = control.ui.offsetParent, wnd = doc.defaultView||window;
            rt.ta.style.display = (op.scrollTop > control.ui.offsetTop + control.ui.offsetHeight || op.scrollTop + op.clientHeight < control.ui.offsetTop + control.ui.offsetHeight) ? 'none' : '';
            rt.ta.style.top = (r.bottom + 2 + (wnd.scrollY||wnd.pageYOffset) + (rt.ta_t||0)) + 'px';
            rt.ta.style.left = (r.left + (wnd.scrollX||wnd.pageXOffset) + (rt.ta_l||0)) + 'px';
        })();
        for(var e = control.ui; e; e = e.parentElement) e.addEventListener('scroll', scrollFollow);
        var i = setInterval(function() {
            doc.activeElement != control.ui && !rt.resizeOngoing && ! rt.ta.contains(doc.activeElement) && control.closePopup();
        }, 30);
        control.closePopup = function() {
            for(var e = control.ui; e; e = e.parentElement) _removeEventListener(e, 'scroll', scrollFollow);
            _removeEventListener(self.getPopupActiveElement(control), 'keydown', escUnf);
            clearInterval(i);
            self.onClosePopup(control);
            rt.ta.remove();
            delete rt.ta;
        }
        _addEventListener(self.getPopupActiveElement(control), 'keydown', (escUnf = function(e) { 
            e.key == 'Escape' && !e.defaultPrevented && (control.ui.focus(), control.closePopup());
        }));
    }    
}

CEditPopup.prototype.createPopup = function(rtd, control) {
    var rt = this.runtime(control), doc = control.ui.ownerDocument, attrs = control.model.attrs, handle, self = this;
    rt.ta = doc.createElement('div'); 
    rt.ta.appendChild(this.getPopupUi(rtd, control));
    rt.ta.appendChild(handle = document.createElement('span'));
    doc.getElementsByTagName('body')[0].appendChild(rt.ta);
    this.setPopupAttributes(rtd, control, attrs.ta||{}, control.error);
    handle.setAttribute('class', 'ui-resizeable-handle-br');
    handle.addEventListener('mousedown', function(ie) {
        rt.resizeOngoing = 1;
        var ox = ie.screenX, oy = ie.screenY, w = rt.ta.offsetWidth, h = rt.ta.offsetHeight, move, up;
    	document.addEventListener('mousemove', move = function(me) {
            self.onResize(control);
    		rt.ta.style.width = rt.ta_w = (w + me.screenX - ox) + 'px';
    		rt.ta.style.height = rt.ta_h = (h + me.screenY - oy) + 'px';
            me.preventDefault(), window.getSelection().removeAllRanges();
    	});
    	document.addEventListener('mouseup', up = function(me) {
            rt.resizeOngoing = 0;
    		_removeEventListener(document, 'mousemove', move);
    		_removeEventListener(document, 'mouseup', up);
            self.getPopupActiveElement(control).focus();
    	});
    });
}

CEditPopup.prototype.setPopupAttributes = function(rtd, control, attrs, errs) {
    var rt = this.runtime(control);
    if(rt.ta) {
        var st = rt.ta.style, w = st.width||rt.ta_w, h = st.height||rt.ta_h, t = st.top, l = st.left;
        rt.ta_l = attrs.offsetLeft, rt.ta_t = attrs.offsetTop; 
        attrs['class'] = (attrs['class']||'') + (errs && attrs.eclass ? ' ' + attrs.eclass : '');
        this.setAttributesUI(rtd, rt.ta, control.data, errs, attrs, []);
        w && (st.width = w), h && (st.height = h), t && (st.top = t), l && (st.left = l);
    }
}
//####################################################################################
function CDivButton(){ this.name = 'div-button'; }
CDivButton.prototype = new Component();
CDivButton.prototype.constructor = CDivButton;
            
CDivButton.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(!control.ui) {
        control.ui = document.createElement('div');
        control.ui.appendChild(control.ui_text = document.createElement('label'));
        control.ui.appendChild(control.ui_error = document.createElement('label'));
        control.ui_text.setAttribute('class', 'div-button-text');
        control.ui_error.setAttribute('class', attrs.eclass || 'div-button-error'); 
        _addEventListener(control.ui, 'click', function(e){control.store(rtd, data)});
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        control.parentNode && control.parentNode.appendChild(control.ui);
    }
    var e = errs ? 'error' : '';
    if(control.ui_text.innerHTML != data) control.ui_text.innerHTML = data;
    if(control.ui_error.innerHTML != e) control.ui_error.innerHTML = e;
    this.setAttributes(rtd, control, data, errs, attrs, events);
}

//#############################################################################
function CMultiOption() {this.name = 'multioption'; }
CMultiOption.prototype = new Component();
CMultiOption.prototype.constructor = Component;
CMultiOption.prototype.render = function (rtd, control, data, errs, attrs, events) {
    if(Array.isArray(data.value)) data.value = data.value[0];
    if(control.ui != undefined) {
        this.emptyUI(rtd, control);
    }
    if( data != undefined && Array.isArray(data.options) ) {
        control.ui = document.createElement('div');
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        var select = new Set(), d, c, cc = [];
        (typeof data.value == 'string' ? data.value.split(';') : []).forEach(function(a) { select.add(a) });
        data.options.forEach(function (o) {
            control.ui.appendChild(d = document.createElement('div'));
            attrs.rowclass && d.setAttribute('class', attrs.rowclass);
            attrs.rowstyle && d.setAttribute('style', attrs.rowstyle);
            c = document.createElement('input');
            c.setAttribute('type', 'checkbox');
            d.appendChild(c);
            cc.push(c);
            c.checked = select.has(c.value = o.value);
            _addEventListener(c, 'change', function(e){
                control.store(rtd, cc.map(function(c) {return c.checked ? c.value : -1}).filter(function(v) {return v != -1}).join(';'));//cc.map(c => c.checked ? c.value : -1).filter(v => v != -1).join(';'));
            }, true);
            d.appendChild(c = document.createElement('label'));
            c.setAttribute('style', 'align-self: center;');
            c.innerText = (o.description != undefined ? o.description : o.value);
        }, this);
        control.parentNode && control.parentNode.appendChild(control.ui);
    }
}
//####################################################################################
function CTypeAheadA() {this.name = 'typeahead'; }
CTypeAheadA.prototype = new Component();
CTypeAheadA.prototype.constructor = Component;
CTypeAheadA.prototype.defaultOPTS = { source : {}, minLength: 1, maxItem: 8, maxItemPerGroup: 6, order: "asc", hint: true, searchOnFocus: true, debug: false, display: ['value','description'], template: '{{value}}: {{description}}', emptyTemplate: 'no result for {{query}}' }

CTypeAheadA.prototype.render = function (rtd, control, data, errs, attrs, events) {
    var rt = this.runtime(control), prevValue = '', self = this, s;
    if(!control.ui) {
        control.ui = document.createElement('div');
        control.ui.innerHTML = '<div class="typeahead__field"><span class="typeahead__query"><input type="search" autocomplete="off"/></span></div>';
        control.ui.setAttribute('class', 'typeahead__container');
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        rt.node = control.ui.firstChild.firstChild.firstChild;
        rt.memorizedItem = {};
        opts = _extend( attrs && attrs.options, this.defaultOPTS );
        opts.callback = { onClickAfter: function (node, a, item, event) { control.store(rtd, rt.memorizedItem = item) } }
        $(rt.node).typeahead( opts );
        control.parentNode && control.parentNode.appendChild(control.ui);
    }

    if( data && data.status != 'loading' ) {
        $(rt.node).prop('disabled', false);
        $(rt.node).typeahead('hideloading');
        if( rt.url != data.url ) {
            rt.url = data.url;
            $(rt.node).typeahead( { source : { data : data.items} }, 'reload' );
        }
        if(!data.found) {
            if(data.items.length > 0) {
                control.store(rtd, rt.memorizedItem = {});
                $(rt.node).typeahead('clean');
            } else {
                $(rt.node).prop('disabled', true).val('No results found for given criteria');
            }
        } else {
            var match = true; for(v in data.value) match = match && rt.memorizedItem[v] == data.found[v];
            match || (rt.memorizedItem = data.found);
            rt.node.value = rt.memorizedItem[attrs.display || 'description'];     //$(rt.node).typeahead('close');
        }
    } else 
        $(rt.node).typeahead('showloading');
}

CTypeAheadA.prototype.emptyUI = function(rtd, control) {
    if(control.ui) {
        $(rtd.node).typeahead( 'destroy' );
        Component.prototype.emptyUI(rtd, control);
    }
}

//####################################################################################
function CPlaceholder() {this.name = 'placeholder'; }
CPlaceholder.prototype = new Component();
CPlaceholder.prototype.constructor = CPlaceholder;
CPlaceholder.prototype.keepmUI = true;
CPlaceholder.prototype.render = function (rtd, control, data, errs, attrs, events) {
    var tagname = attrs.tagname || 'div', pp = control.parentNode && control.parentNode.parentNode;
    control.ui = 1;
    this.emptyUI(rtd, control);
    data = Array.isArray(data) ? data.length : data;
    for(i=0; i<data; i++) {
        pp && pp.insertBefore(control.mUI[i] = document.createElement(tagname), control.parentNode.nextSibling||null);
        this.setAttributesUI(rtd, control.mUI[i], data, errs, attrs, events);
    }
}
CPlaceholder.prototype.setParentNode = function(control, pnode) {
    if(pnode)
        (control.mUI||[]).forEach(function(ui) { pnode.parentNode && pnode.parentNode.insertBefore(ui, pnode.nextSibling||null)});
    else 
        (control.mUI||[]).forEach(function(ui) { ui.parentNode && ui.parentNode.removeChild(ui)});
    control.parentNode = pnode;
}

CPlaceholder.prototype.emptyUI = function (runtime, control) {
    (control.mUI||[]).forEach(function(ui) { ui.parentNode && ui.parentNode.removeChild(ui)});
    control.mUI = [];
}
//####################################################################################
function CDivButtonX(){ this.name = 'div-button-x'; }
CDivButtonX.prototype = new CDivButton();
CDivButtonX.prototype.constructor = CDivButtonX;
            
CDivButtonX.prototype.render = function (rtd, control, data, errs, attrs, events) {
    CDivButton.prototype.render.call(this, rtd, control, data, errs, attrs, events);
    control.ui.style.position = 'relative';
    if(!control.ui_x) {
        control.ui_x = document.createElement('input')
        control.ui_x.value = 'x';
        control.ui_x.setAttribute('type', 'button');
        control.ui_x.setAttribute('class', 'div-button-x');
        control.ui.appendChild(control.ui_x);
        _addEventListener(control.ui_x, 'click', function(e){ e.stopImmediatePropagation(); control.store(rtd, 'x') }, true);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);        
   }
   control.ui_x.style.visibility = (attrs.ta && !attrs.ta.visible) ? 'hidden' : 'visible';
}
//####################################################################################

var dfeComponents = [new CContainer(), new CButton(), new CEditbox(), new CDropdown(), new CRadiolist(), 
                  new CLabel(), new CCheckbox(), new CDiv(), new CDivC(), new CDivR(), new CTextarea(), 
                  new CTab(), new CDivButton(), new CMultiOption(), new CTypeAheadA(), new CPlaceholder(),
                 new CDivButtonX(), new CEditboxD(), new CEditPopup(), new CMenu(), new CHtml()];
 
