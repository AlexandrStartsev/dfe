
var DfeValidator = function(name){
    this.name = name;
}

var listener = {
    dpMap : {},
    depend : function () {},
    notify : function (d, e, a, v) { 
    	if('mard'.indexOf(a) != -1) {
    		console.error('Model is mutating:\n' + JSON.stringify(d) + '\n' + e + '\n' + a + '\n' + v );
    		throw new Error('Model is mutating');
    	}
    	return true 
    }, //    
    For: function() { return this; }
}

DfeValidator.prototype.render = function(rtd, control, data, errs, attrs, events) {
    control.ui = true;
}

DfeValidator.prototype.doValidation = function(rtd, control, events, attrs) { 
    attrs || (attrs = {});
    return !(attrs['disabled'] || attrs['hidden'] || (attrs.vstrategy && attrs.vstrategy.indexOf('none') != -1));
}

DfeValidator.prototype.purge =function() {} 

DfeValidator.createForm = function(dfe_data) {
    console.time('Nashorn form creation took');
    var dfe_proxy = new JsonProxy(dfe_data);
    var cn = new Set(), comps = [], form;
    dfe_proxy.get('dfe.type').forEach( function(t) { cn.has(t) || (cn.add(t), comps.push(new DfeValidator(t))) });
    form = new DfeForm(dfe_proxy, comps);
    console.timeEnd('Nashorn form creation took');
    return form;
}

DfeValidator.validate = function(arf_data, form) {
    console.time('Nashorn validation took');
    var rt = new DfeRuntime('dfe', listener).setDfeForm(form).setModel(new JsonProxy(arf_data)), errors = [];
    rt.rootControl.erroringControls.forEach(function(c) {errors.push(c)});
    //rt.shutdown(); GC will do it for us?  
    console.timeEnd('Nashorn validation took');
    return errors.map(function(c) { return {field: c.field.data.name, error: c.error}});
}

DfeValidator.validateStringify = function(arf_str, dfe_str) {
	var e = DfeValidator.validate(JSON.parse(arf_str), DfeValidator.createForm(JSON.parse(dfe_str)));
	return JSON.stringify({ result : e.length == 0, data : e});
}
