function functionize( obj , func ) {
   out = func;
   for( i in obj ){ out[i] = obj[i]; } ;
   return out;
}

function _extend(from, to) { 
    var v, key; for (key in from) { v = from[key]; to[key] = (typeof v === 'object' && (v = _extend(v, Array.isArray(v) ? [] : {})) || v) } return to;
}

//###############################################################################################################################
var ScopedData = {
    storage: new Map(), // Map(proxy.data -> { children: Set(proxy.data), scopes: Map( scoped_name -> value )})
    get : function(listener, data, parents, name) {
        for(d=data, i=parents.length; d; d=parents[--i]) {
            listener.depend(d, name);
            if( (d = this.storage.get(d)) && typeof (d = d.scopes.get(name)) != 'undefined') return d;
        }
        return [];
    },
    set : function(listener, data, parents, name, value) {
        var cd, d = this.storage.get(data);
        if( d && typeof (cd = d.scopes.get(name)) != 'undefined' ) {
            if( !value || value == [] ) value = '';
            if( cd != value ) { 
                d.scopes.set(name, value);
                listener && listener.notify(data, name, 's', cd, value.toString());
            }
        }
    },
    create : function(listener, data, parents, name, value) {
        var cd, d = this.storage.get(data);
        if(!d) {
            this.storage.set(data, d = { children : new Set(), scopes : new Map() });
            for(i=parents.length-1; i>=0; i--) 
                if( cd = this.storage.get(parents[i]) ) {
                    cd.children.add(data);
                    break ;
                }
        }
        this.set(listener, data, parents, name, value);
    },
    evict : function(listener, data) {
        var sd = this.storage.get(d); if(sd) { this.storage['delete'](d); sd.children.forEach(function(d) {ScopedData.evict(d)}); }
    }
}
//###############################################################################################################################
function JsonProxy(data, parents, elements, listener) {
    this.parents = (parents || []);
    this.elements = (elements || []);
    this.data = data||{};
    this.persisted = data;
    this.listener = listener;
    if(this.parents.length != this.elements.length) throw 'Oops';
}          

JsonProxy.prototype.toString = function() { return 'JsonProxy{' + this.elements.join('.') + '}' }

/* Queries model from value(s) or subset(s) 
 * @param {String} path full-path string i.e. 'policy.class.code' or relative path like '.code', '..class.code' etc
 * @returns {String|JsonProxy|Array}
 */
JsonProxy.prototype.get = function (path) {
    var sb = 0;
    if(!path) return this;
    if(path.charAt(0) == '.' ) {
        var s = path.substr(1), ret;
        if(s.indexOf('.') == -1 && s.length > 0) {
            ret = this.data[s];
            this.listener && this.listener.depend(this.data, s);
            if( ret && Array.isArray(ret) ) { 
                var t = ret, p = this.parents.concat(this), e = this.elements.concat(s); ret = [];
                t.forEach(function (d) {
                    ret.push(new JsonProxy(d, p, e, this.listener));
                }, this);
            }
            return ret || [];
        } else {
            while(s.charAt(sb) == '.') sb++;
            var p = this.elements.slice(0, this.elements.length-sb).join('.');
            path = (p == '' ? s.substr(sb) : p + path.substr(sb));
        }
        if(sb == s.length) return this.parents.concat(this)[this.parents.length - sb];
    } 
    if(path.charAt(0) == ':' ) { return ScopedData.get(this.listener, data, parents, path); }
    var p = path.split('.'), pa = this.parents.concat(this);
    if(path.length == 0) return [new JsonProxy(pa[0].data, [], [], this.listener)];
    var va = [pa[0]], maintained = true;
    for(var i = 0; i < p.length && va.length > 0; i++) {
       if(maintained && pa.length-sb > i+1 && i < p.length - 1 && this.elements[i] == p[i]) {
          va = pa[i+1].data ? [pa[i+1]] : [];
       } else {
          var nva = [], e, listener = this.listener;
          va.forEach(function(px){
            if( px.data ) {
               if(listener) listener.depend(px.data, p[i]);
               if(e = px.data[p[i]]) {
                  if(Array.isArray(e)) {
                     var pars = px.parents.concat(px), els = p.slice(0, i+1);
                     e.forEach(function(d){
                        nva.push(new JsonProxy(d, pars, els, listener));
                     });
                  } else {
                     nva.push(e);
                  }
               }
            }
          });
          if(maintained && i == p.length - 1 && nva.length)
              return Array.isArray(e) ? nva : nva[0]||[];
          maintained = false;
          va = nva;
       }
    }
    return va;
}
 
JsonProxy.prototype.shadow = function (path, defaults) {
    if(path.length == 0) return [];
    if(path.charAt(0) == '.') 
        path = this.elements.join('.') + path;
    var p = path.split('.'), me = this, pa = this.parents.concat(this), ret;
    for(var i = 0; i < p.length; i++) 
        if(!(pa.length > i + 1 && this.elements[i] == p[i])) {
            pa = pa.slice(0, i+1);
            for(var j = i + 1; j <= p.length; j++) 
                pa = pa.concat(new JsonProxy(undefined, pa, p.slice(0, j), this.listener));
            ret = pa.pop();
            break ;
        }
    _extend(defaults, (ret = ret || new JsonProxy(undefined, this.parents, p, this.listener)).data);
    return [ret];
}

JsonProxy.prototype.persist = function () {
    if(!this.persisted ) {
        var lp = this.parents[this.parents.length - 1], le = this.elements[this.parents.length - 1], arr;
        lp.persist();
        arr = lp.data[le] || (lp.data[le] = []);
        if(arr.indexOf(this.persisted = this.data) == -1) {
            arr.push(this.data);
            this.listener && this.listener.notify(lp.data, le, 'a', this.data);
        }
    } 
    return this;
}
 
JsonProxy.prototype.append = function (path, defaults) {
    var ret = this.shadow(path, defaults);
    ret.forEach(function (px) { px.persist(); });
    return ret;
}

JsonProxy.prototype.clone = function () {
    var ret = (this.parents.length && this.parents[this.parents.length - 1].append('.' + this.elements[this.elements.length - 1])[0] || new JsonProxy({})).withListener(this.listener);
    _extend(this.data, ret.data);
    return ret;
}

JsonProxy.prototype.scoped = function (name, value) {
    if(this.data) {
        if(name[0] != ':') name = ':' + name;
        ScopedData.create(this.listener, this.data, this.parents, name, value);
    }
}
    
JsonProxy.prototype.set = function (path, value) {
    if(!path) return ;
    value || (value = '');
    if(value.length == 1 && value.constructor == Array /* && typeof value[0] !== 'undefined' */) value=value[0];
    var listener = this.listener, le, va, maintained = true, sb = 0, sd;
    if(path.charAt(0) == '.') {
        while(path.charAt(sb+1) == '.') sb++;
        path = this.elements.slice(0, this.elements.length-sb).join('.') + path.substr(sb);
        while( path.charAt(0) == '.' ) path = path.substr(1);
    }
    if(path.charAt(0) == ':' ) { return ScopedData.set(this.listener, this.data, this.parents, path, value); }
    var p = path.split('.'), pa = this.parents.concat(this),
    va = [pa[0]];
    for(var i = 0; i < p.length - 1 && va.length > 0; i++) {
       if(maintained && pa.length-sb > i+1 && this.elements[i] == p[i]) {
          va = [pa[i+1]];
       } else {
          var nva = [], e;
          va.forEach(function(px){
            if((e = px.data[p[i]]) == undefined) e = [undefined];
            if(!Array.isArray(e)) throw 'Unable to overwrite property with subset';
            e.forEach(function(d){
               nva.push(new JsonProxy(d, px.parents.concat(px), p.slice(0, i+1), listener));
            });
          });
          maintained = false;
          va = nva;
       }
       value.length && va.forEach(function(px) {px.persist()});
    }
    le = p.pop();
    va.forEach(function(px) {
       var v = px.data[le];
       if(v == undefined || v==[]) v = '';
       if(typeof v == 'number') v = v.toString();
       if(v != value) {
          var old = px.data[le];
          if(value.length == 0) {
            delete px.data[le];
            listener && listener.notify(px.data, le, 'r', old); 
          } else {
            px.data[le] = value;
            listener && listener.notify(px.data, le, 'm', old, value.toString());
          }
       }
    });
}
 
JsonProxy.prototype.detach = function() {
    ScopedData.evict(this.listener, this.data);
    if(this.persisted && this.parents.length > 0) {
        var p = this.parents[this.parents.length - 1], e = this.elements[this.parents.length - 1], sd, f;
        var arr = p.data[e];
        var idx = arr.indexOf(this.data);
        if( idx != -1 ) {
            arr.splice(idx, 1); 
            arr.length || delete p.data[e]; 
            this.listener && this.listener.notify(p.data, e, 'd', this.data);
        }
        delete this.persisted; // = undefined;
    }
}
 
JsonProxy.prototype.withListener = function(l) {
    var ret = new JsonProxy(this.data, this.parents, this.elements, l);
    ret.persisted = this.persisted;
    return ret ;
}

//####################################SUPPORTING FUNCTIONS#######################################################################

JsonProxy.indexOf = function(pxA, path, value) {
    return Array.isArray(pxA) ? pxA.map(function(a){return a.get(path)}).indexOf(value) :
        pxA.get(path).map(function(a){return a.data}).indexOf(pxA.data);
}

JsonProxy.prototype.index = function(depth) {
    depth||(depth=1);
    return JsonProxy.indexOf(this, '........'.substr(0, depth+1) + this.elements.slice(this.elements.length-depth, this.elements.length).join('.'));
}

/* returns first instance of subset. if subset array size is zero, shadow instance is returned. consequential write into shadow instance will persist it. 
 * @param {String} path full-path string i.e. 'policy.class' or relative path like '.class'
 * @param {Boolean} persist if no records exsit, and parameter set to 'false', shadow record will be returned; otherwise record will be persisted
 * @param {Object} defaults default values to set in row only if it s created. 
 * @returns {Array} array of exactly one JsonProxy object
 */
JsonProxy.prototype.single = function (path, persist, defaults) {
    persist && this.withListener().get(path) == 0 && this.append(path, defaults); // we don't want to get notification of this? 
    var s = this.get(path); 
    return [(s.length > 0 ? s : this.shadow(path, defaults))[0]];
}

/* retrieves existing value from model, if field doesn't exist, default value is assigned to field in model and returned. 
 * @param {String} path full-path string i.e. 'policy.class' or relative path like '.class'
 * @param {String} _default default value
 * @returns {String|Array}
 */
JsonProxy.prototype.getOrDefault = function (path, _default) { var ret = this.get(path); if(ret == 0 && _default) { this.set(path, _default); ret = this.get(path); } return ret; }

/* similar to JsonProxy::getOrDefault, but for subsets. If subset doesn't exist, instance will be added to a model and returned
 * @param {String} path full-path string i.e. 'policy.class.code' or relative path like '.code', '..class.code' etc
 * @returns {Array} array of JsonProxy objects (with a length of at least 1)
 */
JsonProxy.prototype.getOrAppend = function (path, defaults) { var ret = this.get(path); if(ret == 0) { this.append(path, defaults); ret = this.get(path); } return ret; }

JsonProxy.prototype.getOrShadow = function (path, defaults) { var ret = this.get(path); return ret == 0 ? this.shadow(path, defaults) : ret; }

//###############################################################################################################################
function DfeListener(dependencyMap, control) {
    this.dpMap = dependencyMap || new Map();
    this.control = control;
}

DfeListener.prototype.depend = function(data, element) {
    if(this.control) {
        var e = this.dpMap.get(data);
        e || this.dpMap.set(data, e = new Map());
        var l = e.get(element);
        l || e.set(element, l = new Set());
        if(!l.has(this.control)) {
            l.add(this.control);
            this.control.dependencies.push({data : data, element : element});
        }
    }
}

DfeListener.prototype.For = function(control) {
	return new DfeListener(this.dpMap, control);
}

DfeListener.prototype.notify = function(data, element, action, d1) {
    (e = this.dpMap.get(data)) && (s = e.get(element)) && s.forEach(function (cc) {
        cc.notifications.push({data : data, element : element, action : action, d1 : d1});
    });
    return true;
}

DfeListener.prototype.set = function (data, element, value, action) { if(data[element] != value) { data[element] = value; this.notify(data, element, action, value) }; return true; }
DfeListener.prototype.get = function (data, element) { this.depend(data, element); return data[element]; }
//###############################################################################################################################
function DfeRuntime(rootUI, listener) {
   this.rootUI = rootUI;
   this.listener = listener || new DfeListener(); 
   this.controls = new Set();
}

DfeRuntime.prototype.setDfeForm = function(form, rootFieldName) {
    this.form = form;
    this.root_field_proxy = form.rootField(rootFieldName);
    this.restart();
    return this;
}

DfeRuntime.prototype.setModel = function(model_proxy) {
    this.model_proxy = model_proxy;
    this.restart();
    return this;
}

DfeRuntime.prototype.shutdown = function () { 
    clearInterval(this.processor); this.controls.forEach(function(c) { this.evict(c) }, this);
    delete this.rootControl;
}

DfeRuntime.prototype.restart = function() {
    this.shutdown();
    if(this.model_proxy && this.root_field_proxy) {
        var self = this;
        if(typeof this.form.onstart == 'function') this.form.onstart(this.model_proxy, this);
        this.rootControl = this.addControl(this.rootUI, 0, this.model_proxy, this.root_field_proxy);
        this.processInterceptors();
        this.processor=setInterval(function() { self.processInterceptors(); }, 50);
    }
}

DfeRuntime.prototype.store = function (control, value, method) {
   var f = control.field.get('.set'), self = this, l = control.model.listener;
   (typeof f === 'function') && (l.control = null, f(control.model, control.model.value = value), l.control = control); // easiest way to prevent dependency on reads in 'set' 
   setTimeout(function() { self.processInterceptors() }, 1);
}

DfeRuntime.prototype.processInterceptors = function() {
   this.controls.forEach(function(control){
      if(control.notifications.length) {
          var events = control.notifications;
          control.notifications = [];
          this.render(control, events);
      }
   }, this);
}

DfeRuntime.prototype.processChildren = function(parent, rx, prx, fpx) {
    if(parent.children.size || fpx.length ) {
        var pc = parent.children, fields = new Map(), rows = new Map(), rkeys = new Set(), fkeys = new Set(), skeys = new Set(), i=0, m, present, a, f, n, c; 
        parent.children.forEach(function(v, k) { rkeys.add(k);i++||v.forEach(function(c, f){fkeys.add(f)})});
        (fpx||[]).forEach(function(fp) { fp=fp.data.proxy,d=fp.data,fields.set(d, fp); (typeof d['class'] == 'string' && d['class']!=''?skeys:fkeys).add(d) });
        (rx||[]).forEach(function(r) { rows.set(r.data, r); rkeys.add(r.data)});
        rkeys.forEach( function(r) { 
            (m = pc.get(r))||pc.set(r, m = new Map()); 
            present = rows.get(r); 
            fkeys.forEach(function(k) {
                c = m.get(k);
                present && (f=fields.get(k)) ? c || m.set(k, this.addControl(0, parent, present, f)) : c && (this.evict(c), m['delete'](k));
            }, this);
            m.size || pc['delete'](r);
        }, this);
        m = parent.fixedChildren;
        skeys.forEach(function(k) {
            c = m.get(k);
            (f=fields.get(k)) ? c || m.set(k, this.addControl(0, parent, prx, f)) : c && (this.evict(c), m['delete'](k));
        }, this);  
    }
}

DfeRuntime.prototype.addControl = function (parentNode, parentControl, model_proxy, field_proxy) {
    if(field_proxy) {
        var control = {parentNode : parentNode, parentControl : parentControl, data : 0, dependencies : [], notifications : [{action: 'init'}]
                     , children : new Map(), fixedChildren : new Map(), erroringControls : new Set() };
        this.controls.add(control);
        control.model = this.prep$$(control, model_proxy);
        control.field = field_proxy.withListener(control.model.listener);
        this.verifyComponent(control);
        return control;
    }
}

DfeRuntime.prototype.evict = function(control) {
   this.processChildren(control, [], {}, []);
   control.component.purge(this, control);
   this.cleanUpDependencies(control);
   this.controls['delete'](control);
   this.removeErroring(control);
}

DfeRuntime.prototype.prep$$ = function(control, model_proxy) {
    var $$ = functionize(model_proxy.withListener(this.listener.For(control)), function(p) { return arguments.callee.get(p); });
    $$.runtime = this;
    $$.form = this.form;
    $$.control = control;
    $$.result = function(data) {
          $$.runtime.processChildren($$.control, data || [], $$.attrs.hmodel, $$.control.field.get('.children'));
          $$.control.component.render($$.runtime, $$.control, data, $$.control.error, $$.attrs, $$.events);
          return $$.control.data = data;
    }
    $$.error = function(error) {
       if( error && $$.control.doVal ) {
    	   try {
    		   $$.control.component.render($$.runtime, $$.control, $$.control.data, error, $$.attrs, $$.events);
    	   } finally {
               $$.control.stickyError = $$.control.error = error;
               $$.attrs && $$.attrs.errorwatch || $$.runtime.notifyErroring($$.control, $$.events);
    	   }
       }
       return error;
    }
    $$.errorwatch = function() {
        $$.attrs.errorwatch && $$.runtime.findErroringChildren($$.control.parentControl, $$).length && $$.error('Simulated error');
    }
    return $$;
}

DfeRuntime.prototype.removeErroring = function(control) {
    for( p=control.parentControl; p && p.erroringControls['delete'](control) && this.listener.notify(p, 'erroringControls'); p=p.parentControl ) ;
}

DfeRuntime.prototype.notifyErroring = function(control, events) {
    var e = events.filter(function(e1) {return e1.action == 'validate'}).length ? 'validate' : 'errorwatch';
    for( p=control.parentControl; p && !p.erroringControls.has(control) && (p.erroringControls.add(control)||1) //IE11 fix 
                    && this.listener.notify(p, 'erroringControls', e); p=p.parentControl ) ;
}

DfeRuntime.prototype.render = function (control, events) {
    var $$ = control.model;
    try {
        if(!control || !this.verifyComponent(control)) return ;
        var fa = control.field.get('.atr'), fg = control.field.get('.get'), fv = control.field.get('.val'), rezultz;
        $$.events = events;
        $$.attrs = (typeof fa != 'function' ? {} : fa($$));
        $$.attrs.errorwatch && $$.listener.depend($$.control.parentControl, 'erroringControls');
        !($$.attrs.hmodel) && ($$.attrs.hmodel = $$);
        $$.control.doVal = (!control.component || control.component.doValidation(this, control, events, $$.attrs));
        delete $$.control.error;
        this.removeErroring(control);
        var rezultz = (typeof fg != 'function' ? [] : fg($$));
        if(typeof rezultz !== 'undefined' || !control.ui) $$.result(rezultz);
        $$.control.doVal && (typeof fv == 'function') && fv($$);
        
        control.ui._dfe_ = control;
    } catch(e) { 
        $$.control.doVal = 1; try{ $$.error(e.message) } catch (e) { } console.error(control.field + '\n' + e.message + '\n' + e.stack); 
	}
}

DfeRuntime.prototype.verifyComponent = function(control) {
    var component = control.field.get('.component');
    if( component != control.component ) {
        if(control.component) {
            control.component.emptyUI(this, control);
            delete control.runtime;
            delete control.data;
            delete control.error;
            delete control.stickyError;
        }
        control.component = component;
        control.store = component.store;
    }
    return control.component;
}

DfeRuntime.prototype.cleanUpDependencies = function(control) {
	var dpMap = this.listener.dpMap;
    control.dependencies.forEach(function(dep) {
        var eleMap = dpMap.get(dep.data);
        if(eleMap) { 
            var ctlSet = eleMap.get(dep.element);
            if(ctlSet) {
                ctlSet['delete'](control);
                ctlSet.size || eleMap['delete'](dep.element);
                eleMap.size || dpMap['delete'](dep.data);
            }
        }
    }, this);
    control.dependencies.splice(0);
}

DfeRuntime.prototype.notifyControls = function(controls, action) {
   (Array.isArray(controls) ? controls : [controls]).forEach(function(control) { control.notifications.push({action : action||'n'}) }); /*this.render(control, [{action : action||'n'}]);*/
}

DfeRuntime.prototype.findChildren = function(controls, deep, includeSelf, field, model) {
    var ret = new Set(), a = [];
    function traverse(control) { 
        control.children.forEach(function(v) { v.forEach(function(c) { 
            (!field || c.field.data.name == field) && (!model || c.model.data == model.data ) && ret.add(c); 
            traverse(c);
        })});
        control.fixedChildren.forEach(function(c) { 
            (!field || c.field.data.name == field) && (!model || c.model.data == model.data ) && ret.add(c); 
            traverse(c);
        });
    }
    (Array.isArray(controls) ? controls : [controls]).forEach( function (c) { 
        includeSelf && (!field || c.field.data.name == field) && (!model || c.model.data == model.data ) && ret.add(c); 
        traverse(c); 
    });
    ret.forEach(function(k) { a.push(k); });
    return a;
}

DfeRuntime.prototype.findErroringChildren = function(parent, model) {
    var ret = [];
    parent || (parent=this.rootControl);
    (Array.isArray(parent) ? parent : [parent]).forEach(function(p) {
        model && model.listener.depend(p, 'erroringControls');
        p.erroringControls.forEach(function(c) { ret.push(c) });
    });
    return model ? ret.filter(function(c) { for(;c && c.model.data != model.data;c=c.parentControl); return c; }) : ret;
}

DfeRuntime.prototype.findControls = function(fields, model_proxy) {
    var ret = [], array = (Array.isArray(fields) ? fields : [fields]);
    this.controls.forEach(function(c) {
        if(array.indexOf(c.field.data.name) != -1 && (model_proxy == undefined || c.model.data == model_proxy.data )) ret.push(c);
    });
    return ret;
}
//###############################################################################################################################
function DfeForm(dfe_proxy, components, listener) {
    this.components = new Map();
    this.dfe_proxy = new JsonProxy({ dfe : [], form : this }, [], [], listener);
    if(Array.isArray(components))  this.registerComponents(components);
    if(dfe_proxy && dfe_proxy.data) {
        this.registerFields(dfe_proxy.data.dfe);
        try { 
            (this.dfe_proxy.data.setup = dfe_proxy.data.setup) && Function(dfe_proxy.data.setup ).call(this) 
        } catch (e) { console.error(e) }
    }
}

DfeForm.prototype.registerComponents = function(components) {
       components.forEach(function(c){
         this.dfe_proxy.get('dfe').forEach(function(px){
             if(px.get('.type') == c.name)
                 px.set('.component', c);
         });
         this.components.set(c.name, c);
         this.dfe_proxy.set('components.' + c.name, c);
       }, this);
       return this;
}

DfeForm.prototype.findByName = function(name) {
    var field = undefined;
    this.dfe_proxy.get('dfe').forEach(function(px){
        if(field == undefined && px.get('.name') == name)
            field = px;
    });
    return field;
}

DfeForm.prototype.registerFields = function(fields) {
    var ret = [];
    fields.forEach(function(f){
         var cur = this.findByName(f.name), par, ev;
         if(cur != undefined) {
             cur.set('.parent', undefined);
             this.fixParent(cur);
         } else
             cur = this.dfe_proxy.append('dfe')[0];
         for( i in f )
             cur.set('dfe.' + i, f[i]);
         cur.set('.component', this.components.get(cur.get('.type')));
         cur.set('.form', this);
         ret.push(cur);
    }, this);
    ret.forEach(function(cur) { this.fixParent(cur); this.fixFunctions(cur, true);  }, this );
    return ret;
}

    
function needsReturn(code) {
    var esprima = require('esprima'); 
    try {
        var fbody = (esprima.parseScript||esprima.parse)('function foo($$) {\n' + code + '\n}').body[0].body.body;
        return fbody.length == 1 && ( fbody[0].type == 'ExpressionStatement' ||
                    fbody[0].type == 'BlockStatement' && fbody[0].body.filter(function(b) { b.type != 'LabeledStatement'}).length === 0);
    } catch(e) { }
    return true;
}

function compilationerror($$) { $$.error('compilation error'); return [] }
function makefunction(code, log, nv, nr) { try { return (code == 0 ? [] : nv ? Function('$$', 'value', code ) : Function('$$', ( nr && needsReturn(code) ? 'return ' : '') + code ) ) } catch (e) { log && console.error('Compilation error [' + e.message + '] for:\n' + code); return compilationerror } }

DfeForm.prototype.fixFunctions = function(cur, log) {
    cur.set('.set', makefunction(cur.get('._set'), log, 1));
    cur.set('.val', makefunction(cur.get('.validation'), log));
    cur.set('.get', makefunction(cur.get('._get'), log, 0, 1) );
    cur.set('.atr', makefunction(cur.get('.attributes'), log, 0, 1));
}

DfeForm.prototype.fixParent = function(proxy) {
    var par;
    if(proxy) {
        if((par = proxy.get('.parent_px')) != 0) {
            par.get('.children').forEach(function (cf){
            if(cf.get('.name') == proxy.get('.name'))
                cf.detach();
            });
        }
        var parentname = proxy.get('.parent');
        if(parentname && parentname != 0 && (par = proxy.get('.form').findByName(parentname)) != undefined) {
            proxy.set('.parent_px', par);
            par = par.append('.children')[0];
            par.set('.name', proxy.get('.name'));
            par.set('.proxy', proxy);
        } else {
            proxy.set('.parent_px', []);
        }
    }
}

DfeForm.prototype.getDfeArf = function () {
    return this.dfe_proxy;
}

DfeForm.prototype.rootField = function (fieldName) {
    var dfes = this.dfe_proxy.get('dfe'), ret = dfes[0];
    dfes.forEach(function (dfe) { ret = (dfe.get('.name') == fieldName) ? dfe : ret; });
    return ret;
}
//###############################################################################################################################
var global = (function(){ return this; })()||window;

function DfeManager(urlBase, components, listener) {
    this.forms = new Map();
    this.urlBase = urlBase;
    this.runtimes = new Set();
    this.components = components;
    this.listener = listener || new DfeListener();
}

DfeManager.prototype.startRuntime = function(arg) {
    var runtime = new DfeRuntime(arg.node, this.listener), c = arg.components||this.components, l = this.listener, self = this;
    runtime.manager = this;
    for(var v in arg.params) runtime[v] = arg.params[v];
    this.runtimes.add(runtime);
    $.when( arg.model ? $.resolved(arg.model, 'success') : $.get('/DfeServlet.srv?a=model'),
            arg.dfe ? $.resolved(arg.dfe, 'success') : $.get(arg.formUrl || (self.urlBase + arg.formName)),
            $.require(['esprima']) ).done( function(model, dfe, esprima) {
        // TODO: error handling
        var dfe_proxy = new JsonProxy(dfe[0], [], [], l), form = new (arg.formClass || DfeForm)(dfe_proxy, c, l, arg.params);
        form.formName = arg.formName;
        runtime.setModel(new JsonProxy(model[0])).setDfeForm(form);
        arg.ready && arg.ready(runtime, dfe_proxy);
    })
    return runtime;
} 

DfeManager.prototype.stopRuntime = function(runtime) {
    runtime.shutdown();
    this.runtimes['delete'](runtime);
}
