Array.isArray || (Array.isArray = function(o) { return o instanceof Array })
Array.prototype.forEach || (Array.prototype.forEach = function(f, a) { for(var i = 0; i < this.length; i++) f.call(a, this[i], i, this) })
Array.prototype.indexOf || (Array.prototype.indexOf = function(e) { var i=this.length-1; for(;i>=0 && this[i] != e;i--); return i; })
Array.prototype.filter || (Array.prototype.filter = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) f.call(a, this[i], i, this) && r.push(this[i]); return r } )
Array.prototype.map || (Array.prototype.map = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) r.push(f.call(a, this[i], i, this)); return r } )
Array.from || (Array.from = function(s) { 
    var r = [], o;
    Symbol && Symbol.iterator && (typeof s[Symbol.iterator] === 'function') && (s=s[Symbol.iterator]());
    if(typeof s.next === 'function') 
        while(!(o=s.next()).done) 
            r.push(o.value); 
    else 
        s.forEach(function(e) { r.push(e); } ); 
    return r; 
})

var Symbol = Symbol || {}
Symbol.iterator || (Symbol.iterator='Symbol(Symbol.iterator)')
 
var window = {}
typeof setTimeout    !== 'undefined' || (setTimeout    = function(f) {f()});
typeof setInterval   !== 'undefined' || (setInterval   = function() {});
typeof clearInterval !== 'undefined' || (clearInterval = function() {});

var AjaxHandler = Java.type('com.arrow.util.experimental.AjaxHandler');
var CacheHandler = Java.type('com.arrow.util.experimental.CacheHandler');

var ajaxCache = CacheHandler.sharedCache('ajaxCache', '1000', '60');

var $ = {
   ajax : function(o) {
      new AjaxHandler().handle(bindings, servletContext, localName, o.url, o.type, o.dataType, o.data, o.headers);
      var __error = true;
      if(status == 'success' ) 
         if(typeof o.success === "function")
        	 try {
        		 o.success(JSON.parse(strResponse), 'success');
        		 __error = false;
        	 } catch(err) { strError = err.message }
      if(__error && (typeof o.error === "function") ) o.error('error', strError);
   }
}
 
var NashornSet = Java.type('com.arrow.util.experimental.collections.NashornSet');
var NashornMap = Java.type('com.arrow.util.experimental.collections.NashornMap');
 
var Set = function(iterable) {
    this.__impl = new NashornSet();
    if(iterable !== undefined) {
    	if(typeof iterable.forEach === 'function') iterable.forEach(function(e) { this.__impl.add(e); }, this);
    	else this.__impl.add(iterable);
    }
}
 
Object.defineProperty(Set.prototype, 'size', { get : function() { return this.__impl.size(); }});
Set.prototype.constructor = Set;
Set.prototype.forEach = function (f, ctx) { return ctx===undefined ? this.__impl.forEach(f) : this.__impl.forEach(function(k) {f.call(ctx, k)}) };
Set.prototype.add = function (o) { this.__impl.add(o); return this; }
Set.prototype.clear = function () { return this.__impl.clear(); }
Set.prototype.delete = function (o) { return this.__impl.delete(o); }
Set.prototype.entries = function () { return this.__impl.entries(); }
Set.prototype.keys = Set.prototype.entries;
Set.prototype.values = Set.prototype.entries;
Set.prototype[Symbol.iterator] = Set.prototype.entries;
Set.prototype.has = function (o) { return this.__impl.has(o); }
 
var Map = function(iterable) {
    this.__impl = new NashornMap();
    if(iterable !== undefined) {
    	if(typeof iterable.forEach === 'function') iterable.forEach(function(e) { this.__impl.set(e[0], e[1]); }, this);
    	else this.__impl.add(iterable);
    }    
}

Object.defineProperty(Map.prototype, 'size', { get : function() { return this.__impl.size(); }});
Map.prototype.constructor = Map;
Map.prototype.forEach = function (f, ctx) { return ctx===undefined ? this.__impl.forEach(f) : this.__impl.forEach(function(v, k) { f.call(ctx, v, k)}) };
Map.prototype.clear = function() { return this.__impl.clear(); }
Map.prototype.delete = function(k) { return this.__impl.delete(k); }
Map.prototype.set = function(k,v) { this.__impl.set(k,v); return this; }
Map.prototype.get = function(k) { var ret = this.__impl.get(k); return ret == null ? undefined : ret; }
Map.prototype.has = function(k) { return this.__impl.contains(k); }
Map.prototype.entries = function () { return this.__impl.entries(); }
Map.prototype.keys = function () { return this.__impl.keys(); }
Map.prototype.values = function () { return this.__impl.values(); }
Map.prototype[Symbol.iterator] = Map.prototype.entries;

//########################################################################################
var CTab = { active : function () { return false } }

//########################################################################################

var console = { 
    timeMap : new Map(),
    log : function (a) { print(a); }, 
    error : function (a) { print(a); },
    time : function(s) { this.timeMap.set(s, java.lang.System.currentTimeMillis()) },
    timeEnd : function(s) { return java.lang.System.currentTimeMillis() - this.timeMap.get(s) }
}

var alert = console.log;
