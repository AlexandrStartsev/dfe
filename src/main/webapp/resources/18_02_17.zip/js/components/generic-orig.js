define('components/component', ['ui-utils'], function(uiUtils) {
    var Component = function () { }
    Component.prototype.name = 'component';
    Component.prototype.isContainer = function () { return false; }
    Component.prototype.skipattrs = new Set();
    Component.prototype.toAttribute = new Set();

    [   'tagname', 'hmodel', 'options', 'trigger', 'orientation', 'vstrategy', 'formatting',
        'default', 'display', 'focusnew', 'data', 'info', 'depend', 'errorwatch', 'events', 'ta', 
        'filter', 'order', 'offsetLeft', 'offsetTop', 'rowclass', 'rowstyle', 'colclass', 'colstyle',
        'rowclass$header', 'rowclass$footer', 'rowstyle$header', 'rowstyle$footer', 'haclass', 'nodollar',
        'skip', 'pattern', 'transform', 'hfield', 'tagname', 'eclass'
    ].forEach(function(a) { Component.prototype.skipattrs.add(a) }); 

    ['name', 'id', 'disabled', 'hidden', 'readonly', 'maxlength', 'placeholder', 'spellcheck', 'class', 'style'
    ].forEach(function(a) { Component.prototype.toAttribute.add(a) }); 

    Component.prototype.setAttributesUI = function(rtd, ui, data, errs, attrs, events) { 
        for(var i in attrs) {
            if(! this.skipattrs.has(i)) {
                if( this.toAttribute.has(i) ) 
                    uiUtils.setAttribute(ui, i, attrs[i]);
                else
                    if(i.indexOf('$')==-1) ui[i] = attrs[i]; 
            }
        }
    }

    Component.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) { 
        this.setAttributesUI(rtd, control.ui, data, errs, attrs, events);
    }

    Component.prototype.checkAttributes = function(control, newArrts, oldAttrs) { return true; }

    Component.prototype.setParentNode = function(control, pnode) {
        if(pnode) {
            control.ui && pnode.appendChild(control.ui); 
            (control.mUI||[]).forEach(function(ui) {pnode.appendChild(ui)});
        } else 
            if(control.parentNode) {
                control.ui && control.parentNode.removeChild(control.ui); 
                (control.mUI||[]).forEach(function(ui) {control.parentNode.removeChild(ui)});
            }
        control.parentNode = pnode;
    }

    Component.prototype.emptyUI = function (runtime, control) {
        if(control.parentNode) {
            control.ui && control.parentNode.removeChild(control.ui); 
            (control.mUI||[]).forEach(function(ui) {control.parentNode.removeChild(ui)});
        }
        control.ui = 0, control.mUI = [];
    }

    Component.prototype.purge = function (runtime, control) { this.emptyUI(runtime, control); }

    /* none - no validation. $$.error = ... is ignored on both client and server side. may be useful with ajaxFeed datasource
       default/clean - validate if previously errored or when 'validate' notification received
       followup - acts as 'clean' until first error (control.stickyError is undefined), then as 'notified' 
       notified - validate if previously errored or when notified (non-empty event queue)
       always - validate on every rendering cycle (including very first one, after creation)
       extras:
        - if 'disabled' word is added, control will validate as above even when attribute 'disabled' is set 
        //- if 'post' word is added, control will be notified with 'validate' event when any  additionally after 
     */
    Component.prototype.doValidation = function(rtd, control, events, attrs) { 
        attrs || (attrs = {});
        var vs = (attrs.vstrategy||'').split(' ');
        if( vs.indexOf('none') != -1 ) return false;
        if( ( vs.indexOf('disabled') == -1 && attrs.disabled) || attrs.hidden ) return false;
        if( vs.indexOf('always') != -1 ) return true;
        if( ( vs.indexOf('notified') != -1 || vs.indexOf('followup') != -1 && control.stickyError )
                   && (control.error || events.length > 1 || events.length && events[0].action != 'init') ) return true;
        //if(attrs.errorwatch && control.stickyError && events.filter(e => ['errorwatch'].indexOf(e.action)!=-1) != 0 ) return true;
        return control.error || events.filter(function(e) { return 'validate' == e.action }) != 0; 
    }

    Component.prototype.appendError = function(control, ui, errs, attrs, keepmUI) { 
        if(ui) {
            while( control.mUI && control.mUI.length > (keepmUI||0) ) ui.removeChild(control.mUI.pop());
            if( errs ) {
                var e = document.createElement('label'); 
                uiUtils.setAttribute(e, 'class', attrs.eclass || 'dfe-error');
                uiUtils.setAttribute(e, 'style', attrs.estyle); // || 'color: #DB1260; font-weight: bold; display: block;'
                e.innerHTML = errs;
                ui.appendChild(e);
                (ui == control.parentNode) && (control.mUI||(control.mUI = [])).push(e);
            }
        }
    }
    Component.prototype.store = function(runtime, value) { runtime.store(this, value); }
    Component.prototype.render = function(runtime, control, model_proxy, errs, attrs, events) { control.ui = 1; }
    Component.prototype.layout = 'none';
    Component.prototype.runtime = function(control) { return control.runtime || (control.runtime={}) }
    Component.prototype.setEvents = function(rtd, ui, control, data, errs, attrs, events) {
        for(n in attrs.events) 
            (function(a, e) { 
                if(typeof e == 'function') {
                    var nm = a, t = ui, id, i=a.indexOf('$'); 
                    if(i != -1 && !isNaN(id=+a.substr(i+1)) && (id==0||control.mUI[id])) { t = id==0?control.ui:mUI[id-1]; nm=a.substr(0,i)}
                    uiUtils.addEventListener(t, nm, function(event) { return e.call(control.model.runtime.form, event, control) }, false);
                }
            })(n, attrs.events[n]);
    } 
    return new Component();
})

define('components/editbox', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CEditbox = function () {}
    CEditbox.prototype = new Component.constructor();
    CEditbox.prototype.name = 'editbox';
    CEditbox.prototype.constructor = CEditbox;
    CEditbox.patterning = function(v, p) { while(p && v != 0 && !(v.match(p) && v.match(p)[0] == v) ) v = v.substr(0, v.length-1); return v; }
    CEditbox.formatting = function(value, format) { // aka XXX-XXX-XXXX or MM/DD/YYYY
        if(format && typeof value !== 'undefined') {
            var ret = '', i, j, vn, vl, fn, fl;
            value = (Array.isArray(value) ? value[0] : value).toString().replace(/\W/g, '');
            for (i = 0, j = 0; i < format.length && j < value.length; i++) {
                vn = !(vl = value.charAt(j).match(/[A-Z]/i)) && !isNaN(parseInt(value.charAt(j)));
                fn = !(fl = format.charAt(i) == '_') && 'XdDmMyY9'.indexOf(format.charAt(i)) >= 0;
                if (fl && !vl || fn && !vn) break ;
                ret += fl && vl || fn && vn ? value.charAt(j++) : format.charAt(i);
            }
            value = ret;
        }
        return value||'';
    }

    CEditbox.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(attrs.transform) {
            control.transform = [];
            attrs.transform.split('').forEach(function(s) { control.transform.push(s.charCodeAt(0)-(s.charCodeAt(0) > 57 ? 55 : 48)) });
        }
        control.pattern = attrs.pattern;
        control.formatting = attrs.formatting;
        if(!control.ui) {
            control.ui = document.createElement('input');
            control.parentNode && control.parentNode.appendChild(control.ui);
            control.ca = 0;
            uiUtils.addEventListener(control.ui, 'keydown', function(e) {
                var s = control.ui.selectionStart, v = control.ui.value, m; 
                if((e.key == 'Backspace' || e.key == 'Delete' || e.key == 'Del') && control.formatting && v.length != control.ui.selectionEnd) {
                    e.preventDefault();
                    s && (control.ui.selectionEnd = --control.ui.selectionStart);  
                } 
                if(!e.key || e.key.length > 1 || e.ctrlKey) return ;
                if(control.formatting) {
                    control.ca++;
                    if(e.key == control.formatting[s]) { control.ui.selectionStart++; e.preventDefault(); return ; }
                    while(control.formatting[s] && '_XdDmMyY9'.indexOf(control.formatting[s])==-1) s++;
                    var ol = v.length, nl = CEditbox.formatting(v.substr(0, s) + e.key + v.substr(s + 1), control.formatting).length;
                    if(s < ol && nl >= ol || s >= ol && nl > ol ) {
                        control.ui.value = control.ui.value.substr(0, s) + control.ui.value.substr(s + 1); 
                        control.ui.selectionEnd = s; 
                    } else {
                        e.preventDefault();
                        return ;
                    }
                }
                if(control.pattern) {
                    m = (v = control.ui.value.substr(0, s) + e.key + control.ui.value.substr(control.ui.selectionEnd)).match(control.pattern);
                    (!m || m[0] != v) && (control.ca--, e.preventDefault());
                }
            }, false);
            var store = function() { 
                var f = control.formatting, p = control.pattern, data = CEditbox.patterning(CEditbox.formatting(control.ui.value, f), p); 
                if(control.transform) { 
                    var t = []; for(var i=0;i<control.transform.length; i++)
                        data.length > control.transform[i] && (t[i] = data.charAt(control.transform[i]));
                    for(var i=0;i<t.length; i++) 
                        t[i] = t[i]||' ';
                    data = t.join('');
                }
                control.notifications.push({ action : 'self' }); 
                control.store(rtd, data); 
            }
            uiUtils.addEventListener(control.ui, attrs.trigger||'keyup', store, false);
            uiUtils.addEventListener(control.ui, 'change', store, false);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        Array.isArray(data) && (data=data[0]), data || (data=''), data = data.toString();
        if(control.transform) { 
            var t = []; for(var i=0;i<data.length; i++) 
                control.transform.length > i && (t[control.transform[i]] = data.charAt(i));
            data = t.join('');
        }
        data = CEditbox.patterning(CEditbox.formatting(data, control.formatting), control.pattern);
        if(data != control.ui.value) {
            var v = control.ui.value, ss = control.ui.selectionStart;
            control.ui.value = data;
            if(control.formatting && ss >= control.ca && ss <= v.length && v != control.ui.value) {
               var over = control.formatting.substr(ss-control.ca, control.ca).replace(/[_XdDmMyY9]/g,'').length;
               control.ui.selectionEnd = control.ui.selectionStart = ss + over; 
            }
            control.ca = 0;
        }

        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }

    CEditbox.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) { 
        attrs.placeholder = attrs.disabled ? '' : control.formatting || attrs.placeholder;
        Component.setAttributes.call(this, rtd, control, data, errs, attrs, events);
    }

    CEditbox.prototype.appendError = function(control, ui, errs, attrs) {
        if(attrs.eclass) 
            uiUtils.setAttribute(control.ui, 'class', (attrs['class']||'') + (errs ? ' ' + attrs.eclass : ''));
        else 
            Component.appendError.call(this, control, ui, errs, attrs);
    }
    return new CEditbox();
})

define('components/editbox-$', ['components/editbox', 'ui-utils'], function(CEditbox, uiUtils) {
    var CEditboxD = function () {}
    CEditboxD.prototype = new CEditbox.constructor();
    CEditboxD.prototype.name = 'editbox-$';
    CEditboxD.prototype.constructor = CEditboxD;
    CEditboxD.formatting = function(v, n, l) {
        do {
            v = (n?'':'$') + v.replace(/[^\d]/g,'').replace(/(\d)(?=(\d{3})+$)/g, '$1,');
        } while(l && v.length > l && (v=v.substr(0, v.length-1)));
        return v;
    }  

    CEditboxD.prototype.render = function (rtd, control, data, errs, attrs, events) {
        control.maxlength = attrs.formatting && attrs.formatting.length;
        control.nodollar = attrs.formatting && attrs.formatting.charAt(0) != '$';
        if(!control.ui) {
            control.ui = document.createElement('input');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, 'keydown', function(e) {
                var ml = control.maxlength < CEditboxD.formatting(control.ui.value + '1', control.nodollar, 99).length;
                if(e.key == ',' && control.ui.value.charAt(control.ui.selectionStart) == ',') control.ui.selectionStart++;
                !e.ctrlKey && e.key && e.key.length == 1 && control.ui.selectionStart == control.ui.selectionEnd && (e.key < '0' || e.key > '9' || ml) && e.preventDefault();
            }, false);
            var store = function() { 
                var v = CEditboxD.formatting(control.ui.value, control.nodollar, control.maxlength);
                control.notifications.push({ action : 'self' }); control.store(rtd, v.replace(/[^\d]/g,'')); 
            }
            uiUtils.addEventListener(control.ui, attrs.trigger||'keyup', store, false);
            uiUtils.addEventListener(control.ui, 'change', store, false);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        Array.isArray(data) && (data=data[0]);
        if(typeof data == 'string' || typeof data == 'number') {
            var ss = control.ui.selectionStart, ov = control.ui.value, nv = CEditboxD.formatting(data, control.nodollar, control.maxlength), o = 0;
            if(ov != nv) {
                control.ui.value = nv;
                if(control.ui == document.activeElement) {
                    for(i=0;i<ss;i++) (nv.charAt(i) == ',' || nv.charAt(i) == '$') && o++, (ov.charAt(i) == ',' || ov.charAt(i) == '$') && o--;
                    control.ui.selectionStart = control.ui.selectionEnd = ss + o - (ov.charAt(ss) == ',' && nv.charAt(ss + o - 1) == ',' ? 1 : 0);
                }
            }
        } else control.ui.value = '';

        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }
    return new CEditboxD();
})

define('components/dropdown', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CDropdown = function (){}
    CDropdown.prototype = new Component.constructor();
    CDropdown.prototype.name = 'dropdown';
    CDropdown.prototype.constructor = CDropdown;
        // we assume {data.items} = [{value, description}] to be array of items and {data.value} to be one of those (or be something third if not selected)
    CDropdown.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('select');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, 'change', function(e){
                control.store(rtd, control.ui.options[control.ui.selectedIndex].value);
            }, true);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        //while (control.ui.firstChild) control.ui.removeChild(control.ui.firstChild);
        var s = 0, i = 0, opt, d = [];
        attrs['default'] && (!Array.isArray(attrs['default']) || (attrs['default']={value: attrs['default'], description: 'Please select...'})) && d.push(attrs['default']);
        data && Array.isArray(data.items) && (d = d.concat(data.items));
        //var html = [];
        var currentNode = control.ui.firstChild;
        d.forEach(function(v) {
            currentNode || control.ui.appendChild(currentNode = document.createElement('option'));
            if(typeof v == 'string' || typeof v == 'number') {
                currentNode.text = currentNode.value = v;
                if(data.value == v) s = i;
            } else {
                currentNode.value = v.value;
                currentNode.text = (v.description || v.value);
                if(data.value == v.value) s = i;
            }
            i++; currentNode = currentNode.nextSibling;
        });
        for(; currentNode; currentNode = currentNode.nextSibling) control.ui.removeChild(currentNode);
        control.ui.selectedIndex = s; 
        //var so = control.ui.options[control.ui.selectedIndex]; attrs.default || so && control.store(rtd, so.value);
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }
    return new CDropdown();
})

define('components/button', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CButton = function (){}
    CButton.prototype = new Component.constructor();
    CButton.prototype.name = 'button';
    CButton.prototype.constructor = CButton;

    CButton.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('input');
            control.ui.setAttribute('type', 'button');
            uiUtils.addEventListener(control.ui, 'click', function(e){control.store(rtd, control.ui.value);}, true);
            control.parentNode && control.parentNode.appendChild(control.ui);
        }
        control.ui.value = data;
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }

    CButton.prototype.appendError = function(control, parentNode, errs, attrs) {
        attrs.estyle ? uiUtils.setAttribute(control.ui, 'style', (attrs.style||'') + ';' + (errs && attrs.estyle || '')) : Component.appendError.call(this, control, parentNode, errs, attrs);
    }
    return new CButton();
})

define('components/container', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CContainer = function () { }
    CContainer.prototype = new Component.constructor();
    CContainer.prototype.name = 'container';
    CContainer.prototype.constructor = CContainer;
    CContainer.prototype.layout = 'tpos';
    CContainer.prototype.isContainer = function () { return true; }
    CContainer.prototype.runtime = function(control) {
        return control.runtime || (control.runtime = { fieldData: [], allocs : new Map() }); 
    }

    CContainer.prototype.emptyUI = function(rtd, control) {
        Component.emptyUI.call(this, rtd, control);
        var rt = this.runtime(control);
        rt.allocs = new Map();
        delete rt.headAlloc;
        delete rt.footAlloc;
    }

    CContainer.prototype.buildFieldData = function(control, previousData, attrs) {
        var l = control.field.listener, ret = [], d, pd, tpos, i=0, cls, nm; 
        previousData = previousData||[];
        ret.match = true, ret.attrs = attrs;
        (l.get(control.field.data, 'children')||[]).forEach(function(cf) {
            tpos = l.get(cf, 'tpos') || {}, cls=l.get(cf, 'class');
            if(attrs.skip && attrs.skip.indexOf(l.get(cf, 'name')) != -1) return ;
            tpos = {w: tpos.w > 1 && tpos.w, h: tpos.h > 1 && tpos.h, n: tpos.n=='Y', s: tpos.s }
            ret.push(d = { field: cf, clazz: (typeof cls == 'string' ? cls : ''), pos: tpos });
            pd = previousData[i++]||false;
            ret.match = ret.match && pd && d.clazz == pd.clazz && d.field == pd.field && tpos.s == pd.pos.s && tpos.w == pd.pos.w && tpos.h == pd.pos.h && tpos.n == pd.pos.n;
        });
        ret.match = ret.match && ret.length == previousData.length; // && this.checkAttributes(control, attrs, previousData.attrs);
        return ret;
    }

    CContainer.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
        var ret = { nodes: [], rows: [] }, td, tr, ib = nextAllocs && nextAllocs.rows[0];
        fieldData.forEach(function(fd) {
            if(fd.pos.n || !tr) {
                ui.insertBefore(tr = document.createElement('tr'), ib||null);
                ret.rows.push(tr);
            }
            ret.nodes.push(td = document.createElement(fd.clazz == '' ? 'td' : 'th'));
            td.setAttribute('valign', fd.clazz == '' ? 'top' : 'middle');
            tr.appendChild(td);
            fd.pos.w && td.setAttribute('colSpan', fd.pos.w);
            fd.pos.h && td.setAttribute('rowSpan', fd.pos.h);
            fd.pos.s && td.setAttribute(fd.pos.s.charAt(0) == '-' ? 'class' : 'style', fd.pos.s);
        }); 
        return ret;
    }

    CContainer.prototype.positionChildren = function(rtd, control, allocs, fieldData, rowData) {
        var children = rowData ? control.children.get(rowData) : control.fixedChildren, rt = this.runtime(control), i = 0;
        fieldData.forEach(function(fd) {
            var cc = children.get(fd.field);
            cc.component.setParentNode(cc, allocs.nodes[i++]);
        });
    }

    CContainer.prototype.render = function(rtd, control, data, errs, attrs, events) {
        if( ! (this.runtime(control).fieldData = this.buildFieldData(control, this.runtime(control).fieldData, attrs)).match ) {
            this.emptyUI(rtd, control);
        }
        if(!control.ui) {
            this.renderFx(rtd, control, data, errs, attrs, events);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        this.processRows(rtd, control, attrs, data || [], events);
        this.setAttributes(rtd, control, data, errs, attrs, events);
    }

    CContainer.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) {
        Component.setAttributes.call(this, rtd, control, data, errs, attrs, events);
        var rt = this.runtime(control), ha = rt.headAlloc, fa = rt.footAlloc, body = rt.allocs;
        ha && ha.rows.forEach(function(r) { uiUtils.setAttribute(r, 'class', attrs['rowclass$header']); uiUtils.setAttribute(r, 'style', attrs['rowstyle$header']); });
        fa && fa.rows.forEach(function(r) { uiUtils.setAttribute(r, 'class', attrs['rowclass$footer']); uiUtils.setAttribute(r, 'style', attrs['rowstyle$footer']); });
        body && body.forEach(function (aa) { aa.rows.forEach(function(r) { uiUtils.setAttribute(r, 'class', attrs.rowclass); uiUtils.setAttribute(r, 'style', attrs.rowstyle); })});
    }

    CContainer.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
        control.ui = document.createElement('table');
        uiUtils.isIE7 && control.ui.appendChild(control.ui_tbody = document.createElement('tbody'));
        control.parentNode && control.parentNode.appendChild(control.ui);
        var rt = this.runtime(control), elem;
        var hf = rt.fieldData.filter(function(fd) { return fd.clazz!='' && fd.clazz!='footer' });
        var ff = rt.fieldData.filter(function(fd) { return fd.clazz=='footer' });
        if(hf.length > 0) {
            control.ui.appendChild(elem = document.createElement('thead'));
            this.positionChildren(rtd, control, this.headAlloc = this.allocateNodes(control, elem, attrs, hf), hf);
        }
        if(ff.length > 0) {
            control.ui.appendChild(elem = document.createElement('tfoot'));
            this.positionChildren(rtd, control, this.footAlloc = this.allocateNodes(control, elem, attrs, ff), ff);
        }
    }

    CContainer.prototype.processRows = function(rtd, control, attrs, newRows, events) {
        var rt = this.runtime(control), newAllocs = new Map(), oldAllocs = rt.allocs, or = [], fieldData = rt.fieldData.filter(function(fd) {return fd.clazz=='';});
        oldAllocs.forEach(function(v,k){or.push(k)});
        var nr = this.orderFilter(rtd, control, attrs, newRows, events);
        for(var i = 0, j = 0; i < nr.length || j < or.length; ) {
            if(i == nr.length) {
                this.removeDataRow(rtd, control, oldAllocs, or[j++], newAllocs);
                continue ;
            }
            if(j == or.length) {
                this.insertRowBefore(rtd, control, attrs, nr[i++], newAllocs, fieldData, rt.footAlloc);
                continue ;
            }
            if(nr[i] != or[j]) { 
                var nn= nr[i+1], on = or[j+1];
                if(nn && nn == or[j])  
                    this.insertRowBefore(rtd, control, attrs, nr[i++], newAllocs, fieldData, oldAllocs.get(or[j]));
                else 
                    if( on == nr[i] )
                        this.removeDataRow(rtd, control, oldAllocs, or[j++], newAllocs);
                    else 
                        this.replaceRow(rtd, control, nr[i++], newAllocs, fieldData, oldAllocs, or[j++]);
            } else { newAllocs.set(nr[i++], oldAllocs.get(or[j++])); }
        }
        rt.allocs = newAllocs;
    }

    CContainer.prototype.orderFilter = function(rtd, control, attrs, newRows, events) {
        if(typeof attrs.filter == 'function') {
            newRows = newRows.filter(attrs.filter);
        }
        if(Array.isArray(attrs.filter)) { 
            var s = new Set(); 
            attrs.filter.forEach(function(r) { s.add(r.data) });
            newRows = newRows.filter(function(px) {return s.has(px.data)});
        }
        return (typeof attrs.order == 'function' ? newRows.sort(attrs.order) : newRows).map(function(r) { return r.data; });
    }

    CContainer.prototype.insertRowBefore = function(rtd, control, attrs, nd, newAllocs, fieldData, oldAlloc) {
        var nal = this.allocateNodes(control, control.ui_tbody||control.ui, attrs, fieldData, oldAlloc);
        newAllocs.set(nd, nal);
        this.positionChildren(rtd, control, nal, fieldData, nd);
    }

    CContainer.prototype.removeDataRow = function(rtd, control, oldAllocs, od, newAllocs) {
        !newAllocs.get(od) && (prevChildren = control.children.get(od)) && prevChildren.forEach(function(c) {c.component.setParentNode(c)});
        oldAllocs.get(od).rows.forEach(function(r) { (control.ui_tbody||control.ui).removeChild(r) } );
    }

    CContainer.prototype.replaceRow = function(rtd, control, nd, newAllocs, fieldData, oldAllocs, od) {
        var oldAlloc = oldAllocs.get(od), pc = control.children.get(od), c;
        newAllocs.set(nd, oldAlloc);
        pc && !newAllocs.get(od) && fieldData.forEach(function(f) { var c = pc.get(f.field); c.component.setParentNode(c) }); //pc.forEach(function(c) {c.component.setParentNode(c)});
        this.positionChildren(rtd, control, oldAlloc, fieldData, nd);
    }
    return new CContainer();
})

define('components/div', ['components/component', 'components/container', 'ui-utils'], function(Component, CContainer, uiUtils) {
    var CDiv = function () {};
    CDiv.prototype = new CContainer.constructor();
    CDiv.prototype.name = 'div';
    CDiv.prototype.constructor = CDiv;
    CDiv.prototype.layout = 'dpos';
    CDiv.prototype.buildFieldData = function(control, previousData, attrs) {
        var l = control.field.listener, ret = [], pd, dp, dpos, i=0, cls, nm; 
        ret.match = true, ret.attrs = attrs;
        previousData = previousData||[];
        (l.get(control.field.data, 'children')||[]).forEach(function(cf) {
            dp = l.get(cf, 'dpos') || {}, cls = l.get(cf, 'class'), nm = l.get(cf, 'name'), dpos = {};
            if( attrs.skip && attrs.skip.indexOf(nm) != -1 ) return ;
            if( dp.colclass && dp.colclass != 0 ) dpos.colclass = dp.colclass;
            if( dp.colstyle && dp.colstyle != 0 ) dpos.colstyle = dp.colstyle;
            var d = { field: cf, clazz: (typeof cls == 'string' ? cls : ''), pos: dpos };
            if( nm == attrs.hfield ) {
                pd = previousData.headField;
                ret.headField = d;
            } else {
                pd = previousData[i++]||false;
                ret.push(d);
            }
            ret.match = ret.match && pd && d.clazz == pd.clazz && d.field == pd.field && dpos.colclass == pd.pos.colclass && dpos.colstyle == pd.pos.colstyle;
        });
        ret.match = ret.match && ret.length == previousData.length; // && this.checkAttributes(control, attrs, previousData.attrs);
        return ret;
    }

    CDiv.prototype.setAttributes = Component.setAttributes;

    CDiv.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
        var ret = { nodes: [], rows: [] }, div, ib = nextAllocs && nextAllocs.rows[0];
        fieldData.forEach(function(fd) {
            ui.insertBefore(div = document.createElement('div'), ib||null);
            ret.rows.push(div);
            ret.nodes.push(div)
            fd.pos.colclass && div.setAttribute('class', fd.pos.colclass);
            fd.pos.colstyle && div.setAttribute('style', fd.pos.colstyle);
        }); 
        return ret;
    }

    CDiv.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
        control.ui = document.createElement('div');
        control.parentNode && control.parentNode.appendChild(control.ui);
        var rt = this.runtime(control), hf = rt.fieldData.filter(function(fd) { return fd.clazz!='' });
        hf.length > 0 && this.positionChildren(rtd, control, rt.headAlloc = this.allocateNodes(control, control.ui, attrs, hf), hf);
    }
    return new CDiv();
})

define('components/div-r', ['components/container', 'components/div', 'ui-utils'], function(CContainer, CDiv, uiUtils) {
    var CDivR = function () { }
    CDivR.prototype = new CDiv.constructor();
    CDivR.prototype.name = 'div-r';
    CDivR.prototype.setAttributes = CContainer.setAttributes;
    CDivR.prototype.constructor = CDivR;
    CDivR.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
        var ret = { nodes: [], rows: [] }, rdiv, div, ib = nextAllocs && nextAllocs.rows[0];
        ui.insertBefore(rdiv = document.createElement('div'), ib||null);
        ret.rows.push(rdiv);
        fieldData.forEach(function(fd) {
            rdiv.appendChild(div = document.createElement('div'));
            uiUtils.setAttribute(div, 'class', fd.pos.colclass);
            uiUtils.setAttribute(div, 'style', fd.pos.colstyle);
            ret.nodes.push(div);
        }); 
        return ret;
    }
    return new CDivR();
})

define('components/tab-s', ['components/div-r', 'ui-utils'], function(CDivR, uiUtils) {
    var CTab = function () { }
    CTab.prototype = new CDivR.constructor();
    CTab.prototype.name = 'tab-s';
    CTab.prototype.constructor = CTab;
    
    CTab.prototype.render = function(rtd, control, data, errs, attrs, events) {
        CDivR.render.call(this, rtd, control, data, errs, attrs, events);
        var headAlloc = this.runtime(control).headAlloc.rows[0], rt = this.runtime(control), headField = rt.fieldData.headField;
        while(headAlloc.lastChild) headAlloc.removeChild(headAlloc.lastChild);
        if(headField) {
            control.children.forEach(function(fl, modelData){ 
                var c = fl.get(headField.field), div, span, pos = headField.pos;
                c.component.setParentNode(c, headAlloc.appendChild(div = document.createElement('div')));
                uiUtils.setAttribute(div, 'class', (pos && pos.colclass||'') + (modelData == rt.activeTab && attrs.haclass ? ' ' + attrs.haclass : ''));
                uiUtils.setAttribute(div, 'style', pos && pos.colstyle);
                uiUtils.addEventListener(div, 'click', function(e) {
                    if(modelData != rt.activeTab) { rt.activeTab = modelData; control.notifications.push({ action : 'self' }); }
                }, false);
            });
        }
    }

    CTab.prototype.orderFilter = function(rtd, control, attrs, newRows, events) {
        var l = control.model.listener, rt = this.runtime(control), nrS = new Set(), has, at = rt.activeTrack; rt.activeTrack = [];
        attrs.focusnew && events.forEach(function(e) { rt.activeTab = e.action == 'a' ? e.d1 : rt.activeTab });
        newRows.forEach(function(r) { nrS.add(r.data); has |= r.data == rt.activeTab });
        for(var i = 0; at && i < at.length; i++) nrS.has(at[i]) && rt.activeTrack.push(at[i]);
        has ? rt.activeTrack.push(rt.activeTab) : rt.activeTab = rt.activeTrack[rt.activeTrack.length - 1] || newRows.length && newRows[0].data;
        //newRows.filter(function(r) { return r.data == rt.activeTab}).length || (rt.activeTab = newRows.length ? newRows[0].data : 0);
        return rt.activeTab ? [rt.activeTab]:[];
    }

    CTab.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
        control.ui = document.createElement('div');
        control.parentNode && control.parentNode.appendChild(control.ui);
        this.runtime(control).headAlloc = { rows: [control.ui.appendChild(document.createElement('div'))] };
    }

    CTab.activeModel = function(control) {
        var ac = control.children.get(control.component.runtime(control).activeTab);
        ac = (ac && ac.values().next().value);
        return ac.model;
    }
    return new CTab();
})

define('components/div-c', ['components/div', 'ui-utils'], function(CDiv, uiUtils) {
    var CDivC = function () { }
    CDivC.prototype = new CDiv.constructor();
    CDivC.prototype.name = 'div-c';
    CDivC.prototype.constructor = CDivC;
    CDivC.prototype.allocateNodes = function(control, ui, attrs, fieldData, nextAllocs) {
        var ret = { nodes: [], rows: [] };
        for(var columns = this.runtime(control).columns, i = 0; i < fieldData.length; i++) {
            var fd = fieldData[i], div = document.createElement('div');
            columns[i].insertBefore(div, nextAllocs && nextAllocs.nodes[i]||null);
            ret.rows.push(div);
            ret.nodes.push(div);
            fd.pos.colclass && div.setAttribute('class', fd.pos.colclass);
            fd.pos.colstyle && div.setAttribute('style', fd.pos.colstyle);
        } 
        return ret;
    }

    CDivC.prototype.renderFx = function(rtd, control, data, errs, attrs, events) {
        control.ui = document.createElement('div');
        control.parentNode && control.parentNode.appendChild(control.ui);
        var rt = this.runtime(control), fd = rt.fieldData, hf = fd.filter(function(fd) { return fd.clazz!='' }), elem;
        rt.columns = [];
        for(i = 0; i < Math.max(hf.length, fd.length - hf.length); i++) {
            rt.columns.push(elem = document.createElement('div')); control.ui.appendChild(elem);
        }
        hf.length > 0 && this.positionChildren(rtd, control, rt.headAlloc = this.allocateNodes(control, control.ui, attrs, hf), hf);
    }

    CDivC.prototype.setAttributes = function(rtd, control, data, errs, attrs, events) {
        CDiv.setAttributes.call(this, rtd, control, data, errs, attrs, events);
        var rt = this.runtime(control);
        for(i = 0; i < rt.columns.length; i++) {
            uiUtils.setAttribute(rt.columns[i], 'class', attrs['rowclass$'+i]||attrs['rowclass$header']);
            uiUtils.setAttribute(rt.columns[i], 'style', attrs['rowstyle$'+i]||attrs['rowstyle$header']);
        }
    }

    CDivC.prototype.removeDataRow = function(rtd, control, oldAllocs, od, newAllocs) {
        var oldAlloc = oldAllocs.get(od), prevChildren = control.children.get(od);
        prevChildren && !newAllocs.get(od) && prevChildren.forEach(function(c) {c.component.setParentNode(c)});
        for(var columns = this.runtime(control).columns, i=0; i < oldAlloc.rows.length; i++)
            columns[i].removeChild(oldAlloc.rows[i]);
    }
    return new CDivC();
})

define('components/checkbox', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CCheckbox = function () { }
    CCheckbox.prototype = new Component.constructor();
    CCheckbox.prototype.name = 'checkbox';
    CCheckbox.prototype.constructor = CCheckbox;
    CCheckbox.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('input'); 
            control.mUI = [document.createElement('label')];
            control.ui.setAttribute('type', 'checkbox');
            if(control.parentNode) {
                control.parentNode.appendChild(control.ui);
                control.parentNode.appendChild(control.mUI[0]);
            }
            uiUtils.addEventListener(control.ui, 'change', function(e){ control.store(rtd, control.ui.checked ? 'Y' : 'N')}, true);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        if(Array.isArray(data)) data = data[0];
        data || (data='N');
        control.ui.checked =  typeof data == 'object' ? (data.checked != 0 && 'Yy'.indexOf(data.checked) != -1) : ('Yy'.indexOf(data) != -1);
        control.mUI[0].innerText = data.text||'';

        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs, 1);
    }
    return new CCheckbox();
})

define('components/radiolist', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CRadiolist = function (){ }, incId = 0;
    CRadiolist.prototype = new Component.constructor();
    CRadiolist.prototype.name = 'radiolist'; 
    CRadiolist.prototype.constructor = CRadiolist;
    CRadiolist.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('div');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, 'change', function(e){
                var selected = [], cc = control.ui.children;
                for(var i = cc.length - 1; i >= 0; i--)
                    if(cc[i].checked) { selected = cc[i].value; break ; }
                control.store(rtd, selected);
            }, true);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        var orientation = attrs.orientation;
        if( orientation != 'horizontal') orientation = 'vertical';
        if(Array.isArray(data)) data = data[0];
        control.radioname || (control.radioname = ++incId);
        data || (data = control.data||{});
        typeof data == 'string' && (data = {value: data});
        if(!data.items) data.items =  [{value :'Y', description : 'Yes'}, {value :'N', description : 'No'}];
        var innerHTML = '', r;
        if(data.items) {
            data.items.forEach( function(it) {
                r = document.createElement('input'); 
                r.setAttribute('type', 'radio'); 
                r.setAttribute('name', control.radioname); 
                r.setAttribute('value', it.value); 
                if(it.value == data.value) { /*reset = false;*/ r.setAttribute('checked', 'checked'); } 
                innerHTML += uiUtils.isIE7 ? r.outerHTML.replace(' ', ' name="' + control.radioname + '" ') : r.outerHTML;
                r = document.createElement('label'); 
                r.innerHTML = (it.description == null ? it.value : it.description); 
                innerHTML += (r.outerHTML + (orientation == 'vertical' ? '</br>' : ''));
            });
            //if(data.items.length > 0 && reset) control.store(rtd, []);
        }
        control.ui.innerHTML = innerHTML;
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.ui, errs, attrs);
    }
    return new CRadiolist();
})
 
define('components/label', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CLabel = function () { }
    CLabel.prototype = new Component.constructor();
    CLabel.prototype.name = 'label';
    CLabel.prototype.constructor = CLabel;

    CLabel.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('label');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, 'click', function(e){control.store(rtd, 'clicked')});
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        control.ui.innerHTML = data;
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }
    return new CLabel();
})

define('components/html', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CHtml = function () { }
    CHtml.prototype = new Component.constructor();
    CHtml.prototype.name = 'html';
    CHtml.prototype.constructor = CHtml;

    CHtml.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('div');
            control.parentNode && control.parentNode.appendChild(control.ui);
        }
        control.ui.innerHTML = data;
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.ui, errs, attrs);
        this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
    }
    return new CHtml();
})

define('components/textarea', ['components/editbox', 'ui-utils'], function(CEditbox, uiUtils) {
    var CTextarea = function () { }
    CTextarea.prototype = new CEditbox.constructor();
    CTextarea.prototype.name = 'textarea';
    CTextarea.prototype.constructor = CTextarea;

    CTextarea.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('textarea');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, attrs.trigger||'keyup', function(e){ control.store(rtd, control.ui.value)});
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
        }
        control.ui.value == data || (control.ui.value = data);
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
    }
    return new CTextarea();
})

define('components/editbox-P', ['components/editbox', 'ui-utils'], function(CEditbox, uiUtils) {
    var CEditPopup = function () { }
    CEditPopup.prototype = new CEditbox.constructor();
    CEditPopup.prototype.name = 'editbox-P';
    CEditPopup.prototype.constructor = CEditPopup;

    CEditPopup.prototype.render = function (rtd, control, data, errs, attrs, events) {
        var rt = this.runtime(control), self = this;
        if(!control.ui) {
            control.ui = document.createElement('input');
            control.parentNode && control.parentNode.appendChild(control.ui);
            uiUtils.addEventListener(control.ui, 'focus', function(e) { self.showPopup(rtd, control) });
            uiUtils.addEventListener(control.ui, 'click', function(e) { self.showPopup(rtd, control) });
            uiUtils.addEventListener(control.ui, attrs.trigger || 'keyup', function(e) { control.currentValue === control.ui.value || control.store(rtd, control.ui.value) });
            uiUtils.addEventListener(control.ui, 'keydown', function(e) { 
                (e.key == 'Esc' || e.key == 'Escape') && rt.ta && control.closePopup();
                e.key == 'Enter' && (e.preventDefault(), self.showPopup(rtd, control), self.getPopupActiveElement(control).focus());
                e.key == 'Tab' && rt.ta && (self.getPopupActiveElement(control).focus(), e.preventDefault());
            });
        }
        this.setValue(rtd, control, data, errs, attrs, events);
        this.setAttributes(rtd, control, data, errs, attrs, events);
        this.appendError(control, control.parentNode, errs, attrs);
        this.setPopupAttributes(rtd, control, attrs.ta||{}, errs);
        this.updatePopupContent(control, data, attrs);
    }

    CEditPopup.prototype.setValue = function(rtd, control, data, errs, attrs, events) {
        control.ui.value === data || (control.ui.value = data);
        control.currentValue = control.ui.value;
    }
    
    CEditPopup.prototype.updatePopupContent = function(control, data, attrs) {
        var rt = this.runtime(control);
        rt.ta && rt.popup && !rt.ta.contains(control.ui.ownerDocument.activeElement) && (rt.popup.value == data || (rt.popup.value = data, rt.popup.selectionStart = rt.popup.selectionEnd = 0, rt.popup.scrollTop = 0));
    }

    CEditPopup.prototype.getPopupUi = function(rtd, control) {
        var attrs = control.model.attrs, rt = this.runtime(control), p = rt.popup;
        if(!rt.popup) { 
            rt.popup = p = control.ui.ownerDocument.createElement('textarea');
            uiUtils.setAttribute(p, 'class', 'edit-popup-textarea');
            uiUtils.addEventListener(p, attrs.trigger || 'keyup', function(){ 
                control.store(rtd, control.ui.value = p.value);
                control.currentValue = p.value;
            });
            uiUtils.addEventListener(p, 'keydown', function(e) { 
                (e.key == 'Esc' || e.key == 'Escape') && (control.ui.focus(), control.closePopup()) 
                e.key == 'Tab' && (control.ui.focus(), e.preventDefault()); // ??
            });
        }
        return p;
    }

    CEditPopup.prototype.onResize = function(control) { }
    CEditPopup.prototype.getPopupActiveElement = function(control) { 
        return this.runtime(control).popup 
    }
    CEditPopup.prototype.onClosePopup = function(control) {}
    CEditPopup.prototype.purge = function (runtime, control) { control.closePopup && rt.ta && control.closePopup(); this.emptyUI(runtime, control); }

    CEditPopup.prototype.showPopup = function(rtd, control) {
        var rt = this.runtime(control), scrollFollow, escUnf, doc = control.ui.ownerDocument, self = this;
        if(control.ui && !rt.ta) {
            this.createPopup(rtd, control);
            this.updatePopupContent(control, control.data, control.model.attrs);
            (scrollFollow = function() {
                var r = control.ui.getBoundingClientRect(), op = control.ui.offsetParent, wnd = doc.defaultView||window;
                rt.ta.style.display = (op.scrollTop > control.ui.offsetTop + control.ui.offsetHeight || op.scrollTop + op.clientHeight < control.ui.offsetTop + control.ui.offsetHeight) ? 'none' : '';
                rt.ta.style.top = (r.bottom + 2 + (wnd.scrollY||wnd.pageYOffset) + (rt.ta_t||0)) + 'px';
                rt.ta.style.left = (r.left + (wnd.scrollX||wnd.pageXOffset) + (rt.ta_l||0)) + 'px';
            })();
            for(var e = control.ui; e; e = e.parentElement) e.addEventListener('scroll', scrollFollow);
            var i = setInterval(function() {
                doc.activeElement != control.ui && !rt.resizeOngoing && ! rt.ta.contains(doc.activeElement) && control.closePopup();
            }, 30);
            control.closePopup = function() {
                for(var e = control.ui; e; e = e.parentElement) uiUtils.removeEventListener(e, 'scroll', scrollFollow);
                uiUtils.removeEventListener(self.getPopupActiveElement(control), 'keydown', escUnf);
                clearInterval(i);
                self.onClosePopup(control);
                rt.ta.remove();
                delete rt.ta;
            }
            uiUtils.addEventListener(self.getPopupActiveElement(control), 'keydown', (escUnf = function(e) { 
                e.key == 'Escape' && !e.defaultPrevented && (control.ui.focus(), control.closePopup());
            }));
        }    
    }

    CEditPopup.prototype.createPopup = function(rtd, control) {
        var rt = this.runtime(control), doc = control.ui.ownerDocument, attrs = control.model.attrs, handle, self = this;
        rt.ta = doc.createElement('div'); 
        rt.ta.appendChild(this.getPopupUi(rtd, control));
        rt.ta.appendChild(handle = document.createElement('span'));
        doc.getElementsByTagName('body')[0].appendChild(rt.ta);
        this.setPopupAttributes(rtd, control, attrs.ta||{}, control.error);
        handle.setAttribute('class', 'ui-resizeable-handle-br');
        handle.addEventListener('mousedown', function(ie) {
            rt.resizeOngoing = 1;
            var ox = ie.screenX, oy = ie.screenY, w = rt.ta.offsetWidth, h = rt.ta.offsetHeight, move, up;
            document.addEventListener('mousemove', move = function(me) {
                self.onResize(control);
                rt.ta.style.width = rt.ta_w = (w + me.screenX - ox) + 'px';
                rt.ta.style.height = rt.ta_h = (h + me.screenY - oy) + 'px';
                me.preventDefault(), window.getSelection().removeAllRanges();
            });
            document.addEventListener('mouseup', up = function(me) {
                rt.resizeOngoing = 0;
                uiUtils.removeEventListener(document, 'mousemove', move);
                uiUtils.removeEventListener(document, 'mouseup', up);
                self.getPopupActiveElement(control).focus();
            });
        });
    }

    CEditPopup.prototype.setPopupAttributes = function(rtd, control, attrs, errs) {
        var rt = this.runtime(control);
        if(rt.ta) {
            var st = rt.ta.style, w = st.width||rt.ta_w, h = st.height||rt.ta_h, t = st.top, l = st.left;
            rt.ta_l = attrs.offsetLeft, rt.ta_t = attrs.offsetTop; 
            attrs['class'] = (attrs['class']||'') + (errs && attrs.eclass ? ' ' + attrs.eclass : '');
            this.setAttributesUI(rtd, rt.ta, control.data, errs, attrs, []);
            w && (st.width = w), h && (st.height = h), t && (st.top = t), l && (st.left = l);
        }
    }
    return new CEditPopup();
})

define('components/div-button', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CDivButton = function (){ }
    CDivButton.prototype = new Component.constructor();
    CDivButton.prototype.name = 'div-button';
    CDivButton.prototype.constructor = CDivButton;

    CDivButton.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(!control.ui) {
            control.ui = document.createElement('div');
            control.ui.appendChild(control.ui_text = document.createElement('label'));
            control.ui.appendChild(control.ui_error = document.createElement('label'));
            control.ui_text.setAttribute('class', 'div-button-text');
            control.ui_error.setAttribute('class', attrs.eclass || 'div-button-error'); 
            uiUtils.addEventListener(control.ui, 'click', function(e){control.store(rtd, data)});
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
            control.parentNode && control.parentNode.appendChild(control.ui);
        }
        var e = errs ? 'error' : '';
        if(control.ui_text.innerHTML != data) control.ui_text.innerHTML = data;
        if(control.ui_error.innerHTML != e) control.ui_error.innerHTML = e;
        this.setAttributes(rtd, control, data, errs, attrs, events);
    }
    return new CDivButton();
})

define('components/multioption', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CMultiOption = function () { }
    CMultiOption.prototype = new Component.constructor();
    CMultiOption.prototype.name = 'multioption';
    CMultiOption.prototype.constructor = Component;
    CMultiOption.prototype.render = function (rtd, control, data, errs, attrs, events) {
        if(Array.isArray(data.value)) data.value = data.value[0];
        if(control.ui != undefined) {
            this.emptyUI(rtd, control);
        }
        if( data != undefined && Array.isArray(data.options) ) {
            control.ui = document.createElement('div');
            this.setAttributes(rtd, control, data, errs, attrs, events);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);
            var select = new Set(), d, c, cc = [];
            (typeof data.value == 'string' ? data.value.split(';') : []).forEach(function(a) { select.add(a) });
            data.options.forEach(function (o) {
                control.ui.appendChild(d = document.createElement('div'));
                attrs.rowclass && d.setAttribute('class', attrs.rowclass);
                attrs.rowstyle && d.setAttribute('style', attrs.rowstyle);
                c = document.createElement('input');
                c.setAttribute('type', 'checkbox');
                d.appendChild(c);
                cc.push(c);
                c.checked = select.has(c.value = o.value);
                uiUtils.addEventListener(c, 'change', function(e){
                    control.store(rtd, cc.map(function(c) {return c.checked ? c.value : -1}).filter(function(v) {return v != -1}).join(';'));//cc.map(c => c.checked ? c.value : -1).filter(v => v != -1).join(';'));
                }, true);
                d.appendChild(c = document.createElement('label'));
                c.setAttribute('style', 'align-self: center;');
                c.innerText = (o.description != undefined ? o.description : o.value);
            }, this);
            control.parentNode && control.parentNode.appendChild(control.ui);
        }
    }
    return new CMultiOption();
})

define('components/typeahead', ['components/component', 'ui-utils', 'jquery', 'jquery-typeahead'], function(Component, uiUtils, $, ta) {
    var CTypeAheadA = function () { }
    CTypeAheadA.prototype = new Component.constructor();
    CTypeAheadA.prototype.name = 'typeahead';
    CTypeAheadA.prototype.constructor = Component;
    CTypeAheadA.prototype.defaultOPTS = { source : {}, minLength: 1, maxItem: 8, maxItemPerGroup: 6, order: "asc", hint: true, searchOnFocus: true, debug: false, display: ['value','description'], template: '{{value}}: {{description}}', emptyTemplate: 'no result for {{query}}' }

    CTypeAheadA.prototype.render = function (rtd, control, data, errs, attrs, events) {
        var rt = this.runtime(control), prevValue = '', self = this, s;
        if(!control.ui) {
            control.ui = document.createElement('div');
            control.ui.innerHTML = '<div class="typeahead__field"><span class="typeahead__query"><input type="search" autocomplete="off"/></span></div>';
            control.ui.setAttribute('class', 'typeahead__container');
            self.setEvents(rtd, control.ui, control, data, errs, attrs, events);
            rt.node = control.ui.firstChild.firstChild.firstChild;
            rt.memorizedItem = {};
            opts = _extend( attrs && attrs.options, self.defaultOPTS );
            opts.callback = { onClickAfter: function (node, a, item, event) { control.store(rtd, rt.memorizedItem = item) } }
            $(rt.node).typeahead( opts );
            control.parentNode && control.parentNode.appendChild(control.ui);
        }

        if( data && data.status != 'loading' ) {
            $(rt.node).prop('disabled', false);
            $(rt.node).typeahead('hideloading');
            if( rt.url != data.url ) {
                rt.url = data.url;
                $(rt.node).typeahead( { source : { data : data.items} }, 'reload' );
            }
            if(!data.found) {
                if(data.items.length > 0) {
                    control.store(rtd, rt.memorizedItem = {});
                    $(rt.node).typeahead('clean');
                } else {
                    $(rt.node).prop('disabled', true).val('No results found for given criteria');
                }
            } else {
                var match = true; for(v in data.value) match = match && rt.memorizedItem[v] == data.found[v];
                match || (rt.memorizedItem = data.found);
                rt.node.value = rt.memorizedItem[attrs.display || 'description'];     //$(rt.node).typeahead('close');
            }
        } else 
            $(rt.node).typeahead('showloading');
    }

    CTypeAheadA.prototype.emptyUI = function(rtd, control) {
        if(control.ui) {
            $(rtd.node).typeahead( 'destroy' );
            Component.emptyUI(rtd, control);
        }
    }
    return new CTypeAheadA();
})

define('components/placeholder', ['components/component', 'ui-utils'], function(Component, uiUtils) {
    var CPlaceholder = function () {}
    CPlaceholder.prototype = new Component.constructor();
    CPlaceholder.prototype.name = 'placeholder'; 
    CPlaceholder.prototype.constructor = CPlaceholder;
    CPlaceholder.prototype.keepmUI = true;
    CPlaceholder.prototype.render = function (rtd, control, data, errs, attrs, events) {
        var tagname = attrs.tagname || 'div', pp = control.parentNode && control.parentNode.parentNode;
        control.ui = 1;
        this.emptyUI(rtd, control);
        data = Array.isArray(data) ? data.length : data;
        for(i=0; i<data; i++) {
            pp && pp.insertBefore(control.mUI[i] = document.createElement(tagname), control.parentNode.nextSibling||null);
            this.setAttributesUI(rtd, control.mUI[i], data, errs, attrs, events);
        }
    }
    CPlaceholder.prototype.setParentNode = function(control, pnode) {
        if(pnode)
            (control.mUI||[]).forEach(function(ui) { pnode.parentNode && pnode.parentNode.insertBefore(ui, pnode.nextSibling||null)});
        else 
            (control.mUI||[]).forEach(function(ui) { ui.parentNode && ui.parentNode.removeChild(ui)});
        control.parentNode = pnode;
    }

    CPlaceholder.prototype.emptyUI = function (runtime, control) {
        (control.mUI||[]).forEach(function(ui) { ui.parentNode && ui.parentNode.removeChild(ui)});
        control.mUI = [];
    }
    return new CPlaceholder();
})

define('components/div-button-x', ['components/div-button', 'ui-utils'], function(CDivButton, uiUtils) {
    var CDivButtonX = function (){ }
    CDivButtonX.prototype = new CDivButton.constructor();
    CDivButtonX.prototype.name = 'div-button-x';
    CDivButtonX.prototype.constructor = CDivButtonX;

    CDivButtonX.prototype.render = function (rtd, control, data, errs, attrs, events) {
        CDivButton.render.call(this, rtd, control, data, errs, attrs, events);
        control.ui.style.position = 'relative';
        if(!control.ui_x) {
            control.ui_x = document.createElement('input')
            control.ui_x.value = 'x';
            control.ui_x.setAttribute('type', 'button');
            control.ui_x.setAttribute('class', 'div-button-x');
            control.ui.appendChild(control.ui_x);
            uiUtils.addEventListener(control.ui_x, 'click', function(e){ e.stopImmediatePropagation(); control.store(rtd, 'x') }, true);
            this.setEvents(rtd, control.ui, control, data, errs, attrs, events);        
       }
       control.ui_x.style.visibility = (attrs.ta && !attrs.ta.visible) ? 'hidden' : 'visible';
    }
    return new CDivButtonX();
})

//==================================================================================================================================================
define('components/editbox-code', ['components/editbox-P', 'ace/ace', 'ui-utils', 'uglify'], function(CEditPopup, ace, uiUtils, uglifyJS) {
    //little how-to: https://ace.c9.io/#nav=howto&api=virtual_renderer
    //https://github.com/ajaxorg/ace
    //https://github.com/ajaxorg/ace/wiki/Syntax-validation
    //_addEventListener(window, 'load', function() {

    var aceEditor = ace.edit(document.createElement('div'));
    aceEditor.container.style.width = aceEditor.container.style.height = '100%';
    aceEditor.setTheme('ace/theme/eclipse');  //dawn, eclipse, iplastic, kuroir, textmate
    aceEditor.setShowPrintMargin(false);
    aceEditor.$blockScrolling = Infinity;
    aceEditor.commands.on('exec', function(e) {
       e.command.name == 'Esc' && aceEditor.completer.popup && aceEditor.completer.popup.isOpen && e.stopPropagation();
    });
    //rt.session.setUseSoftTabs(true);
    // intellisense: https://stackoverflow.com/questions/26239090/javascript-intellisense-in-ace-editor
    ace.config.loadModule('ace/ext/tern', function () {
                /* taken from http://sevin7676.github.io/Ace.Tern/demo.html#html */
                /* http://ternjs.net/doc/manual.html#option_defs */
                /* http://ternjs.net/doc/manual.html#plugins */    
        aceEditor.setOptions({
            enableTern: {
                defs: ['browser', 'ecma5', 'jquery'], 
                plugins: { 
                    doc_comment: { fullDocs: true } 
                }, 
                //useWorker: false, 
                startedCb: function () {
                 $('script').each(function(){ 
                     if(this.src.match(/components\/editbox-code.js$/)) {
                         var url = this.src, src = ['ui-utils', 'dfe-core', 'extras', 'hints']; // $('script').each( ... )
                         $.when.apply($, src.map(function(s) { return $.get(url.replace(/components\/editbox-code/, s), 0, 0, 'text')})).done(function() {
                             for(i = 0; i < arguments.length; i++)
                                 aceEditor.ternServer.addDoc(src[i], arguments[i][0]);
                         });
                     }
                 })
                },
            },
            enableSnippets: true,
            enableBasicAutocompletion: true,
        });
    });

    function formatCode(control, text, func) {
        if(text == 0 ) return '';
        var s = uglifyJS.OutputStream({ comments: true, beautify: true, quote_style: 3 }), // 
            code = func && typeof func.name == 'string' ? (
                    typeof func.of == 'string' ? func.of + '.prototype.' + func.name + ' = function() {\n\t' + (func.cmnt ? '/* ' + func.cmnt + ' */\n\t' : '') + text + '\n}' :
                       'function ' + func.name + '(' + (func.args ? func.args.join(',') : '') + ') {\n\t' +
                        (func.cmnt ? '/* ' + func.cmnt + ' */\n\t' : '') + ( func.ret && needsReturn(uglifyJS, text) ? 'return ' : '') + text + '\n}') : text;
        uglifyJS.parse(code).print(s);
        return s.toString();
    }

    function tryExtractCode(control, text, func) {
        try {
            if(func) {
                var b = uglifyJS.parse(text).body, s = uglifyJS.OutputStream({ quote_style: 3 });
                if( b.length != 1 || func.of && (! (b[0] instanceof uglifyJS.AST_SimpleStatement) || !(b[0].body.right instanceof uglifyJS.AST_Function) ) ) throw 'illegal structure';
                (func.of ? b[0].body.right : b[0]).print(s);
                text = s.toString().replace(/^[^{]*{(return *)?|};?$/g,'');
            }
            control.notifications.push({ action : 'self' }); 
            control.store(control.model.runtime, text);
        } catch(e) { console.error(e), control.error || control.model.error('compilation error') }
    }

    var CEditCode = function () {}
    CEditCode.prototype = new CEditPopup.constructor();
    CEditCode.prototype.constructor = CEditCode;
    CEditCode.prototype.name = 'editbox-code';
    ['func', 'lang', 'fontSize'].forEach(function(a) { CEditCode.prototype.skipattrs.add(a) });

    CEditCode.prototype.setValue = function(rtd, control, data, errs, attrs, events) {
        if(!errs) {
            control.ui.value === data || (control.ui.value = data);
            control.currentValue = control.ui.value;
        } else {
            control.currentValue = data;
        }
    }
        
    CEditCode.prototype.updatePopupContent = function(control, data, attrs) {
        var rt = this.runtime(control);
        !(rt.ta && rt.ta.contains(control.ui.ownerDocument.activeElement)) && rt.session && rt.session.setValue(formatCode(control, data, attrs.ta.func));
    }

    CEditCode.prototype.getPopupUi = function(rtd, control) {
        var attrs = control.model.attrs, rt = this.runtime(control);
        if(!rt.session) { 
            rt.session = require('ace/ace').createEditSession(formatCode(control, control.data, attrs.ta.func), 'ace/mode/' + (attrs.ta.lang||'javascript'));
            rt.session.on('change', function(e) { new Error().stack.indexOf('.setValue') == -1 && tryExtractCode(control, rt.session.getValue(), attrs.ta.func) });
        }
        aceEditor.setSession(rt.session);
        return aceEditor.container;
    }

    CEditCode.prototype.onResize = function(control) { aceEditor.resize() }
    CEditCode.prototype.getPopupActiveElement = function(control) { return aceEditor.renderer.textarea }
    CEditCode.prototype.onClosePopup = function(control) {}
    CEditCode.prototype.purge = function (runtime, control) { rt = this.runtime(control), rt.session && rt.session.destroy(); this.emptyUI(runtime, control); }
    CEditCode.prototype.setPopupAttributes = function(rtd, control, attrs, errs) {
        CEditPopup.setPopupAttributes.call(this, rtd, control, attrs, errs);
        this.runtime(control).ta && (this.getPopupUi(rtd, control).style.fontSize = attrs.fontSize||'14px', aceEditor.resize());
    }
    return new CEditCode();
})
