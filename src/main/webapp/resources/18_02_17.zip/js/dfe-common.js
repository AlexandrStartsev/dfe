define('dfe-common', ['exports'], function(exports) {
	
	function _extend(from, to) { 
	    for (var key in from) to[key] = from[key]; return to;
	}
	//#################################################################################################################
	
	function yyyymmdd(dt) {
	  var mm = dt.getMonth() + 1, dd = dt.getDate();
	  return [dt.getFullYear(),(mm>9 ? '' : '0') + mm,(dd>9 ? '' : '0') + dd].join('');
	}
	
	function ARFtoDate(ad) { 
	    Array.isArray(ad) && (ad=ad[0]);
	    var dt = new Date(ad.substr(0, 4),ad.substr(4, 2)-1,ad.substr(6, 2)); 
	    return (dt == 'Invalid&nbsp;Date' || yyyymmdd(dt) != ad) ? 'Invalid&nbsp;Date' : dt;
	}
	function today(days) { return new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() + (days || 0)); }

	
	var arfDatePattern = '^(18|19|20)((\d\d(((0[1-9]|1[012])(0[1-9]|1[0-9]|2[0-8]))|((0[13578]|1[02])(29|30|31))|((0[4,6,9]|11)(29|30))))|(([02468][048]|[13579][26])0229))$';
	var statesPattern = 'AK|AL|AR|AZ|CA|CO|CT|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NC|ND|NE|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY';
	var statesPatternType = (function(){ var ss = new Set(); statesPattern.split('|').forEach(function(s) {ss.add(s.charAt(0))}); return Array.from(ss).join('|') + '|' + statesPattern})();
	//#################################################################################################################
	
	typeof ajaxCache !== 'undefined' || (ajaxCache = new Map());
	// 'https://cors-anywhere.herokuapp.com/'; headers : {'X-Requested-With': 'Accept'}
	//, headers: {'Content-Type': 'application/x-www-form-urlencoded'} <- auto added
	//, headers: {'X-Requested-With': 'Accept'} 
	// url, param, name, element, method, headers, mapper, errorcallback, default
	function ajaxFeed($$, args) {
		function __test(name, item, param){
			if(name) return item[name]==param[name];
			for(var v in param) if(item[v]!=param[v]) return; 
			return true; 
		}
	   //function extend(v1, v2) {r={};for(v in v1)r[v]=v1[v];for(v in v2)r[v]=v2[v]; return r}
	   //o = extend({element : 'result', method: 'GET', headers: {}, mapper : function(i) {return i}}, o);
	   var o = _extend(args, {element : 'result', method: 'GET', headers: {}, mapper : function(i) {return i}});
	   var r = { value : ( o.name ? o.param[o.name] : o.param), url: o.url, status: 'loading', items : []}, cached, has = false;
	   var success = function(data, status) {
		  typeof data == 'string' && (data=JSON.parse(data));
	      ajaxCache.set(o.url, data);
	      var d = data && (o.element && data[o.element] || data), e;
	      o['default'] && (d = [o['default']].concat(d));
	      (r.status = status) == 'success' && Array.isArray(d) && d.forEach( function(i) { r.items.push(i=o.mapper(i)); r.found||__test(o.name, i, o.param)&&(r.found=(o.name ? i[o.name] : i)) });
	      if(!r.found) {
	          e = (o.errorcallback ? o.errorcallback(status, r, o.param) : (r.items.length > 0 ? 'Please&nbsp;make&nbsp;selection' : 'Not&nbsp;found')); 
	          if($$.control.doVal && e && !o.noerror) { $$.control.data = r; $$.error(e) } else { $$.result(r) }
	      } else { 
	          delete $$.control.error;
	          $$.result(r); 
	      }
	   };
	   if( (cached = ajaxCache.get(o.url)) != undefined) success(cached, 'success');
	   else  
	       $.ajax({ url: o.url, dataType: 'json', type: o.method, success: success, 
	            headers : _extend(o.headers, {'Content-Type': 'application/x-www-form-urlencoded'}),
	            error: function (status, error) {
	                r.status = status;
	                e = (o.errorcallback ? o.errorcallback(status, error, o.param) : JSON.stringify(error)); 
	                if($$.control.doVal && e && !o.noerror) { $$.control.data = r; $$.error(e) } else { /*$$.control.error = e;*/ $$.result(r) }
	            }
	        });
	   if(r.status == 'loading') return r; // to prevent re-rendering after synchronous $.ajax call
	}
	//###########################################################################################################
	_extend({ yyyymmdd: yyyymmdd,
			ARFtoDate: ARFtoDate,
			today: today,
			arfDatePattern: arfDatePattern,
			statesPattern: statesPattern,
			statesPatternType: statesPatternType,
			ajaxFeed: ajaxFeed,
            extend: _extend },
	exports);
});