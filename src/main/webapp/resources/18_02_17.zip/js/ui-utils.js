// Promise polyfill
(function(){"use strict";function e(){}function n(e){if(!(this instanceof n))throw new TypeError("Promises must be constructed via new");if("function"!=typeof e)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=undefined,this._deferreds=[],f(e,this)}function t(e,t){for(;3===e._state;)e=e._value;0!==e._state?(e._handled=!0,n._immediateFn(function(){var n=1===e._state?t.onFulfilled:t.onRejected;if(null!==n){var i;try{i=n(e._value)}catch(f){return void r(t.promise,f)}o(t.promise,i)}else(1===e._state?o:r)(t.promise,e._value)})):e._deferreds.push(t)}function o(e,t){try{if(t===e)throw new TypeError("A promise cannot be resolved with itself.");if(t&&("object"==typeof t||"function"==typeof t)){var o=t.then;if(t instanceof n)return e._state=3,e._value=t,void i(e);if("function"==typeof o)return void f(function(e,n){return function(){e.apply(n,arguments)}}(o,t),e)}e._state=1,e._value=t,i(e)}catch(u){r(e,u)}}function r(e,n){e._state=2,e._value=n,i(e)}function i(e){2===e._state&&0===e._deferreds.length&&n._immediateFn(function(){e._handled||n._unhandledRejectionFn(e._value)});for(var o=0,r=e._deferreds.length;r>o;o++)t(e,e._deferreds[o]);e._deferreds=null}function f(e,n){var t=!1;try{e(function(e){t||(t=!0,o(n,e))},function(e){t||(t=!0,r(n,e))})}catch(i){if(t)return;t=!0,r(n,i)}}var u=setTimeout;n.prototype["catch"]=function(e){return this.then(null,e)},n.prototype.then=function(n,o){var r=new this.constructor(e);return t(this,new function(e,n,t){this.onFulfilled="function"==typeof e?e:null,this.onRejected="function"==typeof n?n:null,this.promise=t}(n,o,r)),r},n.prototype["finally"]=function(e){var n=this.constructor;return this.then(function(t){return n.resolve(e()).then(function(){return t})},function(t){return n.resolve(e()).then(function(){return n.reject(t)})})},n.all=function(e){return new n(function(n,t){function o(e,f){try{if(f&&("object"==typeof f||"function"==typeof f)){var u=f.then;if("function"==typeof u)return void u.call(f,function(n){o(e,n)},t)}r[e]=f,0==--i&&n(r)}catch(c){t(c)}}if(!e||"undefined"==typeof e.length)throw new TypeError("Promise.all accepts an array");var r=Array.prototype.slice.call(e);if(0===r.length)return n([]);for(var i=r.length,f=0;r.length>f;f++)o(f,r[f])})},n.resolve=function(e){return e&&"object"==typeof e&&e.constructor===n?e:new n(function(n){n(e)})},n.reject=function(e){return new n(function(n,t){t(e)})},n.race=function(e){return new n(function(n,t){for(var o=0,r=e.length;r>o;o++)e[o].then(n,t)})},n._immediateFn="function"==typeof setImmediate&&function(e){setImmediate(e)}||function(e){u(e,0)},n._unhandledRejectionFn=function(e){void 0!==console&&console&&console.warn("Possible Unhandled Promise Rejection:",e)};var c=function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if(void 0!==c)return c;throw Error("unable to locate global object")}();c.Promise||(c.Promise=n)})();

// ############ polyfill for Array.*, Map and Set
Array.isArray || (Array.isArray = function(o) { return o instanceof Array })
Array.prototype.forEach || (Array.prototype.forEach = function(f, a) { for(var i = 0; i < this.length; i++) f.call(a, this[i], i, this) })
Array.prototype.indexOf || (Array.prototype.indexOf = function(e) { var i=this.length-1; for(;i>=0 && this[i] != e;i--); return i; })
Array.prototype.filter || (Array.prototype.filter = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) f.call(a, this[i], i, this) && r.push(this[i]); return r } )
Array.prototype.map || (Array.prototype.map = function(f, a) { var r=[],i; for(i=0; i < this.length; i++) r.push(f.call(a, this[i], i, this)); return r } )
Array.from || (Array.from = function(s) { 
    var r = [], o;
    Symbol && Symbol.iterator && (typeof s[Symbol.iterator] === 'function') && (s=s[Symbol.iterator]());
    if(typeof s.next === 'function') 
        while(!(o=s.next()).done) 
            r.push(o.value); 
    else 
        s.forEach(function(e) { r.push(e); } ); 
    return r; 
})

var Symbol = Symbol || {}
Symbol.iterator || (Symbol.iterator='Symbol(Symbol.iterator)')

var Map = Map || (
Map = function(i) { this.size = 0; i && Array.from(i).forEach(function(a) { a=Array.from(a); this.set(a[0], a[1]) }, this) },
Map.prototype.clear = function() { delete this.head; this.size = 0; },
Map.prototype[Symbol.iterator] = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: [this.pos.key, this.pos.value], done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Map.prototype.keys = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.key, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Map.prototype.values = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.value, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},        
Map.prototype.entries = Map.prototype[Symbol.iterator],
Map.prototype.set = function(k,v) {
    if(!this.head) {
        this.head = {key: k, value: v};
        this.size++;
    } else {
        if(this.head.key == k) {
            this.head.value = v;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k; h=h.next) ;
            if(!h.next) {
                h.next = {key: k};
                this.size++;
            }
            h.next.value = v;
        }
    }
    return this; 
},
Map.prototype['delete'] = function(k) {
    if(this.head) {
        if(this.head.key == k) {
            this.head = this.head.next;
            this.size--;
            return true;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k ; h=h.next);
            if(h.next) {
                h.next = h.next.next;
                this.size --;
                return true;
            }
        }
    }
    return false;
},
Map.prototype.get = function(k) {
    var h = this.head;
    for(; h; h=h.next) 
        if(h && h.key == k) return h.value;
},
Map.prototype.has = function(k) { return typeof this.get(k) !== 'undefined'; },
Map.prototype.forEach = function(f, a) {
    var h = this.head;
    for(; h; h=h.next) 
        f.call(a, h.value, h.key, this);
},
Map.prototype.keys = function() { var ret = []; for(var h = this.head; h; h=h.next)  ret.push(h.key);  return ret;},
Map.prototype.values = function() { var ret = []; for(var h = this.head; h; h=h.next)  ret.push(h.value);  return ret;},
Map)

var Set = Set || (Set = function(i) { this.size = 0; i && Array.from(i).forEach(function(v) { this.add(v) }, this) },
Set.prototype[Symbol.iterator] = function() {
    return {
        pos: this.head,
        next: function () {
            return this.pos ? (r = { value: this.pos.key, done: false }, (this.pos=this.pos.next), r) : { done : true };
        }
    }
},
Set.prototype.keys = Set.prototype[Symbol.iterator],
Set.prototype.entries = Set.prototype[Symbol.iterator],
Set.prototype.add = function(k) {
    if(!this.head) {
        this.head = {key: k};
        this.size++;
    } else {
        if(this.head.key != k) {
            var h = this.head;
            for(; h.next && h.next.key != k; h=h.next) ;
            if(!h.next) {
                h.next = {key: k};
                this.size++;
            }
        }
    }
    return this; 
},
Set.prototype.clear = function() { delete this.head; this.size = 0; },
Set.prototype['delete'] = function(k) {
    if(this.head) {
        if(this.head.key == k) {
            this.head = this.head.next;
            this.size--;
            return true;
        } else {
            var h = this.head;
            for(; h.next && h.next.key != k ; h=h.next);
            if(h.next) {
                h.next = h.next.next;
                this.size --;
                return true;
            }
        }
    }
    return false;
},
Set.prototype.forEach = function (f, a) {
    for(var h = this.head; h; h=h.next) 
        f.call(a, h.key, this);
},
Set.prototype.has = function(k) { 
    for(var h = this.head; h; h=h.next) 
        if(h && h.key == k) return true;
    return false;
},
Set)

//###### JSON polyfill
window.JSON || (window.JSON = {
    parse: function(sJSON) { return eval('(' + sJSON + ')'); },
    stringify: (function () {
      var toString = Object.prototype.toString;
      var hasOwnProperty = Object.prototype.hasOwnProperty;
      var isArray = Array.isArray || function (a) { return toString.call(a) === '[object Array]'; };
      var escMap = {'"': '\\"', '\\': '\\\\', '\b': '\\b', '\f': '\\f', '\n': '\\n', '\r': '\\r', '\t': '\\t'};
      var escFunc = function (m) { return escMap[m] || '\\u' + (m.charCodeAt(0) + 0x10000).toString(16).substr(1); };
      var escRE = /[\\"\u0000-\u001F\u2028\u2029]/g;
      return function stringify(value) {
        if (value == null) {
          return 'null';
        } else if (typeof value === 'number') {
          return isFinite(value) ? value.toString() : 'null';
        } else if (typeof value === 'boolean') {
          return value.toString();
        } else if (typeof value === 'object') {
          if (typeof value.toJSON === 'function') {
            return stringify(value.toJSON());
          } else if (isArray(value)) {
            var res = '[';
            for (var i = 0; i < value.length; i++)
              res += (i ? ', ' : '') + stringify(value[i]);
            return res + ']';
          } else if (toString.call(value) === '[object Object]') {
            var tmp = [];
            for (var k in value) {
              // in case "hasOwnProperty" has been shadowed
              if (hasOwnProperty.call(value, k))
                tmp.push(stringify(k) + ': ' + stringify(value[k]));
            }
            return '{' + tmp.join(', ') + '}';
          }
        }
        return '"' + value.toString().replace(escRE, escFunc) + '"';
      };
    })()
  });


function displayServerError(text) {
    require(['jquery-ui'], function() {
        console.error(text),
        $('<div>').text(text).dialog({ 
            classes: {'ui-dialog': 'server-error-dlg'}, 
            title: 'Server error', 
            width: 1000, 
            height: 400, 
            close: function() { 
                $(this).dialog('destroy') 
            } 
        }).focus()
    });
}

//===================================================================================

function _extend(from, to) { 
    for (var key in from) to[key] = from[key]; return to;
}

// TODO: make AMD module 

// TODO: doing it via submit is crappier, but fits better with current design. Switch back to ajaxPost / single page app when whole chain of forms will support it.  

var _postModel = function(runtime, onsuccess, onerror) {
	require(['jquery'], function($) {
		typeof runtime.form.onpost == 'function' && runtime.form.onpost.call(runtime.form, _extend(runtime.model_proxy, function(p) { return arguments.callee.get(p); }), runtime);
	    $.ajax({ url: '/DfeServlet.srv?a=model', type: 'POST', dataType: 'json', contentType:"application/json", data: JSON.stringify(runtime.model_proxy.data),
	        success: function(r, s) { 
	        	runtime.notifyControls(runtime.findControls(r.data.map(function(v) {return v.field})), 'validate');
	        	(r.result ? onsuccess : onerror)(r, s);
	        },
	        error: function(d, s, e) { onerror(d, s, e); }
	    })		
	})
}

var whenTrue = function(check, action, ctx, delay, tries) {
	var worker;
	//tries = tries||10;
	(worker = function() {
		check.call(ctx) ? action.call(ctx) : typeof tries == 'undefined' || --tries > 0 ? setTimeout(worker, delay||5) : 0;  
	})();
}

//TODO: something about this:
function yyyymmdd(dt) {
	var mm = dt.getMonth() + 1, dd = dt.getDate();
	return [dt.getFullYear(),(mm>9 ? '' : '0') + mm,(dd>9 ? '' : '0') + dd].join('');
}
function ARFtoDate(ad) { 
    Array.isArray(ad) && (ad=ad[0]);
    var dt = new Date(ad.substr(0, 4),ad.substr(4, 2)-1,ad.substr(6, 2)); 
    return (dt == 'Invalid&nbsp;Date' || yyyymmdd(dt) != ad) ? 'Invalid&nbsp;Date' : dt;
}
//===================================================================================
//TODO: wrap all this
var runtime; 

function dfe_navigate(form, action) {
	try {
		var arf = runtime.model_proxy.data;
	    form.policy_formname.value = arf.policy[0].formname;
	    if(action == 'next') {
	    	form.action.value = 'next_experimental';
	     	/*
	     	typeof runtime.form.onpost == 'function' && runtime.form.onpost(_extend(runtime.model_proxy, function(p) { return arguments.callee.get(p); }), runtime);
	     	form.jsonModel.value = JSON.stringify(arf);
	     	form.submit();
	     	*/
	     	_postModel(
	     		runtime, 
	     		function(){ 
	     			form.submit() 
	     		}, 
	     		function(xhr){
	     			xhr.responseText && displayServerError(xhr.responseText);
	     			document.getElementById('button_next').disabled = false; 
		     	}
	     	);
	    }
	} catch(e) {
		displayServerError(e.toString());
		document.getElementById('button_next').disabled = false; 
	}
}

// support for nav tab
var DFE = DFE || {};
DFE.nav = function () {
    var postForm = function (form, formName) {
            form.action.value = 'load';
            form.policy_formname.value = formName;
            form.submit();
        },
        backNav = function (form, formName) {
            form.action.value = 'back';
            form.policy_formname.value = formName;
            form.submit();
        },
        reloadQuote = function (form, formName) {
            form.action.value = 'reload';
            form.policy_formname.value = formName;
            form.submit();
        },
        submitForm = function (form) {
        	dfe_navigate(form, 'next'); 
        };
    
    return {
        postForm:      postForm,
        backNav:       backNav,
        reloadQuote:   reloadQuote,
        submitForm:    submitForm
    };
} ();

require.config({
	waitSeconds : 3600,
    bundles: {
        'components/generic' : ['components/editbox','components/editbox-$','components/dropdown','components/button','components/container','components/div','components/div-r','components/tab-s','components/div-c','components/checkbox','components/radiolist','components/label','components/html','components/textarea','components/editbox-P','components/div-button','components/multioption','components/typeahead','components/placeholder','components/div-button-x'],
    },
    paths: {
        'forms': '../forms'
    },            
});

define('ui-utils', ['jquery'], function(jq) {
    var _isIE7 = (navigator.appVersion.indexOf("MSIE 7.") != -1);
    navigator.appVersion.match(/MSIE (8|9)/) && setInterval(function() {jq('#innercontainer').width(jq('#body').width() + jq('.nav-menu-options').width() + 20)}, 100);
    
    return {
        setAttribute: function (node, name, value) { 
            if(value && value != 0) { _isIE7 ? jq(node).attr(name, value) : node.setAttribute(name, value); return true; } else node.removeAttribute(name); 
        },
        addEventListener: function (node, eventname, handler, capture) {
            typeof node.addEventListener === 'function' ? node.addEventListener(eventname, handler, capture) : jq(node).on(eventname, handler);
        },
        removeEventListener: function (node, eventname, handler, capture) {
            typeof node.removeEventListener === 'function' ? node.removeEventListener(eventname, handler, capture) : jq(node).off(eventname, handler);
        }
    }
});

function defineForm(n, d, f) {
	var fx = function() {
	    var a = f.apply(this, arguments), m = new Map(), i;
	    a.name = n;
	    a.dependencies = {};
	    f.toString().match(/\([^\)]*\)/)[0].replace(/\(|\)| /g,'').split(',').slice(1).forEach(function(n, i){
	        a.dependencies[n] = d[i + 1];
	    })
	    a.dfe.forEach(function(row) {
	        m.get(row.parent) ? m.get(row.parent).push(row) : m.set(row.parent, [ row ]);
	        (row.children = m.get(row.name)) || m.set(row.name, row.children = []);
	    });
	    return a;
	}
	define("forms/" + n, d, fx); 
}

(function() {
	var _try = true, processed = new Set(), f = function(node){
        require(['dfe-core', 'forms/' + node.getAttribute('dfe-form'), 'jquery', 'dfe-common'], function(core, dfe) {
        	var model = node.getAttribute('dfe-model'), f = function(arf) { node._dfe_runtime = core.startRuntime({ model : arf, node: node, form: dfe, params: { launchThrottle: 200 } }) };
        	window[model] && typeof window[model].then == 'function' ? window[model].then(f) : f(window[model]); 
        })
    }, l = function() {
    	if(_try) {
			for(var n = document.querySelectorAll('div[dfe-form]'), i = 0; i < n.length; i++)  
				processed.has(n[i]) || ( processed.add(n[i]), f(n[i]));
			setTimeout(l, 5);
    	}
	};
	window.onload = function() { l(); _try = false }
	l();
})();

