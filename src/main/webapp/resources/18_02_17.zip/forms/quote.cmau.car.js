defineForm("quote.cmau.car", [ "require", "dfe-common", "components/div", "components/tab-s", "components/div-button", "components/label", "components/button", "components/container", "components/radiolist", "components/editbox", "components/dropdown", "components/html", "components/editbox-$", "components/checkbox" ], function(require, cmn, __c_div, __c_tab_s, __c_div_button, __c_label, __c_button, __c_container, __c_radiolist, __c_editbox, __c_dropdown, __c_html, __c_editbox_$, __c_checkbox) {
    return new class {
        constructor() {
            this.dfe = [ {
                name: "root",
                component: __c_div,
                get: $$ => $$('policy.cmau')
            }, {
                name: "locs",
                component: __c_tab_s,
                parent: "root",
                get: $$ => $$('.location'),
                atr: () => ({
                    haclass: 'tab-item-active',
                    focusnew: 1,
                    hfield: 'loc-hdr',
                    rowclass$header: 'tab-header',
                    rowclass: 'tab-body',
                    rowstyle: 'display: block; width: 900px;'
                })
            }, {
                name: "loc-hdr",
                component: __c_div_button,
                parent: "locs",
                get: $$ => '<a style="color: #444">Location #' + ($$.index(2) + 1) + '</a><br/>' + ($$('.city') + ' ' + $$('.state') + ' ' + $$('.zip') + '-' + $$('.zipaddon')).replace(/-$/, ''),
                val: $$ => $$.errorwatch($$.control.parentControl),
                atr: () => ({
                    class: 'div-button',
                    eclass: 'dfe-error',
                    vstrategy: 'always'
                }),
                pos: {
                    colclass: "tab-item"
                }
            }, {
                name: "loc-title1",
                component: __c_div,
                parent: "locs",
                get: $$ => [ $$ ],
                pos: {
                    colclass: "tab-section-header"
                }
            }, {
                name: "cars",
                component: __c_tab_s,
                parent: "locs",
                get: $$ => $$('.car'),
                atr: () => ({
                    haclass: 'tab-item-active',
                    focusnew: 1,
                    hfield: 'car-hdr',
                    style: 'width: 100%;',
                    rowclass$header: 'tab-header',
                    rowclass: 'tab-body',
                    rowstyle: 'padding: 0px; overflow: hidden;'
                }),
                pos: {
                    colstyle: "width: 100%; "
                }
            }, {
                name: "field-159",
                component: __c_label,
                parent: "loc-title1",
                get: $$ => 'Location #' + ($$.index() + 1)
            }, {
                name: "add-car",
                component: __c_button,
                parent: "loc-title1",
                get: () => 'Add Vehicle',
                set: function($$, value) {
                    var p = $$.append('.car', this.carDefaults)[0], r = $$.runtime;
                    setTimeout(function() {
                        r.findChildren(r.findControls('cars', $$), 1, 0, 'vin', p).pop().ui.focus();
                    }, 2);
                },
                atr: () => ({
                    style: 'padding: 1px 10px'
                }),
                pos: {
                    colstyle: "position: absolute; right: 5px; top: 5px"
                }
            }, {
                name: "car-hdr",
                component: __c_div_button,
                parent: "cars",
                get: $$ => $$('..state') + ' - Vehicle #' + ($$.index() + 1) + '<br/>' + $$('.ModelYr') + ' ' + $$('.make'),
                val: $$ => $$.errorwatch($$.control.parentControl),
                atr: $$ => ({
                    class: 'div-button',
                    eclass: 'dfe-error',
                    vstrategy: 'always',
                    ta: {
                        visible: $$('..car').length - 1
                    }
                }),
                pos: {
                    colclass: "tab-item"
                }
            }, {
                name: "add-loc",
                component: __c_button,
                parent: "root",
                get: () => 'Add location',
                set: $$ => $$.append('.location'),
                atr: () => ({
                    style: 'width: 150px; margin: 3px; display: none'
                }),
                pos: {
                    colstyle: "align-self: flex-end;"
                }
            }, {
                name: "body",
                component: __c_container,
                parent: "cars",
                get: $$ => [ $$ ],
                atr: () => ({
                    class: 'tab-cols-5-5 tab-alt-color'
                }),
                pos: {
                    colstyle: "width:100%",
                    colclass: "-dfe-inline-section-1"
                }
            }, {
                name: "field-154",
                component: __c_label,
                parent: "body",
                get: $$ => 'Vehicle #' + ($$.index() + 1),
                pos: {
                    w: "2"
                }
            }, {
                name: "field-8",
                component: __c_label,
                parent: "body",
                get: () => 'Do you have the VIN?',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-9",
                component: __c_radiolist,
                parent: "body",
                get: $$ => $$('.hasvin'),
                set: ($$, value) => $$.set('.hasvin', value),
                atr: () => ({
                    orientation: 'horizontal'
                })
            }, {
                name: "vinnumber",
                component: __c_container,
                parent: "body",
                get: $$ => [ $$ ],
                atr: $$ => ({
                    class: 'tab-cols-5-5 tab-alt-color'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "padding: 0px"
                }
            }, {
                name: "hastype",
                component: __c_container,
                parent: "body",
                get: $$ => $$('.hasvin') == 'Y' ? [] : [ $$ ],
                atr: () => ({
                    class: 'tab-cols-5-5 tab-alt-color-1'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "padding: 2px 0px; background: white;"
                }
            }, {
                name: "field-22",
                component: __c_label,
                parent: "hastype",
                get: () => 'Override VIN?',
                atr: () => ({
                    style: 'padding-left: 10px; '
                })
            }, {
                name: "field-23",
                component: __c_radiolist,
                parent: "hastype",
                get: $$ => $$('.vinoverride'),
                set: ($$, value) => $$.set('.vinoverride', value),
                atr: () => ({
                    orientation: 'horizontal'
                })
            }, {
                name: "field-20",
                component: __c_label,
                parent: "hastype",
                get: () => 'Vehicle Year, Make and/or Model is not available in dropdown',
                atr: () => ({
                    style: 'padding-left: 10px; '
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-21",
                component: __c_radiolist,
                parent: "hastype",
                get: $$ => $$('.custom'),
                set: ($$, value) => $$.set('.custom', value),
                atr: () => ({
                    orientation: 'horizontal'
                })
            }, {
                name: "field-10",
                component: __c_label,
                parent: "vinnumber",
                get: () => 'Vihicle Identification Number (VIN)',
                val: $$ => $$('.hasvin') == 'Y' || $$('.vinoverride') == 'Y',
                atr: () => ({
                    vstrategy: 'always'
                })
            }, {
                name: "vin",
                component: __c_editbox,
                parent: "vinnumber",
                get: function($$) {
                    return function($$) {
                        var vin = $$('.vinnumber'), has = $$('.hasvin') == 'Y', url = '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getVinLookupResults&vinNumber=' + vin, cached = ajaxCache.get(url), r;
                        var foo = function(data) {
                            if (!(r = data.result).isMatch) {
                                $$.error('Vin not found');
                                $$.events.filter(e => 'validate' == e.action).length || $$.control.notifications.push({
                                    action: 'validate'
                                });
                            }
                            $$.set('.vinvalid', r.isMatch ? 'Y' : 'N');
                            $$.set('.vehicletype', r.vehicleType);
                            $$.set('.ModelYr', r.vehicleYear);
                            $$.set('.make', r.vehicleMake);
                            $$.set('.modelinfo', r.vehicleModel);
                            $$.set('.vehicleocostnew', r.vehicleCost);
                            return cached || ajaxCache.set(url, data);
                        };
                        has && vin.length == 17 && (cached && foo(cached) || $.ajax({
                            url: url,
                            type: 'POST',
                            dataType: 'json',
                            success: foo,
                            error: function(e, s) {
                                $$.error(s);
                            }
                        }));
                        return has || $$('.vinoverride') == 'Y' ? vin : '';
                    }($$);
                },
                set: ($$, value) => $$.set('.vinnumber', value),
                val: $$ => $$('.vinnumber').length != 17 && $$.error('Invalid VIN number format'),
                atr: $$ => ({
                    spellcheck: 'false',
                    disabled: $$('.hasvin') != 'Y' && $$('.vinoverride') != 'Y',
                    style: 'width: 150px; text-transform:uppercase;',
                    pattern: '[a-zA-Z0-9]{1,17}'
                })
            }, {
                name: "field-153",
                component: __c_div,
                parent: "body",
                get: () => [],
                pos: {
                    n: "Y",
                    s: "padding: 0px"
                }
            }, {
                name: "field-12",
                component: __c_label,
                parent: "body",
                get: () => 'Vehicle Type',
                val: $$ => $$('.hasvin') == 'Y' || $$.required('.vehicletype'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "type-choice",
                component: __c_dropdown,
                parent: "body",
                get: $$ => ({
                    value: $$('.vehicletype'),
                    items: [ {
                        value: 'car',
                        description: 'Private Passenger Type'
                    }, {
                        value: 'truck',
                        description: 'Truck, Tractor or Trailer'
                    }, {
                        value: 'golf',
                        description: 'Golf Carts and Low Speed Vehicles'
                    }, {
                        value: 'mobile',
                        description: 'Mobile Homes'
                    }, {
                        value: 'antique',
                        description: 'Antique Autos'
                    } ]
                }),
                set: ($$, value) => $$.set('.vehicletype', value),
                atr: $$ => ({
                    disabled: $$('.hasvin') == 'Y',
                    style: 'width: fit-content;',
                    default: []
                })
            }, {
                name: "field-14",
                component: __c_html,
                parent: "body",
                get: () => '<a href="javascript:showHelp(\'/cmau_help.html#year\')" class="qmark"></a>Vehicle Year',
                val: $$ => $$('.hasvin') == 'Y' || $$.required('.ModelYr', '(18|19|20)\\d{2}'),
                atr: () => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "year-switch",
                component: __c_div,
                parent: "body",
                get: $$ => [ $$ ]
            }, {
                name: "year-free",
                component: __c_editbox,
                parent: "year-switch",
                get: $$ => $$('.ModelYr'),
                set: ($$, value) => $$.set('.ModelYr', value),
                atr: $$ => ({
                    hidden: !($$('.hasvin') == 'Y' || $$('.custom') == 'Y'),
                    disabled: $$('.hasvin') == 'Y',
                    style: 'width: 150px;',
                    formatting: 'XXXX'
                })
            }, {
                name: "year-choice",
                component: __c_dropdown,
                parent: "year-switch",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getYearOptions&vehicleType=' + $$('.vehicletype'),
                    param: {
                        value: $$('.ModelYr')
                    },
                    name: 'value',
                    noerror: 1
                }),
                set: ($$, value) => $$.set('.ModelYr', value),
                atr: $$ => ({
                    hidden: $$('.hasvin') == 'Y' || $$('.custom') == 'Y',
                    style: 'width: fit-content;',
                    default: []
                })
            }, {
                name: "field-16",
                component: __c_html,
                parent: "body",
                get: () => '<a href="javascript:showHelp(\'/cmau_help.html#make\')" class="qmark"></a>Vehicle Make',
                val: $$ => $$('.hasvin') == 'Y' || $$.required('.make'),
                atr: $$ => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "make-switch",
                component: __c_div,
                parent: "body",
                get: $$ => [ $$ ]
            }, {
                name: "make-free",
                component: __c_editbox,
                parent: "make-switch",
                get: $$ => $$('.make'),
                set: ($$, value) => $$.set('.make', value),
                atr: $$ => ({
                    hidden: !($$('.hasvin') == 'Y' || $$('.custom') == 'Y'),
                    disabled: $$('.hasvin') == 'Y',
                    style: 'width: 150px;'
                })
            }, {
                name: "make-choice",
                component: __c_dropdown,
                parent: "make-switch",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getMakeOptions&vehicleType=' + $$('.vehicletype') + '&vehicleYear=' + $$('.ModelYr'),
                    param: {
                        value: $$('.make')
                    },
                    name: 'value',
                    noerror: 1
                }),
                set: ($$, value) => $$.set('.make', value),
                atr: $$ => ({
                    hidden: $$('.hasvin') == 'Y' || $$('.custom') == 'Y',
                    style: 'width: fit-content;',
                    default: []
                })
            }, {
                name: "field-26",
                component: __c_label,
                parent: "body",
                get: () => '<a href="javascript:showHelp(\'/cmau_help.html#model\')" class="qmark"></a>Vehicle Model',
                val: $$ => $$('.hasvin') == 'Y' || $$.required('.modelinfo'),
                atr: () => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "model-switch",
                component: __c_div,
                parent: "body",
                get: $$ => [ $$ ]
            }, {
                name: "model-free",
                component: __c_editbox,
                parent: "model-switch",
                get: $$ => $$('.modelinfo'),
                set: ($$, value) => $$.set('.modelinfo', value),
                atr: $$ => ({
                    hidden: !($$('.hasvin') == 'Y' || $$('.custom') == 'Y'),
                    disabled: $$('.hasvin') == 'Y',
                    style: 'width: 150px;'
                })
            }, {
                name: "model-choice",
                component: __c_dropdown,
                parent: "model-switch",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getModelOptions&vehicleType=' + $$('.vehicletype') + '&vehicleYear=' + $$('.ModelYr') + '&vehicleMake=' + $$('.make'),
                    param: {
                        value: $$('.modelinfo')
                    },
                    name: 'value',
                    headers: {
                        'X-Requested-With': 'Accept'
                    },
                    noerror: 1
                }),
                set: ($$, value) => $$.set('.modelinfo', value),
                atr: $$ => ({
                    hidden: $$('.hasvin') == 'Y' || $$('.custom') == 'Y',
                    style: 'width: 150px;',
                    default: []
                })
            }, {
                name: "costnew-lbl",
                component: __c_label,
                parent: "body",
                get: () => 'Original Cost New',
                val: $$ => $$('.hasvin') == 'Y' || $$.required('.vehicleocostnew'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "costnew-free",
                component: __c_editbox_$,
                parent: "body",
                get: $$ => $$('.vehicleocostnew'),
                set: ($$, value) => $$.set('.vehicleocostnew', value),
                atr: $$ => ({
                    disabled: $$('.hasvin') == 'Y',
                    style: 'width: 150px;',
                    formatting: '$9,999,999'
                })
            }, {
                name: "private",
                component: __c_container,
                parent: "body",
                get: $$ => $$('.vehicletype') == 'car' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-2-5-3'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "field-36",
                component: __c_label,
                parent: "private",
                get: () => 'Private Passenger Auto',
                pos: {
                    w: "3"
                }
            }, {
                name: "field-33",
                component: __c_label,
                parent: "private",
                get: () => 'Usage',
                val: $$ => $$.required('.VehUseCd'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-34",
                component: __c_dropdown,
                parent: "private",
                get: $$ => ({
                    value: $$('.VehUseCd'),
                    items: [ {
                        value: 'Furnished for Non-Business Use'
                    }, {
                        value: 'All Other'
                    } ]
                }),
                set: ($$, value) => $$.set('.VehUseCd', value),
                atr: () => ({
                    default: [],
                    style: 'width: min-content;'
                })
            }, {
                name: "field-35",
                component: __c_button,
                parent: "private",
                get: () => 'Apply to all Passenger Vehicles',
                set: ($$, value) => this.all($$, '.VehUseCd', 'car'),
                atr: $$ => ({
                    class: 'link-button'
                })
            }, {
                name: "nonbus",
                component: __c_container,
                parent: "private",
                get: $$ => $$('.VehUseCd') == 'Furnished for Non-Business Use' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-2-5-3'
                }),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-37",
                component: __c_label,
                parent: "nonbus",
                get: () => 'Operator Experience',
                val: $$ => $$.required('.OperExp'),
                atr: () => ({
                    style: 'padding-left: 10px'
                })
            }, {
                name: "field-38",
                component: __c_dropdown,
                parent: "nonbus",
                get: $$ => ({
                    value: $$('.OperExp'),
                    items: [ {
                        value: 'No operator licensed less than 5 years'
                    }, {
                        value: 'Licenses less than 5 yrs not owner or principal operator'
                    }, {
                        value: 'Owner or principal operator licensed less than 5 yrs'
                    } ]
                }),
                set: ($$, value) => $$.set('.OperExp', value),
                atr: () => ({
                    default: [],
                    style: 'width: min-content;'
                })
            }, {
                name: "field-39",
                component: __c_button,
                parent: "nonbus",
                get: () => 'Apply to all Passenger Vehicles',
                set: $$ => this.all($$, '.OperExp', 'car'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-41",
                component: __c_label,
                parent: "nonbus",
                get: () => 'Operator Use',
                val: $$ => $$.required('.OperUse'),
                atr: () => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-42",
                component: __c_dropdown,
                parent: "nonbus",
                get: $$ => ({
                    value: $$('.OperUse'),
                    items: [ {
                        value: 'Not driven to work or school'
                    }, {
                        value: 'To of from work less than 15 miles'
                    }, {
                        value: 'To or from work 15 or more miles'
                    } ]
                }),
                set: ($$, value) => $$.set('.OperUse', value),
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-43",
                component: __c_button,
                parent: "nonbus",
                get: () => 'Apply to all Passenger Vehicles',
                set: $$ => this.all($$, '.OperUse', 'car'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-151",
                component: __c_div,
                parent: "private",
                get: $$ => [ $$ ],
                pos: {
                    n: "Y",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-44",
                component: __c_label,
                parent: "private",
                get: () => 'Horsepower',
                val: $$ => $$.required('.Horsepower', '[0-9]{2,4}'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-45",
                component: __c_editbox,
                parent: "private",
                get: $$ => $$('.Horsepower'),
                set: ($$, value) => $$.set('.Horsepower', value),
                atr: () => ({
                    pattern: '[0-9]{1,4}',
                    style: 'width: 100px'
                })
            }, {
                name: "field-46",
                component: __c_button,
                parent: "private",
                get: () => 'Apply to all Passenger Vehicles',
                set: ($$, value) => this.all($$, '.Horsepower', 'car'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "truck",
                component: __c_container,
                parent: "body",
                get: $$ => $$('.vehicletype') == 'truck' ? [ $$ ] : [],
                atr: $$ => ({
                    class: 'col-va-middle col-3-centred tab-alt-color tab-cols-3-4-3',
                    skip: $$('.VehicleClass') == 'Trailer Types' ? [ 'field-152' ] : []
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "golf",
                component: __c_container,
                parent: "body",
                get: $$ => $$('.vehicletype') == 'golf' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "mobile",
                component: __c_container,
                parent: "body",
                get: $$ => $$('.vehicletype') == 'mobile' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-2-5-3'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "field-49",
                component: __c_label,
                parent: "truck",
                get: () => 'Trucks, Tractors and Trailers',
                pos: {
                    w: "3"
                }
            }, {
                name: "field-50",
                component: __c_label,
                parent: "truck",
                get: () => 'Vehicle Class',
                val: $$ => $$.required('.VehicleClass'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-51",
                component: __c_dropdown,
                parent: "truck",
                get: $$ => ({
                    value: $$('.VehicleClass'),
                    items: [ {
                        value: 'Light Truck 10,000 lbs GVW or less'
                    }, {
                        value: 'Medium Truck 10,001 to 20,000 lbs GVW'
                    }, {
                        value: 'Heavy Truck 20,001 to 45,000 lbs GVW'
                    }, {
                        value: 'Extra-Heavy Truck over 45,000 lbs GVW'
                    }, {
                        value: 'Heavy Truck-Tractor 45,000 lbs GCW or less'
                    }, {
                        value: 'Extra-Heavy Truck-Tractor over 45,000 lbs GCW'
                    }, {
                        value: 'Trailer Types'
                    } ]
                }),
                set: ($$, value) => $$.set('.VehicleClass', value),
                atr: () => ({
                    default: []
                })
            }, {
                name: "field-52",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.VehicleClass', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "trailer",
                component: __c_container,
                parent: "truck",
                get: $$ => $$('.VehicleClass') == 'Trailer Types' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-3-4-3'
                }),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-54",
                component: __c_label,
                parent: "trailer",
                get: () => 'Trailer Type',
                val: $$ => $$.required('.TrailerType'),
                atr: () => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "N"
                }
            }, {
                name: "field-55",
                component: __c_dropdown,
                parent: "trailer",
                get: $$ => ({
                    value: $$('.TrailerType'),
                    items: [ {
                        value: 'Semitrailers'
                    }, {
                        value: 'Trailers'
                    }, {
                        value: 'Service or Utility Trailer (0-200 lbs. Load Capacity)'
                    } ]
                }),
                set: ($$, value) => $$.set('.TrailerType', value),
                atr: () => ({
                    default: [],
                    style: 'max-width: 310px;'
                })
            }, {
                name: "field-56",
                component: __c_button,
                parent: "trailer",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.TrailerType', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-152",
                component: __c_div,
                parent: "truck",
                get: $$ => [ $$ ],
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-57",
                component: __c_label,
                parent: "truck",
                get: () => 'Is this auto used for transporting personnel, tools and equipment to and from a job location where it is parked for the majority of the day?',
                val: $$ => $$.required('.UseClassInd1'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-58",
                component: __c_radiolist,
                parent: "truck",
                get: $$ => $$('.UseClassInd1'),
                set: ($$, value) => $$.set('.UseClassInd1', value),
                atr: () => ({
                    orientation: 'horizontal'
                })
            }, {
                name: "field-59",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.UseClassInd1', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-61",
                component: __c_label,
                parent: "truck",
                get: () => 'Is this auto used for pick-up and/or delivery of property to residential households?',
                val: $$ => $$.required('.UseClassInd2'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-62",
                component: __c_radiolist,
                parent: "truck",
                get: $$ => $$('.UseClassInd2'),
                set: ($$, value) => $$.set('.UseClassInd2', value),
                atr: () => ({
                    orientation: 'horizontal'
                })
            }, {
                name: "field-63",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.UseClassInd2', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-64",
                component: __c_label,
                parent: "truck",
                get: () => 'Radius',
                val: $$ => $$.required('.RadiusClass'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-65",
                component: __c_dropdown,
                parent: "truck",
                get: $$ => ({
                    value: $$('.RadiusClass'),
                    items: [ {
                        value: 'Local up to 50 miles'
                    }, {
                        value: 'Intermediate 51 to 200 miles'
                    }, {
                        value: 'Long distance over 200 miles'
                    } ]
                }),
                set: ($$, value) => $$.set('.RadiusClass', value),
                atr: () => ({
                    style: 'width:fit-content',
                    default: []
                })
            }, {
                name: "field-66",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.RadiusClass', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-67",
                component: __c_label,
                parent: "truck",
                get: () => 'Used in dumping',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-68",
                component: __c_checkbox,
                parent: "truck",
                get: $$ => $$('.DumpingOpInd'),
                set: ($$, value) => $$.set('.DumpingOpInd', value)
            }, {
                name: "field-69",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.DumpingOpInd', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-70",
                component: __c_label,
                parent: "truck",
                get: () => 'Secondary Class',
                val: $$ => $$.required('.SecondaryClass'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-71",
                component: __c_dropdown,
                parent: "truck",
                get: $$ => ({
                    value: $$('.SecondaryClass'),
                    items: [ {
                        value: 'Truckers'
                    }, {
                        value: 'Food Delivery'
                    }, {
                        value: 'Specialized Delivery'
                    }, {
                        value: 'Waste Disposal'
                    }, {
                        value: 'Farmers'
                    }, {
                        value: 'Dump &amp; Transit Mix'
                    }, {
                        value: 'Contractors'
                    }, {
                        value: 'Not Otherwise Specified'
                    } ]
                }),
                set: ($$, value) => $$.set('.SecondaryClass', value),
                atr: () => ({
                    style: 'width:fit-content',
                    default: []
                })
            }, {
                name: "field-72",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.SecondaryClass', 'truck'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-73",
                component: __c_label,
                parent: "truck",
                get: () => 'Secondary Class Type',
                val: $$ => $$.required('.SecondaryClassType'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-74",
                component: __c_dropdown,
                parent: "truck",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getSecondaryClassTypeOptions&secondaryClass=' + encodeURIComponent($$('.SecondaryClass')),
                    param: {
                        value: $$('.SecondaryClassType')
                    },
                    name: 'value',
                    headers: {
                        'X-Requested-With': 'Accept'
                    },
                    noerror: 1
                }),
                set: ($$, value) => $$.set('.SecondaryClassType', value),
                atr: () => ({
                    style: 'width:fit-content',
                    default: []
                })
            }, {
                name: "field-75",
                component: __c_button,
                parent: "truck",
                get: () => 'Apply to all Trucks, Tractors and Trailers',
                set: $$ => this.all($$, '.SecondaryClassType', 'truck'),
                atr: () => ({
                    class: 'link-button'
                }),
                pos: {
                    n: "N"
                }
            }, {
                name: "covs",
                component: __c_container,
                parent: "body",
                get: $$ => [ $$ ],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-4-3-3'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "field-77",
                component: __c_label,
                parent: "covs",
                get: () => 'Coverages',
                pos: {
                    w: "3"
                }
            }, {
                name: "field-78",
                component: __c_label,
                parent: "covs",
                get: () => 'Physical Damage Only?',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-79",
                component: __c_checkbox,
                parent: "covs",
                get: $$ => $$('.PhysDmgInd'),
                set: ($$, value) => $$.set('.PhysDmgInd', value)
            }, {
                name: "field-80",
                component: __c_button,
                parent: "covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.PhysDmgInd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-81",
                component: __c_label,
                parent: "covs",
                get: () => 'Comp. Ded',
                val: $$ => $$.required('.coverages.otc.ded'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-82",
                component: __c_dropdown,
                parent: "covs",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getCompDedOptions&vehicleType=' + $$('.vehicletype'),
                    param: {
                        value: $$('.coverages.otc.ded')
                    },
                    name: 'value',
                    headers: {
                        'X-Requested-With': 'Accept'
                    },
                    noerror: 1,
                    mapper: function(o) {
                        return {
                            value: o.value,
                            description: o.text
                        };
                    }
                }),
                set: ($$, value) => $$.set('.coverages.otc.ded', value),
                atr: () => ({
                    style: 'width: min-content;',
                    default: []
                })
            }, {
                name: "field-83",
                component: __c_button,
                parent: "covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.otc.ded'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-84",
                component: __c_label,
                parent: "covs",
                get: () => 'Coll. Ded',
                val: $$ => $$.required('.coverages.col.ded'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-85",
                component: __c_dropdown,
                parent: "covs",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getCollDedOptions&vehicleType=' + $$('.vehicletype'),
                    param: {
                        value: $$('.coverages.col.ded')
                    },
                    name: 'value',
                    headers: {
                        'X-Requested-With': 'Accept'
                    },
                    noerror: 1,
                    mapper: function(o) {
                        return {
                            value: o.value,
                            description: o.text
                        };
                    }
                }),
                set: ($$, value) => $$.set('.coverages.col.ded', value),
                atr: () => ({
                    style: 'width: min-content;',
                    default: []
                })
            }, {
                name: "field-86",
                component: __c_button,
                parent: "covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.col.ded'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "val-switch",
                component: __c_container,
                parent: "covs",
                get: $$ => ($$('.coverages.col.ded') + $$('.coverages.otc.ded')).toString().match(/\d|Full/) ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-4-3-3'
                }),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-87",
                component: __c_label,
                parent: "val-switch",
                get: () => 'Valuation',
                val: $$ => $$.required('.ValuationMethod'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-88",
                component: __c_dropdown,
                parent: "val-switch",
                get: $$ => cmn.ajaxFeed($$, {
                    url: '/AJAXServlet.srv?method=CMAUVehicleScriptHelper&action=getValuationMethodOptions&vehicleType=' + $$('.vehicletype'),
                    param: {
                        value: $$('.ValuationMethod')
                    },
                    name: 'value',
                    headers: {
                        'X-Requested-With': 'Accept'
                    },
                    noerror: 1
                }),
                set: ($$, value) => $$.set('.ValuationMethod', value),
                atr: $$ => ({
                    style: 'width: min-content;',
                    default: []
                })
            }, {
                name: "field-89",
                component: __c_button,
                parent: "val-switch",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.ValuationMethod'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "amt-switch",
                component: __c_container,
                parent: "covs",
                get: $$ => this.compCol($$) && $$('.ValuationMethod') == 'Stated Amount' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color-1 tab-cols-4-3-3'
                }),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-91",
                component: __c_label,
                parent: "amt-switch",
                get: () => 'Stated Amount',
                val: $$ => $$.required('.StatedAmt'),
                atr: () => ({
                    style: 'padding-left: 10px; '
                })
            }, {
                name: "field-92",
                component: __c_editbox_$,
                parent: "amt-switch",
                get: $$ => $$('.StatedAmt'),
                set: ($$, value) => $$.set('.StatedAmt', value),
                atr: () => ({
                    style: 'width: 100px',
                    formatting: '$9,999,999'
                })
            }, {
                name: "field-93",
                component: __c_button,
                parent: "amt-switch",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.StatedAmt'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "pdonly-switch",
                component: __c_container,
                parent: "covs",
                get: $$ => $$('.PhysDmgInd') == 'Y' || $$('..state') != 'KS' ? [] : [ $$ ],
                atr: $$ => this.covTabClass($$, 1),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-95",
                component: __c_label,
                parent: "pdonly-switch",
                get: () => 'Personal Injury Protection Coverage'
            }, {
                name: "field-96",
                component: __c_checkbox,
                parent: "pdonly-switch",
                get: $$ => $$('.coverages.pip.IncludeInd'),
                set: ($$, value) => $$.set('.coverages.pip.IncludeInd', value)
            }, {
                name: "field-97",
                component: __c_button,
                parent: "pdonly-switch",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.pip.IncludeInd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "pip-switch",
                component: __c_container,
                parent: "pdonly-switch",
                get: $$ => $$('.coverages.pip.IncludeInd') == 'Y' ? [ $$ ] : [],
                atr: $$ => this.covTabClass($$),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-99",
                component: __c_label,
                parent: "pip-switch",
                get: () => 'Additional Personal Injury Protection',
                val: $$ => $$.required('.coverages.pip.addedpipoption'),
                atr: () => ({
                    style: 'padding-left: 10px'
                })
            }, {
                name: "field-100",
                component: __c_dropdown,
                parent: "pip-switch",
                get: () => ({
                    value: $$('.coverages.pip.addedpipoption'),
                    items: [ 'Option 1', 'Option 2' ]
                }),
                set: ($$, value) => $$.set('.coverages.pip.addedpipoption', value),
                atr: () => ({
                    style: 'width: fit-content',
                    default: []
                })
            }, {
                name: "field-101",
                component: __c_button,
                parent: "pip-switch",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.pip.addedpipoption'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-102",
                component: __c_label,
                parent: "pip-switch",
                get: () => 'Number of Individuals for Broadened PIP',
                val: $$ => $$.required('.coverages.pip.broadpipnum'),
                atr: () => ({
                    style: 'padding-left: 10px'
                }),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-103",
                component: __c_editbox,
                parent: "pip-switch",
                get: $$ => $$('.coverages.pip.broadpipnum'),
                set: ($$, value) => $$.set('.coverages.pip.broadpipnum', value),
                atr: () => ({
                    pattern: '[0-9]{1,5}',
                    style: 'width: 80px;'
                })
            }, {
                name: "field-104",
                component: __c_button,
                parent: "pip-switch",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.pip.broadpipnum'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "opt-covs",
                component: __c_container,
                parent: "body",
                get: $$ => [ $$ ],
                atr: $$ => ({
                    class: 'col-3-centred tab-cols-4-3-3 ' + ($$('.vehicletype') == 'car' ? 'tab-alt-color' : 'tab-alt-color-1')
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "-dfe-inline-section-1"
                }
            }, {
                name: "field-106",
                component: __c_label,
                parent: "opt-covs",
                get: () => 'Optional Coverages',
                pos: {
                    w: "3"
                }
            }, {
                name: "car-ctrl",
                component: __c_div,
                parent: "body",
                get: $$ => [ $$ ],
                atr: $$ => ({
                    skip: $$('..car').length > 1 ? [] : [ 'remove-car' ],
                    style: 'padding: 5px; text-align: right; background: lightgray;'
                }),
                pos: {
                    n: "Y",
                    w: "2",
                    s: "padding: 2px 0px"
                }
            }, {
                name: "towing-switch",
                component: __c_container,
                parent: "opt-covs",
                get: $$ => $$('.vehicletype') == 'car' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color-1 tab-cols-4-3-3'
                }),
                pos: {
                    w: "3",
                    n: "Y",
                    s: "padding: 0px;"
                }
            }, {
                name: "clone-car",
                component: __c_button,
                parent: "car-ctrl",
                get: () => 'Clone Vehicle',
                set: function($$, value) {
                    var r = $$.runtime, p = $$.clone(), loc = p.get('..'), f, c;
                    (f = function() {
                        (c = r.findChildren(r.findControls('cars', loc), 1, 0, 'vin', p).pop()) && c.ui ? (c.ui.focus(), 
                        c.ui.setSelectionRange(c.ui.value.length - 6, c.ui.value.length)) : setTimeout(f, 5);
                    })();
                },
                atr: () => ({
                    style: 'padding: 1px 10px; margin: 0px 5px'
                }),
                pos: {
                    colstyle: "display: inline-block"
                }
            }, {
                name: "field-117",
                component: __c_label,
                parent: "towing-switch",
                get: () => 'Towing and Labor',
                val: $$ => $$.required('.coverages.towlabor.towlabor')
            }, {
                name: "remove-car",
                component: __c_button,
                parent: "car-ctrl",
                get: () => 'Remove Vehicle',
                set: $$ => $$.detach(),
                atr: () => ({
                    style: 'padding: 1px 10px; margin: 0px 5px'
                }),
                pos: {
                    colstyle: "display: inline-block"
                }
            }, {
                name: "field-118",
                component: __c_dropdown,
                parent: "towing-switch",
                get: $$ => ({
                    value: $$('.coverages.towlabor.towlabor'),
                    items: [ {
                        value: 'No Coverage'
                    }, {
                        value: '50',
                        description: '$50'
                    }, {
                        value: '100',
                        description: '$100'
                    }, {
                        value: '200',
                        description: '$200'
                    } ]
                }),
                set: ($$, value) => $$.set('.coverages.towlabor.towlabor', value),
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-119",
                component: __c_button,
                parent: "towing-switch",
                get: () => 'Apply to all Passenger Vehicles',
                set: $$ => this.all($$, '.coverages.towlabor.towlabor', 'car'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-107",
                component: __c_label,
                parent: "opt-covs",
                get: () => 'Loss Payee',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-108",
                component: __c_checkbox,
                parent: "opt-covs",
                get: $$ => $$('.losspayee.losspayeeInd'),
                set: ($$, value) => $$.set('.losspayee.losspayeeInd', value)
            }, {
                name: "field-109",
                component: __c_button,
                parent: "opt-covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.losspayee.losspayeeInd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-110",
                component: __c_label,
                parent: "opt-covs",
                get: () => 'Additional Insured - Lessor',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-111",
                component: __c_checkbox,
                parent: "opt-covs",
                get: $$ => $$('.losspayee.ailessorInd'),
                set: ($$, value) => $$.set('.losspayee.ailessorInd', value)
            }, {
                name: "field-112",
                component: __c_button,
                parent: "opt-covs",
                get: function($$) {
                    return 'Apply to all Vehicles';
                },
                set: $$ => this.all($$, '.losspayee.ailessorInd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-113",
                component: __c_label,
                parent: "opt-covs",
                get: () => 'Hired Auto - Specified As Covered Auto You Own',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-114",
                component: __c_checkbox,
                parent: "opt-covs",
                get: $$ => $$('.losspayee.haownInd'),
                set: ($$, value) => $$.set('.losspayee.haownInd', value)
            }, {
                name: "field-115",
                component: __c_button,
                parent: "opt-covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.losspayee.haownInd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-122",
                component: __c_label,
                parent: "golf",
                get: () => 'Golf Carts and Low Speed Vehicles',
                pos: {
                    w: "3"
                }
            }, {
                name: "field-123",
                component: __c_label,
                parent: "mobile",
                get: () => 'Mobile Homes',
                pos: {
                    w: "3"
                }
            }, {
                name: "field-124",
                component: __c_label,
                parent: "golf",
                get: () => 'Type',
                val: $$ => $$.required('.GolfType'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-125",
                component: __c_dropdown,
                parent: "golf",
                get: $$ => ({
                    value: $$('.GolfType'),
                    items: [ 'Golf Cart', 'Low Speed Vehicles' ]
                }),
                set: function($$, value) {
                    $$.set('.GolfType', value);
                },
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-126",
                component: __c_button,
                parent: "golf",
                get: () => 'Apply to all Golf Carts and Low Speed Vehicles',
                set: $$ => this.all($$, '.GolfType', 'golf'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-127",
                component: __c_label,
                parent: "golf",
                get: () => 'Use',
                val: $$ => $$.required('.GolfUse'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-128",
                component: __c_dropdown,
                parent: "golf",
                get: $$ => ({
                    value: $$('.GolfUse'),
                    items: [ 'Used On Golf Course', 'Other Commercial Purposes' ]
                }),
                set: ($$, value) => $$.set('.GolfUse', value),
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-129",
                component: __c_button,
                parent: "golf",
                get: () => 'Apply to all Golf Carts and Low Speed Vehicles',
                set: $$ => this.all($$, '.GolfUse', 'golf'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-130",
                component: __c_label,
                parent: "golf",
                get: () => 'Vehicle subject to compulsory, financial or other law',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-131",
                component: __c_checkbox,
                parent: "golf",
                get: $$ => $$('.GolfVhsub'),
                set: ($$, value) => $$.set('.GolfVhsub', value)
            }, {
                name: "field-132",
                component: __c_button,
                parent: "golf",
                get: () => 'Apply to all Golf Carts and Low Speed Vehicles',
                set: $$ => this.all($$, '.GolfVhsub', 'golf'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-133",
                component: __c_label,
                parent: "mobile",
                get: () => 'Type',
                val: $$ => $$.required('.MobileHomeType'),
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-134",
                component: __c_dropdown,
                parent: "mobile",
                get: $$ => ({
                    value: $$('.MobileHomeType'),
                    items: [ 'Trailer Equipped As Living Quarters', 'Pickup Trucks Used Solely To Transport Camper Bodies', 'Motor Homes Self-Propelled Equipped As Living Quarters' ]
                }),
                set: ($$, value) => $$.set('.MobileHomeType', value),
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-135",
                component: __c_button,
                parent: "mobile",
                get: () => 'Apply to all Mobile Homes',
                set: $$ => this.all($$, '.MobileHomeType', 'mobile'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "length-switch",
                component: __c_container,
                parent: "mobile",
                get: $$ => $$('.MobileHomeType') == 'Motor Homes Self-Propelled Equipped As Living Quarters' ? [ $$ ] : [],
                atr: () => ({
                    class: 'col-3-centred tab-alt-color tab-cols-2-5-3'
                }),
                pos: {
                    n: "Y",
                    w: "3"
                }
            }, {
                name: "field-137",
                component: __c_label,
                parent: "length-switch",
                get: () => 'Length',
                val: $$ => $$.required('.MotorHomeSize')
            }, {
                name: "field-138",
                component: __c_dropdown,
                parent: "length-switch",
                get: $$ => ({
                    value: $$('.MotorHomeSize'),
                    items: [ 'Up To 22 feet', 'More Than 22 feet' ]
                }),
                set: ($$, value) => $$.set('.MotorHomeSize', value),
                atr: () => ({
                    default: [],
                    style: 'width: fit-content'
                })
            }, {
                name: "field-139",
                component: __c_button,
                parent: "length-switch",
                get: () => 'Apply to all Mobile Homes',
                set: $$ => this.all($$, '.MotorHomeSize', 'mobile'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "added-pip",
                component: __c_container,
                parent: "pip-switch",
                get: $$ => +$$('.coverages.pip.broadpipnum') > 0 ? [ $$ ] : [],
                atr: $$ => this.covTabClass($$),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-144",
                component: __c_html,
                parent: "added-pip",
                get: () => 'Number of Named Individuals for Additional <br> Broadened PIP',
                val: $$ => $$.required('.coverages.pip.addedbroadpipnum'),
                atr: () => ({
                    style: 'padding-left: 10px'
                })
            }, {
                name: "field-145",
                component: __c_editbox,
                parent: "added-pip",
                get: $$ => $$('.coverages.pip.addedbroadpipnum'),
                set: ($$, value) => $$.set('.coverages.pip.addedbroadpipnum', value),
                atr: () => ({
                    pattern: '[0-9]{1,5}',
                    style: 'width: 80px;'
                })
            }, {
                name: "field-146",
                component: __c_button,
                parent: "added-pip",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.pip.addedbroadpipnum'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "added-pip-s",
                component: __c_container,
                parent: "added-pip",
                get: $$ => +$$('.coverages.pip.addedbroadpipnum') > 0 ? [ $$ ] : [],
                atr: $$ => this.covTabClass($$, 1),
                pos: {
                    n: "Y",
                    w: "3",
                    s: "padding: 0px;"
                }
            }, {
                name: "field-148",
                component: __c_label,
                parent: "added-pip-s",
                get: () => 'Additional Broadened Personal Injury Protection',
                val: $$ => $$.required('.coverages.pip.addedbpipoptioncd'),
                atr: () => ({
                    style: 'padding-left: 10px'
                })
            }, {
                name: "field-149",
                component: __c_dropdown,
                parent: "added-pip-s",
                get: $$ => ({
                    value: $$('.coverages.pip.addedbpipoptioncd'),
                    items: [ 'Option 1', 'Option 2' ]
                }),
                set: ($$, value) => $$.set('.coverages.pip.addedbpipoptioncd', value),
                atr: () => ({
                    style: 'width: fit-content',
                    default: []
                })
            }, {
                name: "field-150",
                component: __c_button,
                parent: "added-pip-s",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.coverages.pip.addedbpipoptioncd'),
                atr: () => ({
                    class: 'link-button'
                })
            }, {
                name: "field-156",
                component: __c_label,
                parent: "opt-covs",
                get: () => 'Employee as Lessor',
                pos: {
                    n: "Y"
                }
            }, {
                name: "field-157",
                component: __c_checkbox,
                parent: "opt-covs",
                get: $$ => $$('.emplessor')
            }, {
                name: "field-158",
                component: __c_button,
                parent: "opt-covs",
                get: () => 'Apply to all Vehicles',
                set: $$ => this.all($$, '.emplessor'),
                atr: () => ({
                    class: 'link-button'
                })
            } ];
            this.carDefaults = JSON.parse('{"losspayee":[{"losspayeeInd":"N","ailessorInd":"N","haownInd":"N"}],"emplessor":"N","PhysDmgInd":"N","DumpingOpInd":"N","hasvin":"Y","UseClassInd1":"N","UseClassInd2":"N","coverages":[{"pip":[{"IncludeInd":"N"}],"liab":[{"IncludeInd":"Y"}],"towlabor":[{"towlabor":"No Coverage"}]}]}');
        }
        all($$, prop, type) {
            $$('...location.car').forEach(car => type && car.data.vehicletype != type || car.set(prop, $$(prop)));
        }
        compCol($$) {
            return ($$('.coverages.col.ded') + $$('.coverages.otc.ded')).toString().match(/\d|Full/);
        }
        covTabClass($$, opt) {
            var v = $$('.ValuationMethod') == 'Stated Amount' || !this.compCol($$);
            opt || (v = !v);
            return {
                class: 'col-3-centred tab-cols-4-3-3 ' + (v ? 'tab-alt-color' : 'tab-alt-color-1')
            };
        }
        onstart($$) {
            $$('policy.cmau.location').forEach(loc => loc.defaultSubset('.car', this.carDefaults));
        }
        onpost($$) {}
        setup() {
            if (typeof window != 'undefined') {
                window.showHelp = function(url) {
                    window.open(url, 'DetailWin', 'scrollbars=yes,resizable=yes,toolbar=no,height=250,width=250').focus();
                };
            }
        }
    }();
});